---
name: agenda24h-project
description: Continue o desenvolvimento, diagnostico, documentacao e homologacao do projeto Agenda 24h usando o contexto, codigo, migrations e workflows incluidos nesta skill.
---

# Agenda 24h — continuidade do projeto

Use esta skill quando o usuario pedir para entender, continuar, corrigir, testar ou planejar o Agenda 24h. Ela contem uma **fotografia local** do projeto; nao comprova o estado atual do Supabase, n8n, Evolution, portal publicado ou credenciais.

## Inicio obrigatorio

1. Leia `references/LEIA-PRIMEIRO.md`.
2. Leia `project/documentacao/passagem-projeto-2026-09-23.md` e os seis documentos em `project/documentacao/especificacao-2026-09-24/` conforme a tarefa.
3. Os arquivos principais estao em `project/`. Alguns documentos historicos, testes e copias de migrations foram reunidos como texto em `references/ARQUIVOS-CONSOLIDADOS.txt`; procure pelo caminho original nesse arquivo. No Claude Code, a pasta local `project/` contem cada arquivo separadamente.
4. Inspecione os arquivos de codigo e exports diretamente relacionados. Se houver divergencia, trate a instrucao atual do usuario como prioridade; depois as decisoes recentes, as evidencias do codigo e, por ultimo, documentos antigos. Aponte qualquer conflito importante antes de mudar o rumo.

## Regras que nao devem ser perdidas

- Um WF1 por empresa, disparado **por mensagem do webhook**; consolidacao normal de 5 segundos. Nao trocar por polling de 10 segundos.
- Atendimento automatico apenas para texto e audio; imagens e videos sao ignorados sem resposta. Audio recebido, resposta textual.
- O Supabase e a agenda oficial. A IA consulta ferramentas e nao inventa horarios, servicos, precos ou reservas. Agendamento exige confirmacao explicita e protecao contra conflito.
- `salaoexemplar` e somente empresa ficticia de teste, nunca uma regra global.
- Lembretes 24 h/2 h, reativacao pos-atendimento concluido, reativacao de faltosos, comparecimento, pesquisa de satisfacao e convite neutro ao Google sao fluxos distintos. O convite Google independe da nota.
- Portal contempla administrador, profissional e recepcionista; codigo existente nao equivale a permissao e funcionamento comprovados.
- Nao invente credenciais ou IDs de credenciais. Separe Evolution, Postgres de atendimento, `anon` do portal e `service_role` de provisionamento. Nunca solicite segredo no chat nem o incorpore a arquivos.
- Nao declare migrations aplicadas, workflow ativo ou teste externo aprovado com base apenas em arquivo local. Confirme em modo leitura. Antes de alterar ambiente real, obtenha autorizacao especifica, backup e plano de retorno proporcionais ao risco.

## Modo de trabalho

Para cada pedido: identifique o resultado solicitado, confira as fontes relevantes, diga o estado comprovado e a incerteza, faca apenas as alteracoes autorizadas e valide-as. Ao entregar, separe claramente **preparado localmente**, **implantado** e **homologado**. Nao altere banco, webhook, credenciais ou workflows em producao por inferencia.

Prioridade conhecida em 24/09/2026: destravar e homologar o WF1 linear com agendamento real como cliente; em seguida lembretes e as duas reativacoes. Ainda restam homologacoes de comparecimento, pesquisa, portal e provisionamento para declarar o produto completo.
