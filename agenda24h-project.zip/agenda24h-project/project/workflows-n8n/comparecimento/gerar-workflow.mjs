import { writeFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';

const validar = `const x = $json;
const fail = (http_status,codigo) => [{json:{http_status,body:{sucesso:false,codigo,mensagem:'Não foi possível registrar o resultado.'}}}];
const h = x.headers || {};
const origin = h.origin;
const allowed = ['https://portalagenda24h.multiverso360.com.br','https://fluxomultiverso.github.io'];
if (origin !== undefined && !allowed.includes(origin)) return fail(403,'ORIGEM_NAO_PERMITIDA');
if (!/^application\\/json(?:\\s*;|$)/i.test(h['content-type'] || '')) return fail(415,'TIPO_NAO_SUPORTADO');
const b = x.body;
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
if (!b || typeof b !== 'object' || Array.isArray(b) || Object.keys(b).length !== 3 ||
    typeof b.solicitacao_id !== 'string' || !uuid.test(b.solicitacao_id) ||
    typeof b.agendamento_id !== 'string' || !uuid.test(b.agendamento_id) ||
    !['sim','nao'].includes(b.resposta)) return fail(400,'ENTRADA_INVALIDA');
const authorization = h.authorization;
if (typeof authorization !== 'string' || !/^Bearer [A-Za-z0-9._~-]+$/i.test(authorization) || authorization.length > 8192) return fail(401,'NAO_AUTENTICADO');
return [{json:{solicitacao_id:b.solicitacao_id.toLowerCase(),agendamento_id:b.agendamento_id.toLowerCase(),resposta:b.resposta,authorization}}];`;

const identidade = `const x = $json;
const code = Number(x.statusCode);
const fail = (http_status,codigo) => [{json:{http_status,body:{sucesso:false,codigo,mensagem:'Não foi possível registrar o resultado.'}}}];
if (code === 401 || code === 403) return fail(401,'NAO_AUTENTICADO');
if (code !== 200) return fail(503,'AUTENTICACAO_INDISPONIVEL');
const user = x.body;
if (!user || typeof user.id !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(user.id)) return fail(503,'AUTENTICACAO_INDISPONIVEL');
if (user.is_anonymous !== false || user.role !== 'authenticated') return fail(401,'NAO_AUTENTICADO');
const b = $('Validar entrada').first().json;
return [{json:{usuario_id:user.id,solicitacao_id:b.solicitacao_id,agendamento_id:b.agendamento_id,resposta:b.resposta}}];`;

const resultado = `const r = $json.resultado;
const fail = (http_status,codigo) => [{json:{http_status,body:{sucesso:false,codigo,mensagem:'Não foi possível registrar o resultado.'}}}];
if (!r || typeof r !== 'object') return fail(503,'GRAVACAO_INDISPONIVEL');
if (r.sucesso === true && r.http_status === 200 && ['concluido','faltou'].includes(r.status) && r.agendamento_id && typeof r.repeticao === 'boolean' &&
    (r.status === 'concluido' ? !!r.concluido_em && r.faltou_em === null : !!r.faltou_em && r.concluido_em === null)) {
  return [{json:{http_status:200,body:{sucesso:true,agendamento_id:r.agendamento_id,status:r.status,concluido_em:r.concluido_em,faltou_em:r.faltou_em,repeticao:r.repeticao,mensagem:r.mensagem}}}];
}
const codes = {ENTRADA_INVALIDA:400,SEM_PERMISSAO:403,SOLICITACAO_REUTILIZADA:409,ESTADO_INCOMPATIVEL:409,ANTES_DO_INICIO:409,LEMBRETE_EM_PROCESSAMENTO:409};
if (r.sucesso === false && codes[r.codigo] === r.http_status) return fail(r.http_status,r.codigo);
return fail(500,'FALHA_INTERNA');`;

const nodes = [];
const add = (name,type,typeVersion,parameters,position,extra={}) => nodes.push({id:randomUUID(),name,type:`n8n-nodes-base.${type}`,typeVersion,position,parameters,...extra});
const gate = (name,position) => add(name,'if',2.2,{conditions:{options:{caseSensitive:true,leftValue:'',typeValidation:'strict',version:2},conditions:[{id:randomUUID(),leftValue:'={{ $json.http_status === undefined }}',rightValue:'',operator:{type:'boolean',operation:'true',singleValue:true}}],combinator:'and'},options:{}},position);
add('POST comparecimento','webhook',2,{httpMethod:'POST',path:'agenda24h/comparecimento/v1',responseMode:'responseNode',options:{allowedOrigins:'https://fluxomultiverso.github.io'}},[0,0],{webhookId:randomUUID()});
add('Validar entrada','code',2,{jsCode:validar},[240,0]);
gate('Entrada valida',[460,0]);
add('Validar token no Supabase','httpRequest',4.2,{
  method:'GET',url:'https://CONFIGURAR-SUPABASE.invalid/auth/v1/user',authentication:'genericCredentialType',genericAuthType:'httpHeaderAuth',sendHeaders:true,
  headerParameters:{parameters:[{name:'Authorization',value:'={{ $json.authorization }}'}]},
  options:{redirect:{redirect:{followRedirects:false}},timeout:8000,response:{response:{fullResponse:true,neverError:true,responseFormat:'json'}}}
},[680,-100],{onError:'continueRegularOutput',notes:'Selecionar Header Auth: apikey = chave anon do projeto. Substituir URL após conferir rota. Nunca service_role. Não seguir redirecionamentos.'});
add('Identidade validada','code',2,{jsCode:identidade},[900,-100]);
gate('Usuario autenticado',[1120,-100]);
add('Registrar em transacao','postgres',2.6,{operation:'executeQuery',query:'SELECT public.registrar_comparecimento_workflow($1::uuid,$2::uuid,$3::uuid,$4::text) AS resultado;',options:{queryReplacement:'={{ [$json.usuario_id, $json.solicitacao_id, $json.agendamento_id, $json.resposta] }}',connectionTimeout:5}},[1340,-180],{onError:'continueRegularOutput',notes:'Credencial PostgreSQL exclusiva agenda24h_comparecimento. Host supabase-db, banco postgres. Não usar container postgres. Ver guia TLS.'});
add('Normalizar resultado','code',2,{jsCode:resultado},[1560,-180]);
add('Responder JSON','respondToWebhook',1.4,{respondWith:'json',responseBody:'={{ $json.body }}',options:{responseCode:'={{ $json.http_status }}',responseHeaders:{entries:[{name:'Cache-Control',value:'no-store'},{name:'Content-Type',value:'application/json; charset=utf-8'}]}}},[1800,100]);
const connections = {};
const connect = (from,to,branch=0) => {
  connections[from] ??= {main:[]};
  while(connections[from].main.length<=branch) connections[from].main.push([]);
  connections[from].main[branch].push({node:to,type:'main',index:0});
};
connect('POST comparecimento','Validar entrada'); connect('Validar entrada','Entrada valida');
connect('Entrada valida','Validar token no Supabase'); connect('Entrada valida','Responder JSON',1);
connect('Validar token no Supabase','Identidade validada'); connect('Identidade validada','Usuario autenticado');
connect('Usuario autenticado','Registrar em transacao'); connect('Usuario autenticado','Responder JSON',1);
connect('Registrar em transacao','Normalizar resultado'); connect('Normalizar resultado','Responder JSON');
const workflow = {name:'Agenda 24h - Registrar comparecimento v1',active:false,nodes,connections,
  settings:{executionOrder:'v1',saveDataErrorExecution:'none',saveDataSuccessExecution:'none',saveManualExecutions:false,saveExecutionProgress:false,executionTimeout:30,timezone:'America/Sao_Paulo'},pinData:{},tags:[]};
writeFileSync(new URL('./workflow-comparecimento.json',import.meta.url),JSON.stringify(workflow,null,2)+'\n');
console.log('Workflow inativo preparado. Nenhuma importação ou ativação.');
