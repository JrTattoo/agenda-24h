import { readFileSync, writeFileSync } from 'node:fs';
const base = new URL('./', import.meta.url);
for (const [file,detail] of [['src/components/agenda/atendimento-card.tsx',false],['src/pages/agenda-detalhe.tsx',true]]) {
 let s=readFileSync(new URL(file,base),'utf8');
 s=s.replace('  registrarComparecimento,','  registrarComparecimento,\n  comparecimentoHabilitado,\n  aplicarResultadoComparecimento,');
 s=s.replace("import { isSupabaseConfigured } from '@/lib/supabase'\n",'');
 s=s.replace('const supabasePronto = isSupabaseConfigured()','const integracaoHabilitada = comparecimentoHabilitado()');
 const start=s.indexOf('    try {\n      if (supabasePronto)');
 const end=s.indexOf('    } catch {',start);
 if(start<0||end<0)throw new Error('Bloco não encontrado: '+file);
 const success=detail ? `          setAtendimento(aplicarResultadoComparecimento(atendimento, result))
          setTipoMensagem('sucesso')
          setMensagem(result.mensagem)` : `          onAtualizar?.(aplicarResultadoComparecimento(atendimento, result))`;
 const failure=detail ? `          setTipoMensagem('erro')
          setMensagem(result.mensagem)` : `          setErro(result.mensagem)`;
 s=s.slice(0,start)+`    try {
      const result = await registrarComparecimento(atendimento.id, resposta)
      if (result.sucesso) {
${success}
        setConfirmando(null)
      } else {
${failure}
      }
`+s.slice(end);
 s=s.replace('if (processando) return','if (processando || !integracaoHabilitada || !liberado || !podeAgir) return');
 s=s.replace('if (!atendimento || processando) return','if (!atendimento || processando || !integracaoHabilitada || !liberado || !podeExecutarAcao()) return');
 s=s.replaceAll('disabled={processando}', 'disabled={processando || !integracaoHabilitada}');
 if(detail) {
   s=s.replace('{podeAgir && !mensagem && (','{podeAgir && (');
   s=s.replace('<div className="pt-2 border-t space-y-3">','<div className="pt-2 border-t space-y-3">\n            {!integracaoHabilitada && <p className="text-sm text-muted-foreground" role="status">Registro de comparecimento temporariamente indisponível.</p>}');
   s=s.replace("Registro de comparecimento disponível{' '}\n                {formatarTempoRestante(tempoRestante)} antes do horário.","Registro disponível a partir do início do atendimento, em{' '}\n                {formatarTempoRestante(tempoRestante)}.");
 } else {
   s=s.replace('<div className="border-t px-4 py-3 space-y-2">','<div className="border-t px-4 py-3 space-y-2">\n          {!integracaoHabilitada && <p className="text-sm text-muted-foreground" role="status">Registro de comparecimento temporariamente indisponível.</p>}');
   s=s.replace('Registro disponível {formatarTempoRestante(tempoRestante)} antes do horário.','Registro disponível a partir do início do atendimento, em {formatarTempoRestante(tempoRestante)}.');
 }
 writeFileSync(new URL(file,base),s);
}
const env=new URL('.env.example',base);
writeFileSync(env,readFileSync(env,'utf8')+'\n# Habilitar somente após login real, migration, Auth, CORS e homologação.\nVITE_COMPARECIMENTO_HABILITADO=false\nVITE_COMPARECIMENTO_WEBHOOK_URL=https://n8n.multiverso360.com.br/webhook/agenda24h/comparecimento/v1\n');
