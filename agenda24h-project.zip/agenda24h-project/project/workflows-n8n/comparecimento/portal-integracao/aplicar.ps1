$ErrorActionPreference = 'Stop'
$portalRoot = [IO.Path]::GetFullPath('C:\projetos\portal consulta agenda24h')
$preparedRoot = $PSScriptRoot
$manifest = Get-Content -LiteralPath (Join-Path $preparedRoot 'originais.json') -Raw | ConvertFrom-Json
foreach ($entry in $manifest) {
    $target = [IO.Path]::GetFullPath((Join-Path $portalRoot $entry.path))
    if (-not $target.StartsWith($portalRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Destino fora do portal.' }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Arquivo modificado durante preparação: $($entry.path). Não foi aplicado." }
}
$docTarget = Join-Path $portalRoot 'INTEGRACAO-COMPARECIMENTO.md'
if (Test-Path -LiteralPath $docTarget) { throw 'Documento de destino já existe; revisar antes de sobrescrever.' }
$backupRoot = Join-Path $preparedRoot ('backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
foreach ($entry in $manifest) {
    $backupFile = Join-Path $backupRoot $entry.path
    New-Item -ItemType Directory -Force -Path (Split-Path $backupFile) | Out-Null
    Copy-Item -LiteralPath (Join-Path $portalRoot $entry.path) -Destination $backupFile
}
foreach ($entry in $manifest) {
    Copy-Item -LiteralPath (Join-Path $preparedRoot $entry.path) -Destination (Join-Path $portalRoot $entry.path)
}
Copy-Item -LiteralPath (Join-Path $preparedRoot 'INTEGRACAO-COMPARECIMENTO.md') -Destination $docTarget
Write-Output "Integração aplicada localmente. Backup: $backupRoot"
Push-Location $portalRoot
try {
    & npm.cmd run build
    if ($LASTEXITCODE -ne 0) { throw 'Falha no build; revisar antes de publicar.' }
    & node.exe node_modules/eslint/bin/eslint.js src/services/comparecimento.ts src/components/agenda/atendimento-card.tsx src/pages/agenda-detalhe.tsx
    if ($LASTEXITCODE -ne 0) { throw 'Falha no lint dos arquivos alterados.' }
} finally { Pop-Location }
