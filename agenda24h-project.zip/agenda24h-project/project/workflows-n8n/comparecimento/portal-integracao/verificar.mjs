import ts from 'file:///C:/projetos/portal%20consulta%20agenda24h/node_modules/typescript/lib/typescript.js';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root='C:/projetos/portal consulta agenda24h';
process.chdir(root);
const stage=fileURLToPath(new URL('.',import.meta.url));
const originals=JSON.parse(readFileSync(new URL('originais.json',import.meta.url),'utf8').replace(/^\uFEFF/,''));
const norm=p=>path.resolve(p).replaceAll('\\','/').toLowerCase();
const overrides=new Map(originals.filter(x=>x.path.endsWith('.ts')||x.path.endsWith('.tsx')).map(x=>[norm(root+'/'+x.path),readFileSync(path.join(stage,x.path),'utf8')]));
const config=ts.readConfigFile(root+'/tsconfig.app.json',ts.sys.readFile);
const parsed=ts.parseJsonConfigFileContent(config.config,ts.sys,root);
const host=ts.createCompilerHost(parsed.options);
const originalRead=host.readFile;
host.readFile=file=>overrides.get(norm(file))??originalRead(file);
const program=ts.createProgram(parsed.fileNames,{...parsed.options,noEmit:true,incremental:false},host);
const diagnostics=ts.getPreEmitDiagnostics(program);
if(diagnostics.length){console.log(ts.formatDiagnosticsWithColorAndContext(diagnostics,{getCanonicalFileName:x=>x,getCurrentDirectory:()=>root,getNewLine:()=> '\n'}));process.exit(1)}
console.log('TypeScript: projeto completo com alterações preparadas aprovado.');
const source=readFileSync(path.join(stage,'src/services/comparecimento.ts'),'utf8')
 .replace("import { supabase, isSupabaseConfigured } from '@/lib/supabase'",'const { supabase, isSupabaseConfigured } = mocks')
 .replaceAll('import.meta.env','mocks.env');
const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2023}}).outputText;
const id='00000000-0000-4000-8000-000000000001';
function setup({enabled=true,session=true,fetcher,storage=new Map()}={}){
 let calls=[];
 const context={exports:{},mocks:{env:{VITE_COMPARECIMENTO_HABILITADO:String(enabled)},isSupabaseConfigured:()=>true,supabase:{auth:{getSession:async()=>({data:{session:session?{access_token:'TOKEN_FICTICIO',user:{id:'USUARIO_FICTICIO',is_anonymous:false}}:null},error:null})}}},URL,AbortController,Date,setTimeout,clearTimeout,crypto:{randomUUID:()=> '00000000-0000-4000-8000-000000000099'},sessionStorage:{getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},fetch:async(url,options)=>{calls.push({url,options});return fetcher?fetcher(url,options):{status:200,json:async()=>({sucesso:true,agendamento_id:id,status:'concluido',concluido_em:'2026-09-19T10:00:00Z',faltou_em:null,repeticao:false})}}};
 vm.runInNewContext(js,context);return {api:context.exports,calls,storage};
}
let count=0;
async function test(name,fn){await fn();count++;console.log('OK '+name)}
await test('desabilitado não envia nem simula sucesso',async()=>{const x=setup({enabled:false});assert.equal((await x.api.registrarComparecimento(id,'sim')).codigo,'RECURSO_INDISPONIVEL');assert.equal(x.calls.length,0)});
await test('sem sessão real não envia',async()=>{const x=setup({session:false});assert.equal((await x.api.registrarComparecimento(id,'sim')).codigo,'NAO_AUTENTICADO');assert.equal(x.calls.length,0)});
await test('ID de mock inválido não envia',async()=>{const x=setup();assert.equal((await x.api.registrarComparecimento('att-1','sim')).codigo,'ENTRADA_INVALIDA');assert.equal(x.calls.length,0)});
await test('POST com token e somente contrato autorizado',async()=>{const x=setup();const r=await x.api.registrarComparecimento(id,'sim');assert.equal(r.sucesso,true);assert.equal(x.calls[0].options.headers.Authorization,'Bearer TOKEN_FICTICIO');assert.equal(x.calls[0].options.method,'POST');assert.deepEqual(Object.keys(JSON.parse(x.calls[0].options.body)).sort(),['agendamento_id','resposta','solicitacao_id']);assert.equal(x.storage.size,0)});
await test('timeout preserva chave após recarregar e bloqueia oposta',async()=>{const storage=new Map();const x=setup({storage,fetcher:async()=>{throw new Error('timeout')}});assert.equal((await x.api.registrarComparecimento(id,'sim')).codigo,'RESULTADO_INCERTO');assert.ok(![...storage.values()].join().includes('TOKEN'));const y=setup({storage});assert.equal((await y.api.registrarComparecimento(id,'nao')).codigo,'TENTATIVA_PENDENTE');assert.equal(y.calls.length,0);await y.api.registrarComparecimento(id,'sim');assert.equal(x.calls[0].options.body,y.calls[0].options.body)});
await test('500 nunca é sucesso e preserva chave',async()=>{const x=setup({fetcher:async()=>({status:500,json:async()=>({sucesso:false})})});assert.equal((await x.api.registrarComparecimento(id,'sim')).sucesso,false);assert.equal(x.storage.size,1)});
await test('200 incompleto nunca é sucesso',async()=>{const x=setup({fetcher:async()=>({status:200,json:async()=>({sucesso:true})})});assert.equal((await x.api.registrarComparecimento(id,'sim')).sucesso,false)});
await test('mensagem de banco não vaza no erro',async()=>{const x=setup({fetcher:async()=>({status:403,json:async()=>({sucesso:false,codigo:'SEM_PERMISSAO',mensagem:'SQL SEGREDO'})})});const r=await x.api.registrarComparecimento(id,'sim');assert.equal(r.codigo,'SEM_PERMISSAO');assert.ok(!r.mensagem.includes('SEGREDO'))});
await test('cliques simultâneos fazem um POST',async()=>{let resolve;const pending=new Promise(r=>resolve=r);const x=setup({fetcher:()=>pending});const a=x.api.registrarComparecimento(id,'sim');await new Promise(r=>setTimeout(r,0));const b=await x.api.registrarComparecimento(id,'sim');assert.equal(b.codigo,'TENTATIVA_PENDENTE');assert.equal(x.calls.length,1);resolve({status:503,json:async()=>({})});await a});
await test('horário: antes nega, início permite, inválido nega',()=>{const x=setup();const now=Date.now();assert.equal(x.api.podeRegistrarComparecimento(new Date(now+60000).toISOString()),false);assert.equal(x.api.podeRegistrarComparecimento(new Date(now).toISOString()),true);assert.equal(x.api.podeRegistrarComparecimento('invalido'),false)});
await test('UI usa timestamps servidor e zera campo oposto',()=>{const x=setup();const a=x.api.aplicarResultadoComparecimento({situacao:'confirmado',faltouEm:'antigo'},{status:'concluido',concluido_em:'2026-09-19T10:00:00Z',faltou_em:null});assert.equal(a.situacao,'atendimento_concluido');assert.equal(a.concluidoEm,'2026-09-19T10:00:00Z');assert.equal(a.faltouEm,null)});
console.log(`${count} testes do serviço aprovados; nenhum acesso ao webhook real.`);
