# Evidências e plano de homologação

Execução local em 18/09/2026: `npm test` reportou **51 testes, 51 passaram, zero falhas**, incluindo o teste agregador do banco (21 subtestes SQL e 29 testes de código/estrutura do workflow). Sem servidor, clientes reais, token real ou acesso à rede de produção. A instalação PGlite foi autorizada e realizada somente para os testes locais.

Comandos para repetir na pasta deste pacote:

```text
npm ci --ignore-scripts --no-audit --no-fund
npm run build
npm test
```

O build regenera apenas o JSON, que continua inativo. Não importa nem ativa o workflow. Os testes avaliam o código efetivamente embutido nesse JSON e executam SQL real em PostgreSQL WebAssembly, em memória. Foram carregadas as migrations 001, 005, 009 e 017; outras migrations e todo o estado remoto não são reproduzidos. O banco local usa usuário/empresa/cliente/agendamento fictícios. A fixture de cliente anonimizado evita depender de telefone real. Não foram alteradas migrations antigas para acomodar os testes.

**Limites:** PGlite não reproduz sessões PostgreSQL independentes, TLS, pg_hba, Docker, conexão do nó Postgres, semântica completa do executor n8n nem tráfego HTTP de navegador. Respostas Auth nos testes de código são simuladas; isso verifica a decisão do workflow, não prova validação real de um JWT. A validação real está prevista na chamada ao Auth e precisa do teste integrado. A nova migration foi criada/executada localmente; não foi aplicada remotamente.

| Cenário solicitado | Evidência local | Pendente em homologação |
|---|---|---|
| 1 Admin Sim | SQL: concluido, data e campo oposto null | POST com login real |
| 2 Admin Não | SQL: faltou, data e campo oposto null | POST com login real |
| 3 Profissional responsável | SQL permite | Login profissional real |
| 4 Profissional diferente | SQL 403 | POST real |
| 5 Outra empresa | SQL 403, inexistente também 403 | Comparar HTTP sem vazamento |
| 6 Vínculo/profissional inativo | SQL nega ambos | Login real; revogação durante requisição |
| 7 Token ausente/inválido/expirado | Código rejeita ausente e respostas 401/403; anônimo negado | Tokens inválido/expirado de verdade e logout revogado |
| 8 Nulos/IDs inválidos/respostas desconhecidas | Código e SQL rejeitam; campos extras negados | JSON malformado, 413, 415 no proxy |
| 9 Cancelado | SQL 409 | POST real |
| 10 Repetição | SQL mesma chave e nova chave; mesma data, um evento | Contar logs/eventos após POST |
| 11 Oposta após resultado | SQL 409; chave reutilizada 409 | POST real |
| 12 Duas simultâneas | Proteção por locks no SQL, sem teste de sessões reais | Obrigatório: uma 200, oposta 409; também duas iguais |
| 13 Retry após timeout | SQL repete solicitação de sucesso sem alterar data | Perder resposta depois de COMMIT; repetir mesma chave |
| 14 Falha banco sem falso sucesso | Código retorna 503; falha forçada da auditoria reverte transação | Desconectar banco; timeout e credencial inválida |
| 15 status_presenca | SQL preserva | Conferir também datas da confirmação antecipada |
| 16 Regra temporal | Antes do início nega; depois do início e antes do fim permite | Limite exato e relógios/fusos diferentes |
| 17 Auditoria/lembretes | SQL cria evento; cancela pendentes/falhos; preserva enviado; processando gera 409 | Autoria/correlation completos; corrida com consumidor real |

Também passaram: credencial interna sem UPDATE direto, anon/authenticated/service_role sem EXECUTE, vínculo revogado antes do replay, identidade recebida exclusivamente da resposta Auth, remoção do token antes do nó de banco, ausência de credenciais/pinData no JSON, retenção desativada e todos os ramos previstos ligados ao respondedor.

## Preparação de homologação

Restaurar schema revisado em ambiente isolado. Não restaurar dados de clientes reais para estes testes. Criar duas empresas fictícias, administradores, profissional responsável, outro profissional e vínculo/profissional inativos; um usuário com vínculos nas duas empresas. Criar agendamentos distintos para cada cenário, pois não há correção/reversão. Não usar o SQL de fixtures de PGlite como cadastro de usuários Auth real: criar contas fictícias pelo mecanismo Auth suportado na homologação.

Separar agendamentos confirmados passados, em andamento, futuros, cancelados e concluídos; incluir uma linha da fila por estado/tipo. Nos cenários de filas, desabilitar envio externo ou usar provedor simulado para impedir mensagens reais. Anotar apenas IDs fictícios e resultados sanitizados. Não guardar tokens em relatório.

Depois de configurar credenciais, executar a URL de teste ou ativar somente uma cópia de homologação expressamente autorizada. A URL de produção desta entrega continua inativa. Verificar no navegador o OPTIONS 204 sem Bearer, POST com Bearer, origem não autorizada sem liberação CORS, origem de desenvolvimento explícita, HTTPS/TLS válido, limite 429 e corpo excessivo 413. Testar também JSON inválido, método GET e indisponibilidade do n8n com JSON sanitizado no proxy. Confirmar que não há execução/payload persistido nem token em logs após os testes.

## Concorrência real e perda de resposta

`teste-concorrencia-homologacao.mjs` está preparado e **não foi executado**. Ele usa fetch nativo, duas respostas opostas em paralelo, exige exatamente uma 200 e uma 409, e repete a tentativa vencedora verificando os timestamps. Configurar variáveis em memória por mecanismo seguro:

```text
CONFIRMO_DADOS_FICTICIOS=SIM
COMPARECIMENTO_TEST_URL=https://<HOMOLOGACAO>/webhook/agenda24h/comparecimento/v1
COMPARECIMENTO_TEST_TOKEN=<TOKEN_FICTICIO_EM_MEMORIA>
COMPARECIMENTO_TEST_AGENDAMENTO=<UUID_FICTICIO_CONFIRMADO_COM_INICIO_PASSADO>
```

Executar `node teste-concorrencia-homologacao.mjs`. Não imprime token nem erro HTTP bruto. Não usar token em argumento de linha de comando ou salvar arquivo .env com credenciais reais. Após o teste, verificar exatamente uma transição, um evento, um log de auditoria, timestamp vencedor preservado e nenhum registro da tentativa oposta. Repetir em outro agendamento com duas respostas iguais: ambas 200, uma repetição, mesmo timestamp. Repetir com a mesma solicitacao_id e com IDs diferentes. Testar mesma chave simultânea em dois agendamentos: apenas um deles pode consumir a chave.

Para perda de resposta após commit, usar proxy de falhas de homologação que corte a resposta **depois** do banco concluir, sem interromper a transação. Registrar que a primeira resposta não chegou, conferir gravação por consulta administrativa e repetir o corpo exatamente. Esperado: 200, repeticao true e mesmas datas/contagem de eventos. Um simples abort imediato de fetch não comprova que houve commit.

Para corrida com fila, reservar lembrete em uma sessão e manter processando; comparecimento deve retornar 409 sem alterações. Finalizar envio simulado pelo consumidor e repetir: 200. Na ordem inversa, registrar comparecimento antes da reserva; a fila cancelada não pode ser reservada/enviada. Verificar itens travados e política de retry do consumidor, sem cancelar envios em trânsito às cegas.

## Falha transacional e critérios de aceite

Em homologação isolada, provocar falha de INSERT de auditoria ou indisponibilidade do banco. Esperado: nunca 200; nenhuma alteração parcial de status/fila/eventos/idempotência. Remover a falha, repetir a mesma tentativa e obter resultado único. Testar bloqueio acima de 3 s e deadlock controlado: erro sanitizado/retry, sem detalhes de SQL e sem falso sucesso.

Conferir em auditoria: empresa correta, agendamento correto, membro e usuário validados, anterior confirmado, novo concluido/faltou, horário do servidor e correlation_id igual à solicitação. Confirmar que pesquisas/recuperações não foram ativadas. Conferir o efeito de automações preexistentes de reativação antes da produção.

Não considerar concluído até: schema remoto comparado, permissões aprovadas, importação na versão instalada, credenciais de mínimo privilégio, HTTPS/CORS/limites, testes de concorrência real, login real e ausência de falso sucesso no portal. Depois disso, a ativação de produção ainda depende de autorização.
