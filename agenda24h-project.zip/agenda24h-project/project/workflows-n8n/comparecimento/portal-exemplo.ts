// Exemplo para adaptar ao portal; não aplicado ao código do portal.
// supabase deve ser o cliente existente COM login real habilitado.
export async function enviarComparecimento(
  supabase: { auth: { getSession(): Promise<any> } },
  webhookUrl: string,
  tentativa: { solicitacao_id: string; agendamento_id: string; resposta: 'sim' | 'nao' },
) {
  const { data, error } = await supabase.auth.getSession();
  if (error || !data.session?.access_token) throw new Error('Faça login para registrar o resultado.');
  // getSession obtém o token; a validação real ocorre no servidor.
  const response = await fetch(webhookUrl, {
    method: 'POST',
    redirect: 'error',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${data.session.access_token}` },
    body: JSON.stringify(tentativa),
    signal: AbortSignal.timeout(20000),
  });
  const result = await response.json();
  if (!response.ok || result.sucesso !== true) {
    // Usar result.codigo para conflito/horário/relogin, sem exibir erros SQL.
    throw Object.assign(new Error(result.mensagem || 'Não foi possível registrar o resultado.'), { codigo: result.codigo });
  }
  return result; // Atualizar UI somente com status, concluido_em e faltou_em retornados.
}
// Após a confirmação do usuário, criar UMA tentativa com crypto.randomUUID().
// Desabilitar ambos os botões enquanto aguarda. Em timeout, conservar tentativa.
// Reenviar exatamente solicitacao_id/agendamento_id/resposta; nunca gerar outro
// ID apenas porque a resposta HTTP se perdeu. Nunca fazer fallback simulado.
