begin read only;
select p.oid::regprocedure,p.prosecdef,p.proconfig,pg_get_userbyid(p.proowner) as proprietario
from pg_proc p where p.oid='public.registrar_comparecimento_workflow(uuid,uuid,uuid,text)'::regprocedure;
select r,has_function_privilege(r,'public.registrar_comparecimento_workflow(uuid,uuid,uuid,text)','EXECUTE') as executa,
has_table_privilege(r,'public.agendamentos','UPDATE') as atualiza_tabela,
has_column_privilege(r,'public.agendamentos','status','UPDATE') as atualiza_status
from unnest(array['anon','authenticated','service_role','agenda24h_comparecimento']) r;
-- Esperado: apenas agenda24h_comparecimento executa; anon/authenticated/login interno sem UPDATE.
-- service_role já pode ter privilégios preexistentes de escrita; a migration não os amplia.
select pg_get_userbyid(roleid) as papel,pg_get_userbyid(member) as membro from pg_auth_members
where member=(select oid from pg_roles where rolname='agenda24h_comparecimento');
-- Esperado: nenhum vínculo a outro papel.
select p.oid::regprocedure from pg_proc p join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public' and has_function_privilege('agenda24h_comparecimento',p.oid,'EXECUTE');
-- Revisar: somente a função nova entre as RPCs de negócio; funções PUBLIC preexistentes podem aparecer.
commit;
