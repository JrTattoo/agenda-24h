-- Executar SOMENTE no supabase-db / postgres. Sem dados de clientes ou segredos.
begin read only;
select current_database(), version();
select table_schema,table_name,column_name,udt_name,is_nullable
from information_schema.columns where table_schema='public' and table_name in
 ('agendamentos','membros_empresa','profissionais','agendamento_eventos','logs_auditoria','fila_mensagens')
order by table_name,ordinal_position;
select t.typname,e.enumlabel from pg_type t join pg_enum e on e.enumtypid=t.oid
where t.typname in ('membro_papel','agendamento_status','fila_mensagem_tipo','fila_mensagem_status') order by t.typname,e.enumsortorder;
select c.relname,c.relrowsecurity,c.relforcerowsecurity from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relname in ('agendamentos','membros_empresa','profissionais');
select tablename,policyname,roles,cmd,qual,with_check from pg_policies
where schemaname='public' and tablename in ('agendamentos','membros_empresa','profissionais');
select conrelid::regclass as tabela,conname,pg_get_constraintdef(oid) as definicao
from pg_constraint where conrelid in ('public.agendamentos'::regclass,'public.membros_empresa'::regclass,
 'public.agendamento_eventos'::regclass,'public.logs_auditoria'::regclass,'public.fila_mensagens'::regclass);
select tgrelid::regclass as tabela,tgname,pg_get_triggerdef(oid) from pg_trigger
where not tgisinternal and tgrelid in ('public.agendamentos'::regclass,'public.fila_mensagens'::regclass);
select p.oid::regprocedure,pg_get_functiondef(p.oid) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public' and p.proname in ('definir_atualizado_em','programar_lembretes_agendamento',
 'reservar_fila_mensagens','marcar_fila_mensagem_enviada','marcar_fila_mensagem_falhou','registrar_comparecimento');
select grantee,table_name,privilege_type from information_schema.table_privileges
where table_schema='public' and grantee in ('PUBLIC','anon','authenticated')
and table_name in ('agendamentos','agendamento_eventos','logs_auditoria','fila_mensagens');
select grantee,table_name,column_name,privilege_type from information_schema.column_privileges
where table_schema='public' and table_name='agendamentos' and grantee in ('PUBLIC','anon','authenticated');
select rolname,rolsuper,rolinherit,rolcreaterole,rolcreatedb,rolcanlogin,rolbypassrls
from pg_roles where rolname='agenda24h_comparecimento';
select to_regnamespace('comparecimento_interno') as schema_novo_deve_ser_null;
-- Funções de aplicação executáveis por PUBLIC precisam de revisão antes de criar login.
select p.oid::regprocedure from pg_proc p join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public' and exists
 (select 1 from aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a where a.grantee=0 and a.privilege_type='EXECUTE');
commit;
