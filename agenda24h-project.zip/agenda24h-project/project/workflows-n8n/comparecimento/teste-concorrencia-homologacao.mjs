// NÃO executado nesta entrega. Somente ambiente isolado e dados fictícios.
import { randomUUID } from 'node:crypto';
const { COMPARECIMENTO_TEST_URL:url, COMPARECIMENTO_TEST_TOKEN:token,
 COMPARECIMENTO_TEST_AGENDAMENTO:id, CONFIRMO_DADOS_FICTICIOS:ok }=process.env;
if(ok!=='SIM' || !url || !token || !id) throw new Error('Configure URL de homologação, token, agendamento fictício confirmado e CONFIRMO_DADOS_FICTICIOS=SIM.');
if(!url.startsWith('https://')) throw new Error('HTTPS obrigatório.');
const a={solicitacao_id:randomUUID(),agendamento_id:id,resposta:'sim'};
const b={solicitacao_id:randomUUID(),agendamento_id:id,resposta:'nao'};
async function send(body){
 try {
 const r=await fetch(url,{method:'POST',redirect:'error',signal:AbortSignal.timeout(20000),headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify(body)});
 const data=await r.json();return {http:r.status,data};
 } catch {return {http:0,data:{sucesso:false,codigo:'REDE_OU_TIMEOUT'}};}
}
const results=await Promise.all([send(a),send(b)]);
const summaries=results.map(r=>({http:r.http,sucesso:r.data.sucesso,codigo:r.data.codigo,status:r.data.status}));
console.log(JSON.stringify(summaries,null,2));
const winners=results.filter(r=>r.http===200&&r.data.sucesso===true);
if(winners.length!==1||results.filter(r=>r.http===409).length!==1) throw new Error('Resultado inesperado; verificar banco e logs sanitizados, sem repetir com dados reais.');
const winner=results[0].http===200?a:b;
const retry=await send(winner);
if(retry.http!==200||retry.data.repeticao!==true||retry.data.concluido_em!==winners[0].data.concluido_em||retry.data.faltou_em!==winners[0].data.faltou_em)throw new Error('Falha na repetição.');
console.log('Uma resposta venceu; oposta retornou 409; retry preservou timestamps. Conferir contagem de auditoria no banco.');
