# Comparecimento Agenda 24h — entrega preparada em 18/09/2026

Regra confirmada pelo responsável nesta tarefa: permitir **a partir de `inicio_em`**, inclusive. “Sim” conclui o atendimento; “Não” registra falta. A ausência de resposta não altera nada. Não existe liberação uma hora antes, reversão, correção ou confirmação antecipada neste recurso.

| Etapa | Situação |
|---|---|
| Arquivos preparados | Sim |
| Testes locais | 51 testes reportados pelo executor, todos passaram |
| Workflow importado no n8n | Sim, informado pelo responsável após a entrega |
| Migration aplicada no servidor | Não |
| Workflow ativo/publicado | Não |
| Teste integrado com login real | Não |
| Alteração do código do portal | Aplicada localmente em 19/09; envio desabilitado, não publicado |

Nenhuma conexão SSH, consulta remota, publicação, alteração de produção ou teste com clientes reais foi feita. A única instalação foi a dependência de testes local. A versão 2.36.8 do n8n é a observada na documentação, não foi inspecionada nesta entrega. O JSON usa nós nativos; a importação e execução nessa versão precisam de homologação.

## Arquivos

- `workflow-comparecimento.json`: importável, `active: false`, sem segredos, credenciais vinculadas ou dados fixados. URL de Auth deliberadamente inválida até configuração.
- `../../supabase/migrations/202609180017_comparecimento_workflow.sql`: função transacional e login dedicado sem senha inicial; não aplicada.
- `preflight-somente-leitura.sql` e `verificar-pos-aplicacao.sql`: conferência antes/depois.
- `proxy-nginx.conf.example`: modelo de HTTPS/CORS/preflight/limites/respostas de infraestrutura para adaptar ao proxy real. Não presume Nginx instalado.
- `portal-exemplo.ts`: chamada autenticada para adaptar ao portal.
- `TESTES.md`, `tests/` e `teste-concorrencia-homologacao.mjs`: evidências locais e roteiro pendente.

## Base inspecionada e diferenças do portal

Foram lidos o diagnóstico de comparecimento de 17/09, o inventário lógico do servidor e as migrations locais 001 (tabelas/enums), 002 (constraints), 003 (agenda/lembretes), 005 (privacidade), 006 (fila), 007 (consultas), 009 (grants), além das referências de RLS e satisfação 016. O schema remoto completo não está disponível: executar o preflight e comparar com as migrations antes de aplicar. A coleta anterior confirma os campos de status e timestamps, mas não substitui a conferência atual de auditoria, fila, gatilhos e privilégios.

O arquivo `C:/projetos/portal consulta agenda24h/supabase/migrations/20260917000000_rpc_registrar_comparecimento.sql` permanece intocado e **não deve ser aplicado**. Ele tem a consulta sem FROM, campo `me.papel` inexistente e referências às tabelas erradas. Também concede execução ao navegador, diferente do contrato desta entrega. Se alguma variante dessa RPC existir remotamente, interromper implantação e revisar/revogar seu caminho público mediante autorização; esta migration não a remove às cegas.

O serviço `src/services/comparecimento.ts` do portal ainda chama aquela RPC e libera uma hora antes. `src/hooks/use-auth.tsx` importa usuários simulados; componentes de agenda têm fallback simulado. Nenhum desses caminhos prova gravação real. Login real e remoção do falso sucesso são pré-requisitos para integração.

## Contrato HTTP

POST com `Content-Type: application/json` e `Authorization: Bearer <ACCESS_TOKEN_DA_SESSAO>`.

URLs-modelo, **não são URLs ativas**:

```text
Teste:    https://<HOST_HTTPS_N8N>/webhook-test/agenda24h/comparecimento/v1
Produção: https://<HOST_HTTPS_N8N>/webhook/agenda24h/comparecimento/v1
```

Conferir as URLs apresentadas pelo n8n, inclusive eventual prefixo/reverse proxy. A URL de teste só responde enquanto houver escuta de teste; a de produção exige publicação/ativação autorizada. Evitar testes manuais no editor com tokens reais, porque os itens podem ser exibidos em tempo real mesmo sem retenção.

```json
{
  "solicitacao_id": "00000000-0000-4000-8000-000000000001",
  "agendamento_id": "00000000-0000-4000-8000-000000000002",
  "resposta": "sim"
}
```

Os dois IDs precisam estar no formato UUID canônico; os exemplos são fictícios. Exatamente esses três campos são aceitos. `resposta` aceita exclusivamente `sim` e `nao`, sem normalização de texto. Ausência, null, array, objeto inválido, campo extra e UUID malformado dão 400. Campos de identidade enviados pelo cliente são rejeitados. O mesmo ID de solicitação, por usuário, não pode ser reutilizado com outro agendamento ou resposta após sucesso. Falhas não consomem a chave. Repetir a mesma resposta com uma nova chave também é idempotente em relação ao resultado e à auditoria.

```json
{
  "sucesso": true,
  "agendamento_id": "00000000-0000-4000-8000-000000000002",
  "status": "concluido",
  "concluido_em": "2026-09-18T12:00:00+00:00",
  "faltou_em": null,
  "repeticao": false,
  "mensagem": "Atendimento registrado como concluído."
}
```

Para `nao`, status `faltou`, `concluido_em: null`, `faltou_em` do servidor. Nunca derivar esses campos do relógio do navegador. Falhas seguem:

```json
{"sucesso":false,"codigo":"SEM_PERMISSAO","mensagem":"Não foi possível registrar o resultado."}
```

| HTTP | Códigos / situação |
|---|---|
| 200 | Transação confirmada ou repetição autorizada |
| 400 | ENTRADA_INVALIDA |
| 401 | NAO_AUTENTICADO: ausente, inválido, expirado, sessão anônima |
| 403 | SEM_PERMISSAO; ORIGEM_NAO_PERMITIDA no workflow |
| 405 / 413 / 415 | Método / tamanho / tipo de conteúdo inválidos |
| 409 | ANTES_DO_INICIO, ESTADO_INCOMPATIVEL, SOLICITACAO_REUTILIZADA, LEMBRETE_EM_PROCESSAMENTO |
| 429 | LIMITE_REQUISICOES no proxy |
| 500 | FALHA_INTERNA: resposta do banco fora do contrato |
| 503 | AUTENTICACAO_INDISPONIVEL ou GRAVACAO_INDISPONIVEL; proxy pode normalizar para SERVICO_INDISPONIVEL |

Agendamento inexistente e de outra empresa têm a mesma resposta 403. Não se retorna empresa, dono ou detalhes de SQL. 409 só ocorre após autorização. Timeout não prova que a transação falhou: reenviar a mesma tentativa. Todos os ramos previstos do workflow terminam no respondedor; falhas do processo n8n, parser, credencial ou proxy requerem a camada HTTP de contingência descrita abaixo. Nenhum sistema consegue entregar uma resposta se a conexão do cliente já caiu.

Exemplo com placeholders, somente após configurar homologação:

```bash
curl --request POST 'https://<HOST_HTTPS_N8N>/webhook-test/agenda24h/comparecimento/v1' \
  --header 'Authorization: Bearer <TOKEN_DE_USUARIO_FICTICIO>' \
  --header 'Content-Type: application/json' \
  --data '{"solicitacao_id":"<UUID_DA_TENTATIVA>","agendamento_id":"<UUID_FICTICIO>","resposta":"sim"}'
```

Não colar token real em arquivos, documentação, histórico de terminal, ferramentas de gravação de sessão ou prints. Em testes reais de homologação, obter token em memória de uma conta fictícia e usar o cliente do portal ou runner controlado.

## Autenticação, credenciais e rede

1. Importar o JSON inicialmente **inativo**, após autorização para operar a instância. Selecionar duas credenciais no editor, não inserir seus valores em nós.
2. HTTP Request “Validar token no Supabase”: credencial **Header Auth**, nome do header `apikey`, valor da chave **anon** do projeto correspondente. O Authorization vem do usuário. A chamada `GET /auth/v1/user` autentica de fato no Supabase Auth; não se decodifica JWT para confiar em seus campos. Só aceitar resposta 200 com UUID válido, `role=authenticated` e `is_anonymous=false`. Redirecionamentos estão desativados para não repassar token a outro host.
3. Trocar `https://CONFIGURAR-SUPABASE.invalid/auth/v1/user` por rota confirmada. O inventário identifica `supabase-kong:8000` (HTTP interno) e `supabase-kong:8443` (porta de TLS), não prova certificado/listener TLS funcional. **Preferir HTTPS com certificado válido**, seja via hostname real que resolva do container ou gateway interno com certificado para esse nome. Só usar `https://supabase-kong:8443` se certificado, SAN e CA realmente validarem esse nome. Instalar CA interna no cliente, se necessário. Não marcar “Ignore SSL Issues”. Esta entrega não escolhe HTTP silenciosamente nem inventa hostname ativo.
4. PostgreSQL: host esperado `supabase-db`, porta interna usual `5432` a conferir, banco **postgres**, usuário `agenda24h_comparecimento`, senha definida no servidor por canal seguro. **Nunca conectar ao container `postgres`**. Confirmar resolução e rota a partir do container n8n na `multiverso-network`, sem assumir que a porta publicada no host é a interna.
5. PostgreSQL também deve usar TLS com verificação de CA/hostname quando configurado. Se o container não oferecer TLS verificável, preparar essa configuração ou transporte seguro antes de habilitar; não desativar a validação para fazer o teste passar. Os testes locais não verificaram certificados nem conectividade.
6. O login tem somente CONNECT, USAGE e EXECUTE na nova função. Sem acesso direto às tabelas, BYPASSRLS, superusuário, criação de papel ou vínculo a outro papel. A função SECURITY DEFINER usa `search_path=pg_catalog`, objetos qualificados e parâmetros SQL. `service_role`, `authenticated`, `anon` e PUBLIC não executam a função. O ID validado pelo Auth é passado pelo workflow; quem possuir a credencial interna pode representar usuários, por isso ela precisa permanecer protegida e exclusiva desse workflow.
7. Conferir privilégios herdados de PUBLIC e funções preexistentes no preflight. Um novo login ainda herda PUBLIC; `NOINHERIT` não elimina isso. Não ativar se RPCs amplas estiverem acessíveis por PUBLIC. Não conceder o papel interno ao authenticator, anon ou authenticated. Não é necessário expor a função pelo PostgREST nem usar service_role.

A política requer profissional ativo para o usuário que atua como profissional. Administrador depende do vínculo ativo na empresa, inclusive para registrar histórico de um profissional desativado. Não há acesso extra para operador de plataforma ou outros perfis. O vínculo é escolhido pela empresa do agendamento, não por LIMIT 1.

## Atomicidade, auditoria e lembretes

A função bloqueia a chave lógica, bloqueia o agendamento e verifica vínculo/profissional com locks antes de gravar. Isso serializa respostas concorrentes e impede que a autorização seja invalidada no meio da gravação. Estado inicial aceito: `confirmado`; resultado oposto e cancelamento são conflitos. O relógio é do banco, comparado a `inicio_em`, com timestamps timestamptz. `status_presenca` e seus timestamps não são alterados. `atualizado_em` continua sob o gatilho existente, a conferir no preflight.

Cada transição produz um `agendamento_eventos` e um `logs_auditoria` com membro, usuário, data, transição e `solicitacao_id`/correlation_id. Não há token em SQL, auditoria ou idempotência. Repetições não criam novos eventos nem mudam datas. A pequena tabela privada `comparecimento_interno.solicitacoes` guarda somente a chave, parâmetros e resultado de sucesso; não substitui a auditoria do projeto. Não há rotina de expurgo nesta entrega: manter as chaves para preservar a garantia contra reutilização; definir retenção antes de adotar qualquer limpeza.

Lembretes `lembrete_24h`/`lembrete_2h` pendentes ou falhos são cancelados na mesma transação. Os enviados ficam preservados. Se algum estiver `processando`, responder 409 e **não registrar o comparecimento ainda**. Não alterar artificialmente `processando` para `cancelado`, pois o envio pode já ter ocorrido. Aguardar finalização real pelo consumidor ou reconciliação operacional de item travado, depois repetir a mesma tentativa. Não reclassificar mensagens sem verificar o provedor.

A função local `reservar_fila_mensagens` usa locks de linha; os de comparecimento serializam cancelamento versus reserva. Conferir que consumidores reais só enviam itens efetivamente reservados e não usam cópias antigas nem recriam lembretes após a conclusão. Qualquer consumidor fora desse contrato exige revisão antes de ativar. A geração local só agenda lembretes futuros, mas o SQL remoto e workflows reais precisam ser conferidos.

Não foram criados envios de satisfação ou recuperação. A função preexistente `gerar_reativacoes_pendentes` seleciona agendamentos concluídos: se algum workflow já a executar, uma conclusão poderá tornar-se elegível no futuro. Inventariar essas automações antes da ativação; esta entrega não as ativa nem as desativa.

## HTTPS, CORS, limites e retenção

O navegador acessa somente HTTPS. A validação aceita `https://portalagenda24h.multiverso360.com.br` e, enquanto o portal estiver publicado no GitHub Pages, `https://fluxomultiverso.github.io`. Como a opção CORS do Webhook nesta versão do n8n responde com uma única origem, ela deve ficar em `https://fluxomultiverso.github.io` durante a hospedagem atual. Ao migrar o portal para o domínio definitivo, trocar essa opção para `https://portalagenda24h.multiverso360.com.br`. O modelo de proxy aceita as duas origens exatas e responde OPTIONS sem exigir Bearer, com `Access-Control-Allow-Methods: POST, OPTIONS`, `Access-Control-Allow-Headers: Authorization, Content-Type`, Vary Origin e sem cookies/credentials. POST exige token mesmo sem Origin. Não usar `*`.

Não há origem de desenvolvimento presumida. Quando escolhida, adicioná-la explicitamente à lista do nó de validação, à opção Allowed Origins do Webhook e aos dois maps do proxy; criar rota de teste equivalente protegida. O proxy controla os cabeçalhos finais para não duplicar Allow-Origin. CORS limita browsers, não substitui autenticação.

Limites iniciais propostos no modelo: corpo 4 KiB, 10 POST/min/IP e burst 10, HTTP timeout 35 s no proxy, 8 s no Auth, 5 s de conexão ao banco, statement_timeout 10 s e lock_timeout 3 s no login. Ajustar após teste de carga e conferir IP real do Cloudflare apenas de proxies confiáveis. Não confiar em X-Forwarded-For arbitrário. Exigir também limite global de concorrência no n8n dimensionado à instância; o login tem teto de cinco conexões. O modelo ainda precisa ser validado no proxy efetivamente usado (há Cloudflare Tunnel documentado, Nginx não confirmado).

Workflow já configura salvar sucesso/erro = nenhum, execuções manuais = false e progresso = false. Conferir que a instância respeita essas opções. Configurações globais equivalentes, somente após revisar impacto nos outros workflows:

```text
EXECUTIONS_DATA_SAVE_ON_ERROR=none
EXECUTIONS_DATA_SAVE_ON_SUCCESS=none
EXECUTIONS_DATA_SAVE_ON_PROGRESS=false
EXECUTIONS_DATA_SAVE_MANUAL_EXECUTIONS=false
EXECUTIONS_DATA_PRUNE=true
EXECUTIONS_DATA_MAX_AGE=24
```

Pruning é defesa adicional para registros antigos, não substitui deixar de gravar. Tokens ainda passam em memória pelo trigger e HTTP node; não afirmar que nunca existem no n8n. Não fixar dados, exportar execuções, usar modo debug/trace ou encaminhar payload a error workflow/APM. Conferir logs de proxy, Auth, n8n, Redis/queue mode e crash dumps. Credenciais ficam no cofre criptografado do n8n, com chave de criptografia protegida e backup separado. Logs operacionais devem conter apenas código sanitizado, duração e identificador de solicitação quando apropriado, sem cabeçalhos/corpo. Não desativar TLS.

## Backup, aplicação e verificação — plano, não execução

1. Obter autorização de implantação; acesso SSH informado é `multiverso@192.168.0.4`, mas não foi testado. Fazer preflight primeiro em homologação e depois leitura no servidor. Os comandos abaixo são para o operador no Ubuntu, após transferir os arquivos a um diretório de implantação escolhido.
2. Executar `docker exec -i supabase-db psql -U postgres -d postgres -v ON_ERROR_STOP=1 < preflight-somente-leitura.sql`. Comparar colunas/enums/constraints/gatilhos/privilégios com as migrations; não publicar a saída sem revisar conteúdo de funções. Se divergirem, parar e ajustar o SQL, nunca adivinhar.
3. Fazer backup completo consistente antes da mudança: `docker exec supabase-db pg_dump -U postgres -d postgres -Fc > agenda24h-antes-comparecimento.dump`. Guardar em diretório restrito (umask 077), criptografado e com checksum. Roles/globals exigem backup separado restrito, pois podem conter hashes de senha; não anexar ao projeto. Guardar também definições de roles/grants, configuração do proxy e exportação sanitizada do workflow anterior. Testar restauração em banco isolado, não sobre produção.
4. Executar a migration **uma única vez** como postgres: `docker exec -i supabase-db psql -U postgres -d postgres -v ON_ERROR_STOP=1 < 202609180017_comparecimento_workflow.sql`. Ela tem BEGIN/COMMIT e falha se papel/schema já existirem. Não executar toda a pasta de migrations nem a migration antiga do portal. Não usar `--single-transaction` adicional desnecessário.
5. Em sessão interativa segura do psql (`docker exec -it supabase-db psql -U postgres -d postgres`), definir senha com `\password agenda24h_comparecimento`, fora de gravação de terminal; não usar ALTER ROLE com senha literal no histórico. Conferir pg_hba/TLS e restringir conexão à origem n8n conforme a rede real. Não ampliar permissões gerais.
6. Rodar `verificar-pos-aplicacao.sql`; revisar que nenhum browser executa a função, login interno não escreve diretamente, função pertence ao dono esperado e nenhum papel inesperado lhe dá acesso. Não concluir só porque a migration não deu erro.
7. Importar/configurar o workflow em homologação, proxy, credenciais e testes do `TESTES.md`. Usar apenas contas/dados fictícios. Uma importação bem-sucedida não é teste integrado. Produção continua inativa até autorização explícita para ativar.
8. Quando aprovado, publicar o workflow e conectar o portal real. Confirmar HTTPS, preflight, erros, retenção e relatório de testes; monitorar códigos sanitizados.

Rollback preferido: bloquear a rota, desativar workflow e revogar EXECUTE do login interno. Isso interrompe novos registros sem apagar resultados corretos nem auditoria. Não reverter status automaticamente. Se a implantação falhar antes do COMMIT, a migration inteira reverte. Se já houver uso, preservar tabela de idempotência e auditoria. Remover função/schema/login só com plano específico, checagem de dependências e autorização; não restaurar dump sobre produção para desfazer uma função. Backup completo é recurso de recuperação, não rollback automático de dados.

## Conectar os botões do portal

Implementar Supabase Auth real antes de habilitar o recurso. Substituir a chamada `supabase.rpc` em `src/services/comparecimento.ts` pelo POST do exemplo. A URL pode ser configuração pública; chave interna, senha e service_role nunca podem ir para variáveis VITE.

Exibir “O cliente compareceu?” com Sim/Não e confirmação antes do envio. Criar UUID depois da confirmação e preservar a tentativa em timeout. Desabilitar ambos os botões durante envio. Ajustar a indicação visual ao início previsto, retirando HORAS_ANTECIPACAO=1; a checagem definitiva permanece no servidor. Não concluir localmente, usar fallback simulado ou marcar falta por falta de resposta.

Após 200, usar os timestamps/status retornados e atualizar a consulta. Para 401, pedir novo login; para 403, negar sem revelar dados; para 409, explicar o código em mensagem segura e recarregar o agendamento autorizado. Em LEMBRETE_EM_PROCESSAMENTO, orientar tentativa posterior. Para timeout/503, estado é incerto: permitir repetir a mesma tentativa. Não trocar a resposta silenciosamente ou gerar nova solicitação a cada retry.

## Referências oficiais consultadas

- [Supabase getUser](https://supabase.com/docs/reference/javascript/auth-getuser): autenticação consultando o servidor Auth.
- [n8n PostgreSQL](https://docs.n8n.io/integrations/builtin/app-nodes/n8n-nodes-base.postgres/): query parametrizada.
- [n8n HTTP Request](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.httprequest/): resposta completa, timeout e tratamento HTTP.
- [n8n Respond to Webhook](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.respondtowebhook/): resposta após processamento.
- [n8n retenção de execuções](https://docs.n8n.io/hosting/configuration/environment-variables/executions/): configurações operacionais.

Essas referências sustentam o desenho; não substituem teste na versão instalada.
