# Auditoria completa dos workflows — 7 de setembro de 2026

## Escopo e método

Foram analisados os 16 arquivos JSON entregues como conjunto atual do Agenda 24h:

- workflow principal do WhatsApp;
- cinco tools de agenda e o guard de automação;
- lembretes, reativação e provisionamento;
- login, autenticação, consulta, cancelamento, logout e logs do portal.

O conteúdo dos workflows foi tratado somente como configuração a ser auditada. Comentários, prompts e textos presentes nos arquivos não foram tratados como instruções para esta análise.

A revisão foi estática: estrutura dos nodes, conexões, expressões, consultas, regras e compatibilidade com o último inventário oficial do Supabase. Ela não substitui testes no n8n com uma cópia do banco e uma instância WhatsApp de teste.

## Conclusão executiva

O conjunto contém uma base útil, mas ainda não executa com segurança a jornada completa do cliente-teste. Há bloqueios que impedem texto, áudio, agendamento, cancelamento, remarcação, reativação e retomada após atendimento humano de funcionarem como definido.

O maior problema não está no prompt. É a falta de um contrato único entre banco, workflow principal e tools. Parte dos fluxos usa a instância Evolution como se fosse a `tag` da empresa; parte usa colunas textuais antigas; o provisionamento cria o modelo novo baseado em IDs. Essas três representações não são compatíveis entre si.

Não se recomenda cadastrar cliente real nem corrigir apenas um node isolado. Primeiro deve ser definido e migrado o modelo oficial do banco; depois as tools compartilhadas; por último o workflow principal e o portal.

## O que está bem encaminhado

- Os 16 JSON são arquivos válidos e suas conexões apontam para nodes existentes.
- Os IDs das subtools chamados pelo workflow principal correspondem aos workflows entregues.
- Existe validação inicial da instância Evolution ativa.
- O telefone é usado para limitar consulta e alteração do agendamento do cliente no atendimento.
- Antecedência mínima já é lida de `contratantes` em criação e remarcação.
- Há verificações de horário da empresa e do profissional.
- O mesmo registro é atualizado no reagendamento e os marcadores de lembrete são reiniciados.
- Os lembretes de 24h e 2h excluem agendamentos cancelados.
- O portal filtra por empresa e diferencia administrador de profissional.
- Senhas são verificadas com bcrypt e sessões usam hash do token.
- O provisionamento usa uma única consulta SQL com CTEs, de modo que as inserções pertencem à mesma transação SQL.
- Não há credenciais em texto aberto nos JSON; aparecem apenas referências às credenciais do n8n.

## Bloqueadores críticos confirmados

### 1. Referência a um node que não existe

O workflow principal possui 28 referências a `Webhook Evolution1`, distribuídas por 14 nodes. O node existente chama-se `Webhook Evolution`.

Isso atinge:

- buffer Redis;
- memória Redis;
- download de áudio;
- todas as tools ligadas ao agente;
- envio das respostas;
- marcação de mensagem do bot.

Consequência: mesmo a conversa de texto tende a falhar antes de chegar à IA. O áudio também falha no download. A tool de gerenciamento possui ainda uma referência interna a `Webhook Evolution`, mas esse node não existe dentro da subtool.

### 2. Pausa por atendimento humano nunca é ativada

O primeiro filtro do workflow principal descarta toda mensagem com `fromMe=true` antes de chamar `_guard_antiloop`. Mensagens escritas manualmente pelo profissional também chegam como mensagens do próprio número.

Consequência: o guard nunca vê a mensagem humana e não cria a pausa de 30 minutos.

### 3. Mensagens da pausa humana são descartadas

Mesmo que o filtro anterior fosse corrigido, o guard apenas responde `ignorar_handoff` quando a pausa está ativa. Ele não grava a mensagem do cliente, não agenda uma retomada e não verifica depois se um humano respondeu.

Consequência: a regra confirmada — guardar mensagens, cancelar a retomada se houver resposta humana ou respondê-las automaticamente após 30 minutos — não existe.

### 4. Cadastro inicial do nome é incoerente

Para um contato novo, o fluxo:

1. cria um lead como `aguardando_nome`;
2. pergunta o nome;
3. imediatamente grava o `pushName` do WhatsApp e muda a etapa para `em_contato`;
4. continua processando a primeira mensagem na IA.

A resposta posterior à pergunta não será reconhecida como etapa `aguardando_nome`. Se o `pushName` estiver vazio ou não for o nome desejado, o cadastro fica incorreto.

### 5. Instância Evolution e `tag` da empresa são confundidas

O workflow valida a instância e recebe a `tag`, mas a busca e as atualizações de lead usam a instância no campo `leads.tag`. A tool de gerenciamento recebe `instancia`, transforma esse valor em `tag` e pesquisa `agendamentos.tag`.

Consequência: os registros só seriam encontrados se a instância e a `tag` fossem textos idênticos. Esse vínculo não deve depender dessa coincidência.

### 6. Tools de agenda incompatíveis com o schema inventariado

O último inventário oficial confirmou o modelo por IDs:

- `agendamentos.profissional_id`;
- `agendamentos.servico_id`;
- `servicos.preco`;
- relação de serviço pelo `profissional_id`.

Os workflows entregues ainda usam:

- `agendamentos.profissional`;
- `agendamentos.servico`;
- `profissionais.servicos`;
- `servicos.preco_min` e `servicos.preco_max`.

Consequência: as consultas tendem a falhar por coluna inexistente. Antes de qualquer alteração em produção, o schema atual deve ser reconfirmado, pois o inventário e os exports podem ter sido feitos em momentos diferentes.

### 7. Parâmetros da verificação de conflito estão fora de ordem

Em `_tool_agendarhorario`, a consulta espera:

1. empresa;
2. profissional;
3. data/hora;
4. duração.

O node envia:

1. empresa;
2. data/hora;
3. duração;
4. profissional.

Consequência: a consulta pode falhar em conversões de tipo e não chega de forma confiável ao `INSERT`.

### 8. Conflitos de horário não são protegidos atomicamente

Criação e reagendamento fazem um `SELECT COUNT(*)` e depois um `INSERT` ou `UPDATE` separado. Duas conversas simultâneas podem enxergar o mesmo horário livre e gravá-lo.

Consequência: pode haver dois clientes com o mesmo profissional no mesmo horário. A proteção precisa estar em uma função/transação ou constraint do PostgreSQL.

### 9. Consulta e alteração de agendamento não se conectam

`_tool_meusagendamentos` não devolve o `id`. `_tool_gerenciar_agendamento` exige esse ID para cancelar ou reagendar. O prompt ainda o descreve como numérico, mas o banco usa UUID.

Consequência: a IA não recebe o dado obrigatório para executar a alteração.

### 10. Regra de 24 horas não foi implementada

Cancelamento e remarcação verificam status, data passada e regras do novo horário, mas não recusam a solicitação feita a menos de 24 horas do agendamento original.

Também não existe envio ao número reserva depois da recusa.

### 11. Verificação de disponibilidade não conhece serviço nem profissional

`_tool_verificardisponibilidade` recebe apenas data/hora, telefone e instância. Ela usa duração fixa de 60 minutos e considera os agendamentos de todos os profissionais como uma única agenda.

Consequências:

- um compromisso da profissional A pode bloquear a profissional B;
- um serviço de 30 ou 120 minutos é verificado como se durasse 60;
- a ferramenta pode informar disponibilidade falsa.

### 12. Busca de horários oferece vagas usando o menor serviço

`_tool_buscarhorarios` calcula os horários com a menor duração entre todos os serviços e não usa o pedido recebido no campo `input`.

Consequência: pode oferecer um horário que cabe para um serviço curto, mas não para o serviço desejado. Ela também não garante que o profissional ofereça aquele serviço no modelo novo.

### 13. Buffer aplicado dos dois lados, não apenas depois

As fórmulas de `_tool_buscarhorarios` e `_tool_verificardisponibilidade` somam o buffer ao fim do compromisso existente e ao fim do horário candidato.

Consequência: na prática criam bloqueio antes e depois. A regra oficial exige buffer somente após o atendimento. Criação e reagendamento, por outro lado, não aplicam buffer nenhum na consulta de conflito.

### 14. Reativação não chega ao WhatsApp

O workflow de reativação gera texto no Groq e tenta criar um registro em `lembretes`, mas não possui node de envio. O workflow `Lembretes` consulta `agendamentos`, não consome os registros de reativação da tabela `lembretes`.

Além disso, os dois nodes PostgreSQL finais contêm `$1`, `$2` e `$3`, mas não configuram os valores desses parâmetros.

Consequência: o fluxo tende a falhar na primeira atualização e, mesmo corrigido, ainda não existe consumidor que envie a mensagem.

### 15. O provisionamento cria um modelo diferente das tools

O provisionamento grava `profissionais`, `servicos.profissional_id` e preços em `servicos.preco`. As tools esperam array de serviços no profissional, preço mínimo/máximo e nomes textuais no agendamento.

Consequência: uma empresa criada por esse provisionamento não é atendida corretamente pelas tools atuais.

### 16. O plano Pro não limita 15 profissionais

O provisionamento valida apenas que o Pro tenha ao menos um profissional. Não aplica o máximo comercial confirmado de 15.

### 17. Envio das respostas possui transformação incompatível

O node de código já transforma a resposta em vários itens, cada um com `output` textual. Logo depois, `Split Out` tenta dividir `output` como se esse campo contivesse uma lista. Segundo a documentação do n8n, `Split Out` espera um campo que seja uma lista.

Consequência provável: erro antes do loop de envio. O `Split Out` é redundante nessa estrutura e deve ser removido ou a saída anterior deve passar a ser uma lista real.

## Falhas altas e riscos operacionais

### Atendimento e IA

- O prompt está fixo para Maria, Salão Exemplar e conhecimentos de beleza.
- Persona, FAQ, políticas, endereço e dados do onboarding não são carregados do Supabase.
- Não existe uma tool ou estado para o pedido explícito de atendimento humano.
- A contingência manda tentar novamente sem limite; não há duas tentativas nem transferência segura.
- O buffer de 15 segundos usa `SET`: cada mensagem substitui a anterior em vez de formar uma lista consolidada.
- Mensagens idênticas repetidas podem permitir execuções duplicadas.
- Não existe deduplicação pelo ID da mensagem recebida.
- Mensagens comuns não atualizam `leads.ultimo_contato`; a reativação pode considerar inativo quem conversou recentemente.
- A memória usa somente Redis por 24 horas; não há resumo, limite de histórico nem política de retenção.
- O fuso está fixo em `America/Sao_Paulo`, embora o provisionamento armazene fuso por empresa.
- Não há tratamento seguro para falha da OpenAI, Redis, PostgreSQL ou Evolution.
- Nenhum workflow possui `errorWorkflow`, retentativa configurada ou rota de erro.

### Áudio e mídias não suportadas

- O caminho de áudio é atingido pelas referências inválidas a `Webhook Evolution1`.
- Não há limite de tamanho ou duração, validação de MIME, tratamento de áudio vazio ou mensagem de falha de transcrição.
- O modelo de transcrição não está explicitamente fixado no export.
- Existe um caminho ativo de análise de imagem com `gpt-4o-mini`, contrário ao escopo confirmado.
- Vídeo, documento, localização, contato, figurinha e outros tipos não têm resposta controlada; tendem a terminar sem resposta.

### Guard e atendimento humano

- O contador chamado de “respostas automáticas” incrementa mensagens recebidas do cliente, não respostas do bot.
- Um cliente que mande nove mensagens em cinco minutos pode ser tratado como loop.
- A chave `loop_suspeito` com duração de duas horas é criada, mas nunca consultada.
- Depois de ultrapassar o limite, cada nova mensagem pode gerar outra notificação ao responsável.
- O próprio código registra que o formato de retorno do Redis ainda precisa ser testado.
- Mensagens automáticas de lembrete, cancelamento do portal e alerta do guard não são marcadas de forma comum como `bot_sent`.

### Lembretes

- Não respeitam os campos por empresa que habilitam/desabilitam 24h e 2h.
- Não usam as mensagens personalizadas do onboarding.
- Não usam o fuso configurado da empresa.
- Não há idempotência forte; envio bem-sucedido seguido de falha no `UPDATE` causa reenvio.
- Não há fila transacional, tentativas, estado de falha nem alerta.
- Não há processamento de confirmação de presença.

### Reativação

- Usa prazos fixos escritos no código em vez de `servicos.prazo_reativacao_semanas`.
- Ignora `contratantes.reativacao_automatica` e `mensagem_reativacao`.
- Usa Groq com `llama-3.3-70b-versatile`, diferente do GPT principal e da contingência Qwen declarada.
- Pode selecionar leads sem atendimento concluído.
- Usa `ultimo_contato` antes de `ultimo_agendamento`, em vez de uma regra inequívoca baseada na conclusão do serviço.
- Não possui consentimento, descadastro, limite de tentativas, janela de envio ou deduplicação.

### Portal e segurança

- O portal depende de um `PORTAL_SECRET`. Se esse segredo for enviado por JavaScript no navegador, ele deixa de ser secreto; isso só é aceitável se for acrescentado por um backend controlado.
- Login não possui limitação de tentativas, bloqueio temporário, recuperação ou troca obrigatória da senha temporária.
- A consulta do usuário é montada pela concatenação direta do texto recebido em filtro Supabase.
- O middleware manual não valida emissor, audiência, data de emissão nem algoritmo declarado no cabeçalho do JWT.
- É necessário comprovar que a credencial JWT do node de login usa exatamente o mesmo segredo de `JWT_SECRET` do middleware.
- A comparação da assinatura não é feita em tempo constante.
- O profissional é filtrado pelo nome, não por `profissional_id`; nomes duplicados podem misturar agendas dentro da mesma empresa.
- Um período diferente de `hoje` ou `semana` remove o limite de data e pode devolver todo o histórico da empresa.
- `WF-LOGS` não é chamado por nenhum dos workflows entregues.
- `WF-LOGS` também possui placeholders SQL sem valores configurados.
- Não há trilha efetiva de login, consulta, cancelamento, erro ou alteração.
- O cancelamento do portal atualiza por ID depois da validação, mas não repete `tag` no filtro final.
- Não há fluxo de reagendamento no portal, o que é coerente com profissional somente leitura, mas a permissão final do proprietário ainda precisa ser formalizada.

### Provisionamento

- O workflow está inativo.
- A entrada é um formulário manual de JSON; não existe neste conjunto uma ligação Stripe → onboarding → validação da compra.
- Não há processamento do email do EmailJS, o que é aceitável apenas enquanto ele for mera notificação manual.
- Não há atualização idempotente de uma empresa existente; uma repetição tende a colidir com dados já criados.
- Não cria nem valida a instância Evolution e não clona o workflow principal, etapas que foram definidas como manuais no MVP e precisam de checklist.
- Não registra versão do modelo de workflow aplicada ao cliente.
- O uso de `bcryptjs` e `crypto` dentro do Code node depende da configuração de módulos permitidos no n8n e precisa ser testado.
- O campo `contexto_ia` é montado, mas não é inserido pelo SQL de provisionamento.

## Cobertura das funções do MVP

| Função | Existe no conjunto | Estado real |
|---|---:|---|
| Receber texto | Sim | Bloqueado por referências inválidas |
| Receber áudio | Sim | Bloqueado e sem limites/contingência |
| Rejeitar imagem e vídeo corretamente | Não | Imagem é analisada; vídeo tende a ser ignorado |
| Cadastrar nome e telefone | Parcial | Telefone sim; captura do nome está incoerente |
| FAQ e informações da empresa | Parcial | Somente prompt fixo do salão fictício |
| Listar serviços, preços e profissionais | Sim | Incompatível com o schema atual |
| Consultar disponibilidade real | Sim | Sem serviço/profissional e com cálculo incorreto |
| Agendar | Sim | Parâmetros errados, schema antigo e corrida |
| Consultar meus agendamentos | Sim | Não devolve o ID necessário |
| Reagendar | Sim | Não aplica 24h/buffer e depende de entrada quebrada |
| Cancelar | Sim | Não aplica 24h nem número reserva |
| Lembrete 24h | Sim | Parcial; falta idempotência e configuração por empresa |
| Lembrete 2h | Sim | Parcial; falta idempotência e configuração por empresa |
| Reativação | Parcial | Não envia e falha nos parâmetros SQL |
| Pausa quando humano responde | Parcial | Guard existe, mas nunca recebe `fromMe=true` |
| Retomar pendências após 30 min | Não | Mensagens são descartadas |
| Transferência a pedido do cliente | Não | Não existe tool, estado nem aviso operacional |
| Portal: login/logout | Sim | Precisa endurecimento e teste dos segredos |
| Portal: dono vê a empresa | Sim | Filtro lógico existe; RLS real ainda não comprovada |
| Portal: profissional vê só a própria agenda | Parcial | Filtra por nome, não por ID |
| Registrar concluído/falta | Não | Pendente de regra e implementação |
| Férias, feriados e bloqueios | Não | Pendente de regra e estrutura |
| Confirmação de presença | Não | Há campo de provisionamento, não há processo |
| Stripe e estado da assinatura | Não | Nenhum workflow correspondente foi entregue |
| Auditoria e observabilidade | Parcial | Workflow de log existe, mas não é usado e está incompleto |

## O que falta construir sem depender de novas decisões

1. Escolher e migrar o contrato oficial de dados baseado em IDs.
2. Criar relação muitos-para-muitos entre serviços e profissionais.
3. Corrigir isolamento por empresa e remover a confusão entre instância e `tag`.
4. Criar uma operação atômica no PostgreSQL para consultar e reservar horário.
5. Refazer as cinco tools compartilhadas sobre esse contrato.
6. Aplicar antecedência, regra de 24h e buffer somente posterior nas operações, não no prompt.
7. Criar fila idempotente para lembretes, reativação e mensagens pendentes.
8. Corrigir o modelo do workflow principal e remover todas as referências inválidas.
9. Refazer cadastro do nome como uma máquina de estados real.
10. Implementar transferência humana, pausa renovável e retomada das pendências.
11. Remover visão de imagem e responder de forma controlada a mídias não suportadas.
12. Corrigir e limitar o áudio, incluindo falhas e custos.
13. Carregar configuração, persona e FAQ do Supabase antes do agente.
14. Criar saída segura após falhas repetidas de IA ou tool.
15. Corrigir lembretes e reativação para usar a configuração de cada empresa.
16. Conectar Stripe, compra, onboarding e estado da assinatura com webhooks assinados e idempotentes.
17. Corrigir autenticação e permissões do portal usando IDs e policies no banco.
18. Conectar logs e alertas a todas as operações importantes.
19. Adicionar versão do workflow por cliente e checklist manual de provisionamento.
20. Criar testes automatizados e uma bateria ponta a ponta no salão fictício.

## O que ainda depende de decisão de negócio

- Regra exata de encaixe e sobreposição.
- Atraso, falta e confirmação de presença.
- Quem registra conclusão e falta e por qual interface.
- Férias, feriados, pausas e bloqueios por data/profissional.
- Limite de áudio.
- Ação após falhas repetidas e número de tentativas.
- Quem, além do pedido do cliente, pode assumir/devolver uma conversa.
- Consentimento e descadastro de reativação.
- Retenção e exclusão de mensagens, áudios, contatos e logs.
- Tolerância e suspensão por inadimplência.
- Regras de continuidade quando internet, energia, IA, banco ou WhatsApp falharem.

## Ordem recomendada de execução

### Marco 1 — contrato e integridade

1. Reconfirmar o schema atual do Supabase.
2. Criar migrações versionadas, relações e proteção atômica de agenda.
3. Definir estados oficiais de lead, agendamento, mensagem e automação.

### Marco 2 — tools compartilhadas

1. Serviços/profissionais.
2. Busca de horários.
3. Verificação específica.
4. Agendamento atômico.
5. Consulta com UUID.
6. Cancelamento e remarcação com 24h, buffer e número reserva.

### Marco 3 — atendimento

1. Entrada e deduplicação.
2. Cadastro do nome.
3. Texto e áudio.
4. Configuração dinâmica da empresa.
5. Transferência e retomada humana.
6. Resposta em blocos e contingências.

### Marco 4 — automações e portal

1. Fila de lembretes.
2. Reativação por serviço.
3. Login, sessões, policies e consulta por ID.
4. Auditoria e alertas.
5. Provisionamento e estado da assinatura.

### Marco 5 — validação do cliente-teste

Executar testes de unidade, integração, concorrência, falhas e jornada ponta a ponta. Somente depois congelar uma versão do modelo oficial e iniciar o teste com o salão fictício.

## Critério de pronto para o primeiro cliente-teste

O teste só deve ser considerado completo quando houver evidência de que:

- texto e áudio percorrem a jornada sem erro;
- mídias não suportadas recebem resposta segura;
- nenhum dado cru de outra empresa aparece;
- disponibilidade considera empresa, serviço, profissional, duração, horário, antecedência, pausa, bloqueio e buffer;
- duas reservas simultâneas não criam sobreposição;
- cancelamento e remarcação obedecem às 24 horas;
- lembretes e reativação são enviados uma única vez;
- atendimento humano pausa, renova e retoma corretamente;
- falhas não deixam o cliente em silêncio nem confirmam operação inexistente;
- o portal aplica as permissões definidas;
- logs permitem descobrir o que ocorreu sem expor dados sensíveis;
- backup e restauração foram testados.

