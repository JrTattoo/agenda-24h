# Auditoria dos workflows de agendamento

## Escopo

Comparação entre:

- O inventário estrutural do PostgreSQL/Supabase coletado em 5 de setembro de 2026.
- O relatório sanitizado dos 25 workflows exportados do n8n na mesma data.

Esta é uma análise de leitura. Nenhum workflow ou registro de produção foi alterado.

## Resultado da coleta

A coleta foi concluída corretamente e encontrou 25 workflows: 16 ativos e 9 inativos.

O relatório original foi muito extenso porque incluiu o mapa de nós e conexões. O arquivo sanitizado foi criado no servidor em:

`/home/multiverso/inventario-consultas-n8n-20260905-203113.txt`

## Workflows ativos diretamente relacionados ao Agenda 24h

| Workflow | ID | Função aparente |
|---|---|---|
| `_guard_antiloop` | `E1J8ipZIHaHSz5jS` | Evitar eco, loops e respeitar atendimento humano |
| `_tool_agendarhorario` | `teXOkszBeyohMPnq` | Criar agendamento |
| `_tool_buscarhorarios` | `sZUUAGbGmvUqxxMA` | Listar profissionais, serviços e horários |
| `_tool_gerenciar_agendamento` | `6dxM1S0kEqzUWLGs` | Reagendar ou cancelar |
| `_tool_meusagendamentos` | `W7aRybzcOtdilAxa` | Consultar agenda do cliente |
| `_tool_verificardisponibilidade` | `pUl1yzoy20bsqOmg` | Verificar data e horário específicos |
| `Lembretes` | `AcWN9kwm4xWJ8n8S` | Enviar lembretes de 24h e 2h |
| `Reativação de Clientes` | `pN4IQEWQBDUTJ3kO` | Selecionar e contatar clientes inativos |
| `WF-AUTH-MIDDLEWARE` | `sT9CGoILxxuEjpW7` | Validar sessão do portal |
| `WF-CANCELAR-AGENDAMENTO` | `KNLH6DBTDbrKcurm` | Cancelamento pelo portal |
| `WF-CONSULTAR-AGENDA` | `D0jqw8PTewNwSQEC` | Consulta da agenda pelo portal |
| `WF-LOGIN` | `UgthfnssMEVlfJMI` | Login no portal |
| `WF-LOGOUT` | `0LmttbNQ6xBMxuJZ` | Encerrar sessão |
| `WF-LOGS` | `mLqvALVWcO1bLKkR` | Registrar auditoria |
| `WF1 - Principal Agenda24h (OpenAI)` | `SNMcE53k98RnqKNG` | Atendimento principal via WhatsApp e IA |

O workflow `MCP` também está ativo, mas sua finalidade precisa ser esclarecida.

## Causa estrutural mais provável

Há divergência entre a versão do schema do banco e a versão das consultas presentes nos workflows ativos.

### Schema atual confirmado

`agendamentos` possui:

- `profissional_id`
- `servico_id`

Não foram encontradas as colunas textuais:

- `profissional`
- `servico`

`profissionais` não possui a coluna `servicos`.

`servicos` possui `preco`, mas não possui:

- `preco_min`
- `preco_max`

### Consultas ainda usando o modelo antigo

Os workflows ativos consultam ou gravam:

- `agendamentos.profissional`
- `agendamentos.servico`
- `profissionais.servicos`
- `servicos.preco_min`
- `servicos.preco_max`

Essas consultas tendem a falhar com erros de coluna inexistente no schema inventariado.

## Problemas confirmados por workflow

### `_tool_agendarhorario`

#### Busca de serviço incompleta

A consulta retorna apenas `nome` e `duracao_min`. Ela não retorna `servicos.id`, embora o agendamento atual exija `servico_id`.

#### Busca de profissional incompleta

A consulta retorna nome e horários, mas não retorna `profissionais.id`, embora o agendamento exija `profissional_id`.

#### Parâmetros da consulta de conflito estão fora de ordem

A ordem enviada pelo nó é:

1. `tag`
2. data/hora desejada
3. duração
4. nome do profissional

A consulta interpreta:

1. `tag`
2. profissional
3. data/hora
4. duração

Consequências prováveis:

- A data é comparada com o campo de profissional.
- A duração é convertida para timestamp.
- O nome do profissional é convertido para inteiro.

Mesmo que a coluna antiga `profissional` ainda existisse, essa consulta continuaria incorreta.

#### Inserção usa colunas removidas

O `INSERT` tenta gravar `profissional` e `servico`. O schema atual exige `profissional_id` e `servico_id`.

#### Condição de corrida continua possível

O workflow primeiro executa `SELECT COUNT(*)` e depois faz um `INSERT`. Duas execuções simultâneas ainda podem passar pela verificação antes que qualquer uma grave o horário. A proteção definitiva precisa ser atômica no PostgreSQL.

### `_tool_buscarhorarios`

A consulta de profissionais seleciona `servicos`, coluna que não existe em `profissionais`.

A consulta de serviços seleciona `preco_min` e `preco_max`, enquanto o schema atual possui apenas `preco`.

A consulta de agendamentos ocupados seleciona `profissional` e `servico`, colunas ausentes no schema atual. Ela precisa usar os IDs e joins com `profissionais` e `servicos`.

### `_tool_verificardisponibilidade`

A entrada `data_hora_iso` está corretamente mapeada no workflow principal ativo. Porém, a ferramenta recebe apenas data/hora, telefone e instância; não recebe explicitamente serviço nem profissional.

Sem serviço e profissional, a verificação não conhece de forma confiável:

- A duração necessária.
- A agenda do profissional escolhido.
- O buffer aplicável ao atendimento.

Além disso, a consulta de conflitos busca `profissional` e `servico` nas colunas antigas.

### `_tool_meusagendamentos`

A consulta usa as colunas antigas `servico` e `profissional`.

Ela também não retorna `a.id`, embora `_tool_gerenciar_agendamento` exija que essa ferramenta forneça o `agendamento_id`. Assim, o fluxo prometido à IA não entrega o identificador necessário para cancelar ou reagendar.

### `_tool_gerenciar_agendamento`

A descrição fornecida à IA chama `agendamento_id` de “ID numérico”, mas a chave real do banco é UUID.

A busca inicial utiliza `servico` e `profissional`, colunas antigas.

A consulta de conflito do reagendamento também usa `profissional` e mantém a separação vulnerável entre “verificar” e “atualizar”.

Regra definida: quando o cliente solicita e confirma a remarcação, o mesmo agendamento deve ser atualizado e continuar confirmado. A tool deve alterar data/hora, invalidar lembretes antigos, programar os novos e preservar um histórico de auditoria da mudança.

Os comandos finais de atualização filtram apenas pelo ID. Embora exista uma validação anterior por empresa e telefone, incluir novamente o escopo no `UPDATE` oferece defesa adicional.

### `Lembretes`

A consulta seleciona `a.servico` e `a.profissional`, colunas antigas.

Os marcadores são atualizados depois do envio. Ainda é necessário garantir idempotência quando a mensagem é enviada, mas a atualização falha ou o workflow é repetido.

As janelas encontradas são:

- Lembrete de 24h: entre 23h e 25h antes do atendimento.
- Lembrete de 2h: entre 1h45 e 2h15 antes do atendimento.

É necessário confirmar a frequência do gatilho para verificar se essas janelas não permitem envios duplicados ou perdas.

### `Reativação de Clientes`

A busca lateral do último agendamento seleciona `servico`, coluna antiga.

O workflow considera candidatos com último contato superior a 20 dias ou sem último contato. Depois, muda a etapa para `reativacao` e agenda uma mensagem para uma hora depois.

Ainda falta comprovar que o prazo individual `servicos.prazo_reativacao_semanas` é aplicado corretamente pelo nó de código “Filtrar por Prazo do Serviço”.

### Workflow principal ativo

`WF1 - Principal Agenda24h (OpenAI)` está ativo e aponta para as cinco ferramentas listadas neste documento.

O mapeamento de `data_hora_iso` está presente tanto para confirmação quanto para verificação de disponibilidade. O nome do cliente também está mapeado de forma simples no workflow ativo. Portanto, os mapeamentos defeituosos observados em versões antigas não devem ser confundidos com a versão atualmente ativa.

Entretanto, o workflow ativo ainda chama ferramentas cujas consultas estão incompatíveis com o schema atual.

### Áudio no workflow principal

O atendimento deverá compreender texto e áudio. Como cada empresa terá um workflow principal próprio, o caminho de transcrição de áudio precisa fazer parte do modelo oficial usado para criar esses workflows.

Embora o inventário tenha encontrado o nó `OpenAI - Transcrever Audio`, seu funcionamento completo ainda não foi validado. A adaptação deverá confirmar roteamento, download e validação do arquivo, modelo utilizado, tratamento de erro, privacidade, custo e continuidade correta da conversa.

Imagens e vídeos não serão suportados. O nó antigo `OpenAI - Analisar Imagem` deverá ser removido ou desativado no modelo oficial. Esses formatos devem receber uma resposta controlada pedindo ao cliente que use texto ou áudio, sem chamada à IA de visão.

## Versões duplicadas e risco operacional

Foram encontradas várias versões do workflow principal:

- `Imperio Beauty - Principal` — inativo.
- `My workflow` — inativo.
- `WF1 - Principal` — inativo.
- `WF1 - Principal Agenda24h (OpenAI)` — ativo.
- `WF1 - Principal copy` — inativo.
- `WF1 - Principal MV-teste` — inativo.

Também há três versões de provisionamento, todas inativas.

Manter versões antigas pode ser útil temporariamente, mas aumenta o risco de editar, ativar ou copiar a versão errada. Depois de backup e comparação, elas devem ser nomeadas como arquivo histórico ou exportadas para controle de versão.

## Ordem recomendada de correção

1. Não alterar o schema para recriar automaticamente as colunas antigas.
2. Confirmar que `profissional_id`, `servico_id` e `preco` representam o modelo desejado.
3. Corrigir `_tool_buscarhorarios` para trabalhar com IDs e joins.
4. Corrigir `_tool_verificardisponibilidade` para receber serviço, profissional e data/hora.
5. Corrigir `_tool_agendarhorario`, incluindo a ordem dos parâmetros e o `INSERT` com IDs.
6. Implementar proteção atômica contra sobreposição no PostgreSQL.
7. Corrigir `_tool_meusagendamentos` para retornar o UUID do agendamento.
8. Corrigir cancelamento e reagendamento usando UUID e escopo de empresa/telefone.
9. Atualizar lembretes e reativação para usar joins por IDs.
10. Criar testes de ponta a ponta antes de reativar qualquer versão modificada.
11. Adicionar o fluxo de recusa e encaminhamento para o número reserva quando cancelamento ou remarcação forem solicitados dentro das últimas 24 horas.

## Testes mínimos necessários

- Consultar serviços e preços existentes.
- Consultar profissionais disponíveis.
- Verificar horário livre.
- Verificar horário ocupado.
- Criar um agendamento válido.
- Tentar criar dois agendamentos simultâneos no mesmo horário.
- Listar os agendamentos do telefone e obter o UUID.
- Reagendar para horário livre.
- Recusar reagendamento para horário ocupado.
- Cancelar apenas agendamento pertencente à empresa e ao telefone corretos.
- Enviar lembrete uma única vez.
- Não enviar lembrete de agendamento cancelado.
- Selecionar reativação pelo prazo do serviço.
- Impedir reativação de cliente que recusou contato.

## Estado do diagnóstico

A coleta solicitada foi concluída. A divergência entre workflows e schema é uma causa concreta e prioritária. Para preparar correções seguras, ainda são necessários os códigos dos nós de validação e as definições completas das views/funções do banco.
