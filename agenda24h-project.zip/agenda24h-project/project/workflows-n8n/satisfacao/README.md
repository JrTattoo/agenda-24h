# Pesquisa de satisfação e convite Google

Este pacote depende das migrations `202609230020_pesquisa_satisfacao_enums.sql` e `202609230021_pesquisa_satisfacao_operacao.sql`. Os dois workflows permanecem inativos após importação.

`workflow-gerador-e-expiracao.json` executa a cada cinco minutos e somente cria pesquisas elegíveis ou encerra as que venceram. `workflow-dispatcher.json` reserva mensagens da pesquisa, revalida a elegibilidade, envia pelo Evolution e confirma o resultado. O nó HTTP não deve receber tentativas automáticas: timeout ou resposta ambígua deve permanecer em `processando` para conciliação manual antes de qualquer reenvio.

Antes de importar, criar uma credencial PostgreSQL que use um papel de serviço restrito às RPCs da pesquisa e uma credencial Header Auth da Evolution. Configurar a URL real da Evolution no nó **Enviar WhatsApp**. Nenhuma senha, chave de API ou URL de produção está incluída nos exports.

O workflow principal de entrada deve chamar `processar_resposta_pesquisa(empresa_id, cliente_id, mensagem_id, conteudo_texto)` logo depois de `registrar_mensagem_entrada`. Quando a resposta retornar `registrada`, `ambigua`, `fora_do_prazo` ou `repetida`, ele não deve encaminhar aquela mensagem à IA. Os comandos `PARAR PESQUISA` e `PARAR GOOGLE` também são tratados por essa RPC.

Para cada empresa, um administrador precisa preencher `pesquisa_satisfacao_configuracoes`, ativar a pesquisa e registrar as preferências do cliente. A escolha conservadora já documentada permanece: clientes existentes começam sem adesão (`aceita_pesquisa_satisfacao=false` e `aceita_convite_google=false`).

## Homologação

1. Usar uma empresa, cliente e número de WhatsApp de teste.
2. Criar um agendamento e registrá-lo como concluído.
3. Habilitar a configuração, as preferências e atraso zero para a empresa de teste.
4. Confirmar que o gerador cria uma única pesquisa e uma mensagem na fila.
5. Confirmar que o dispatcher envia uma vez, registra `enviada_em` e cria o convite Google sem consultar a nota.
6. Testar nota válida, nota fora da escala, `PARAR PESQUISA`, `PARAR GOOGLE`, expiração e execução repetida do cron.
7. Conferir no portal pesquisas enviadas, respostas, nota média e convites Google enviados. O painel não informa avaliações publicadas no Google.
