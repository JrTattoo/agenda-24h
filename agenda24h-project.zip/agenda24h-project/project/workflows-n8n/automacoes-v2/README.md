# Lembretes e reativação pós-atendimento — adaptação V2

Arquivos para **homologação**, ambos `active: false`. Preservam somente as **referências** a credenciais que já constavam nos exports originais; não incluem valores de senha/chave:

- `json/lembretes-v2.json`
- `json/reativacao-pos-atendimento-v2.json`

Os exports originais em Downloads não foram alterados. Nada foi importado no n8n ou aplicado no Supabase por esta entrega.

## Mudanças em relação aos exports antigos

Lembretes não consultam `contratantes`, `leads`, `tag`, `data_hora` ou flags `lembrete_*_enviado`. A agenda V2 já cria itens `lembrete_24h` e `lembrete_2h` em `fila_mensagens` quando um agendamento é criado ou remarcado. O novo consumidor, a cada minuto, reserva somente esses dois tipos com `FOR UPDATE SKIP LOCKED`, monta a mensagem com o fuso da empresa, revalida o agendamento e envia pela instância Evolution correspondente. Só confirma `enviado` com ID retornado pela Evolution. Se o retorno for ambíguo ou não houver ID, o item permanece `processando` para conciliação manual, **sem reenvio cego**.

A reativação antiga pesquisava inatividade em `leads`, tinha prazo fixo por nome de serviço, gerava texto pelo Groq e gravava `lembretes`. O novo fluxo, a cada cinco minutos, gera itens idempotentes em `fila_mensagens` somente para o atendimento **concluído mais recente** de cada cliente, após `servicos.prazo_reativacao_dias`, quando a configuração da empresa e o consentimento do cliente permitem. Não envia se há outro agendamento futuro confirmado. Revalida tudo antes do HTTP e usa mensagem determinística. Configurações não definidas não recebem prazo presumido.

Ambos exigem empresa ativa, telefone do cliente, respeito à janela de envio da empresa quando configurada e resultado elegível. O relógio para a janela usa `empresas.fuso_horario`. Os fluxos são compartilhados entre empresas, mas cada item leva sua `empresa_id` e `instancia_evolution` do banco. O agendamento é a fonte de verdade, não o texto da mensagem.

## Antes de importar/ativar

1. Fazer backup dos exports ativos e identificar todos os consumidores atuais de `fila_mensagens`. **Não ativar em paralelo** com consumidor genérico que reserve `lembrete_24h`, `lembrete_2h` ou `reativacao`, inclusive `reservar_fila_mensagens()` sem filtro de tipo.
2. Confirmar em leitura que a base V2 tem `fila_mensagens`, `contexto` (para reativação), `empresa_configuracoes`, `servicos.prazo_reativacao_dias`, funções `marcar_fila_mensagem_enviada` e permissões da credencial PostgreSQL **já presente nos exports originais**: `Postgres account` (`rKBK9lfP7PQ1sCNO`). Este pacote não cria papéis, credenciais nem concede acesso. Se essa conexão não alcançar o banco atual, **não ativar**; diagnosticar o vínculo existente primeiro.
3. O nó HTTP reutiliza a referência `Header Auth account` (`d1FKH88e0LqiyrFZ`) e o endpoint `https://evolution.multiverso360.com.br` do export original de lembretes. A mesma referência aparecia **também no nó Groq** do export antigo de reativação; por isso **não está comprovado** que seja uma chave Evolution válida. Conferir no n8n, sem exibir a chave. Se não for a credencial Evolution, uma credencial apropriada será necessária antes de ativar; nenhuma foi inventada neste pacote.
4. Importar os dois arquivos como workflows novos e inativos. Conferir se o n8n preservou as duas referências, as expressões, parâmetros PostgreSQL, `IF`, link de itens e corpo HTTP na versão instalada. O número é convertido de E.164 (`+55...`) para dígitos no envio; confirmar o formato aceito pela Evolution instalada.
5. Testar com empresa/cliente/agendamento fictícios: 24 h, 2 h, remarcação, cancelamento, falta/conclusão, item duplicado, empresa suspensa, descadastro, novo agendamento, janelas de envio e duas execuções concorrentes. Testar falha HTTP, timeout, 2xx sem `key.id` e reconciliação de `processando` antes de qualquer reenvio manual.
6. Ativar somente depois da homologação e observar fila `pendente`, `processando`, `enviado`, `falhou`, `cancelado`. A execução local não testou n8n nem WhatsApp real.

**Limite de escopo:** este fluxo de reativação cobre o retorno após atendimento concluído. A segunda reativação, do **cliente que faltou**, continua pendente; falta definir prazo/configuração de elegibilidade e registrar separadamente sua conversão. Não rotular este arquivo como cobertura das duas modalidades.

## Segurança operacional e limites

- A reserva de fila e o envio HTTP não formam uma transação única. Há uma pequena janela entre revalidação e envio; homologar cancelamento/remarcação concorrente. Nos contratos atuais, alteração de agendamento com lembrete `processando` pode ser recusada até conciliação.
- Itens `processando` não voltam automaticamente a `pendente`: uma falha/timeout pode ter enviado a mensagem. Conferir a Evolution antes de alterar estado.
- Itens `pendente` que perderam elegibilidade não são enviados, mas este pacote não faz limpeza geral da fila. Definir rotina operacional de cancelamento/reconciliação após inspecionar os consumidores existentes.
- O retorno bem-sucedido da API não comprova entrega no WhatsApp, somente aceitação com ID. Não contabilizar como entregue sem confirmação do provedor.

## Teste local

`node gerar.mjs` regenera os exports. `node testar.mjs` verificou estrutura, SQL com PostgreSQL embarcado, cancelamento de lembrete, geração idempotente de reativação e descadastro antes do envio. Resultado em 23/09/2026: **aprovado**. Não foram executadas chamadas ao servidor, à Evolution ou ao Supabase real.
