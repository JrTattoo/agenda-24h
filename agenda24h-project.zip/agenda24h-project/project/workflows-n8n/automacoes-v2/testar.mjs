import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { PGlite } from '../comparecimento/node_modules/@electric-sql/pglite/dist/index.js';

const read = (name) => JSON.parse(readFileSync(new URL('json/' + name, import.meta.url), 'utf8'));
const reminder = read('lembretes-v2.json');
const revival = read('reativacao-pos-atendimento-v2.json');
const query = (wf, name) => wf.nodes.find(n => n.name === name).parameters.query;
for (const wf of [reminder, revival]) {
  assert.equal(wf.active, false);
  for (const n of wf.nodes) {
    if (n.type === 'n8n-nodes-base.postgres') assert.equal(n.credentials?.postgres?.id, 'rKBK9lfP7PQ1sCNO');
    if (n.type === 'n8n-nodes-base.httpRequest') {
      assert.equal(n.credentials?.httpHeaderAuth?.id, 'd1FKH88e0LqiyrFZ');
      assert.ok(n.parameters.url.includes('https://evolution.multiverso360.com.br/message/sendText/'));
    }
  }
  assert.ok(wf.nodes.every(n => !JSON.stringify(n.parameters).includes('contratantes')));
  assert.ok(wf.nodes.every(n => !JSON.stringify(n.parameters).includes('leads')));
  for (const n of wf.nodes) if (n.type === 'n8n-nodes-base.code') new Function(n.parameters.jsCode);
  for (const outputs of Object.values(wf.connections)) for (const branch of outputs.main) for (const edge of branch) assert.ok(wf.nodes.some(n => n.name === edge.node));
}

const db = new PGlite();
const id = n => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
try {
  await db.exec('CREATE SCHEMA auth; CREATE ROLE anon; CREATE ROLE authenticated; CREATE ROLE service_role; CREATE TABLE auth.users(id uuid primary key);');
  await db.exec(readFileSync(new URL('../../supabase/migrations/202609090001_base_v2.sql', import.meta.url), 'utf8'));
  // A migration V3 corrige esta constraint; o teste das automações usa apenas o contrato de colunas V2.
  await db.exec('ALTER TABLE public.clientes DROP CONSTRAINT clientes_telefone_e164_check;');
  await db.exec('ALTER TABLE public.fila_mensagens ADD COLUMN contexto jsonb;');
  await db.exec(`
    INSERT INTO public.empresas(id,codigo,nome_fantasia,whatsapp_numero,instancia_evolution,status_operacional)
      VALUES ('${id(1)}','teste','Empresa Teste','5511999999999','teste','ativo');
    INSERT INTO public.empresa_configuracoes(empresa_id,reativacao_automatica)
      VALUES ('${id(1)}',true);
    INSERT INTO public.profissionais(id,empresa_id,nome) VALUES ('${id(2)}','${id(1)}','Profissional');
    INSERT INTO public.servicos(id,empresa_id,nome,duracao_min,preco,prazo_reativacao_dias)
      VALUES ('${id(3)}','${id(1)}','Servico',60,50,7);
    INSERT INTO public.clientes(id,empresa_id,nome,telefone_e164,status_cadastro,aceita_reativacao)
      VALUES ('${id(4)}','${id(1)}','Cliente','+5511999999999','ativo',true);
    INSERT INTO public.agendamentos(id,empresa_id,cliente_id,profissional_id,servico_id,inicio_em,fim_atendimento_em,fim_bloqueio_em,duracao_min,preco,origem)
      VALUES ('${id(5)}','${id(1)}','${id(4)}','${id(2)}','${id(3)}',now()+interval '24 hours',now()+interval '25 hours',now()+interval '25 hours',60,50,'cliente_whatsapp');
    INSERT INTO public.fila_mensagens(id,empresa_id,cliente_id,agendamento_id,tipo,chave_idempotencia,programado_para)
      VALUES ('${id(6)}','${id(1)}','${id(4)}','${id(5)}','lembrete_24h','teste-lembrete',now()-interval '1 minute');
  `);
  const booked = await db.query(query(reminder, 'Reservar lembretes V2'));
  assert.equal(booked.rows.length, 1);
  assert.equal(booked.rows[0].fila_id, id(6));
  const valid = await db.query(query(reminder, 'Revalidar lembrete'), [id(6)]);
  assert.equal(valid.rows[0].autorizado, true);
  await db.exec(`UPDATE public.agendamentos SET status='cancelado' WHERE id='${id(5)}'`);
  const invalid = await db.query(query(reminder, 'Revalidar lembrete'), [id(6)]);
  assert.equal(invalid.rows[0].autorizado, false);
  assert.equal((await db.query(`SELECT estado FROM public.fila_mensagens WHERE id='${id(6)}'`)).rows[0].estado, 'cancelado');
  await db.exec(`
    INSERT INTO public.agendamentos(id,empresa_id,cliente_id,profissional_id,servico_id,inicio_em,fim_atendimento_em,fim_bloqueio_em,duracao_min,preco,origem)
      VALUES ('${id(8)}','${id(1)}','${id(4)}','${id(2)}','${id(3)}',now()+interval '119 minutes',now()+interval '179 minutes',now()+interval '179 minutes',60,50,'cliente_whatsapp');
    INSERT INTO public.fila_mensagens(id,empresa_id,cliente_id,agendamento_id,tipo,chave_idempotencia,programado_para)
      VALUES ('${id(9)}','${id(1)}','${id(4)}','${id(8)}','lembrete_2h','teste-lembrete-2h',now()-interval '1 minute');
  `);
  const twoHour = await db.query(query(reminder, 'Reservar lembretes V2'));
  assert.equal(twoHour.rows.length, 1);
  assert.equal(twoHour.rows[0].tipo, 'lembrete_2h');
  assert.equal((await db.query(query(reminder, 'Revalidar lembrete'), [id(9)])).rows[0].autorizado, true);
  await db.exec(`UPDATE public.agendamentos SET status='cancelado' WHERE id='${id(8)}'`);
  await db.exec(`
    INSERT INTO public.agendamentos(id,empresa_id,cliente_id,profissional_id,servico_id,inicio_em,fim_atendimento_em,fim_bloqueio_em,duracao_min,preco,origem,status,concluido_em)
      VALUES ('${id(7)}','${id(1)}','${id(4)}','${id(2)}','${id(3)}',now()-interval '9 days',now()-interval '9 days'+interval '1 hour',now()-interval '9 days'+interval '1 hour',60,50,'cliente_whatsapp','concluido',now()-interval '9 days');
  `);
  const generated = await db.query(query(revival, 'Gerar reativações V2'));
  assert.equal(generated.rows[0].geradas, 1);
  const generatedAgain = await db.query(query(revival, 'Gerar reativações V2'));
  assert.equal(generatedAgain.rows[0].geradas, 0);
  const reserved = await db.query(query(revival, 'Reservar reativações V2'));
  assert.equal(reserved.rows.length, 1);
  const revivalValid = await db.query(query(revival, 'Revalidar reativação'), [reserved.rows[0].fila_id]);
  assert.equal(revivalValid.rows[0].autorizado, true);
  await db.exec(`UPDATE public.clientes SET aceita_reativacao=false WHERE id='${id(4)}'`);
  const revivalInvalid = await db.query(query(revival, 'Revalidar reativação'), [reserved.rows[0].fila_id]);
  assert.equal(revivalInvalid.rows[0].autorizado, false);
  console.log('OK: JSONs, SQL V2, lembretes 24h/2h, cancelamento, reativacao idempotente e opt-out.');
} finally {
  await db.close();
}
