import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';

const pasta = dirname(fileURLToPath(import.meta.url));
const pastaSaida = join(pasta, 'json');
mkdirSync(pastaSaida, { recursive: true });

// Referências copiadas dos exports originais fornecidos pelo proprietário.
// São IDs e nomes do n8n, nunca valores de senha/chave.
const credencialPostgres = { postgres: { id: 'rKBK9lfP7PQ1sCNO', name: 'Postgres account' } };
const credencialEvolution = { httpHeaderAuth: { id: 'd1FKH88e0LqiyrFZ', name: 'Header Auth account' } };
const evolutionBase = 'https://evolution.multiverso360.com.br';

const postgres = (name, query, replacement = null, x = 0) => ({
  id: randomUUID(), name, type: 'n8n-nodes-base.postgres', typeVersion: 2.5,
  credentials: credencialPostgres,
  position: [x, 0],
  parameters: { operation: 'executeQuery', query, options: {
    ...(replacement ? { queryReplacement: replacement } : {}), connectionTimeout: 5,
  } },
});
const code = (name, jsCode, x) => ({ id: randomUUID(), name, type: 'n8n-nodes-base.code', typeVersion: 2, position: [x, 0], parameters: { mode: 'runOnceForEachItem', jsCode } });
const schedule = (minutes) => ({ id: randomUUID(), name: 'A cada ' + minutes + ' minuto(s)', type: 'n8n-nodes-base.scheduleTrigger', typeVersion: 1.2, position: [0, 0], parameters: { rule: { interval: [{ field: 'minutes', minutesInterval: minutes }] } } });
const http = (name, source, x) => ({
  id: randomUUID(), name, type: 'n8n-nodes-base.httpRequest', typeVersion: 4.2, position: [x, 0],
  credentials: credencialEvolution,
  parameters: { method: 'POST', url: `={{ '${evolutionBase}/message/sendText/' + encodeURIComponent($('${source}').item.json.instancia_evolution) }}`,
    authentication: 'genericCredentialType', genericAuthType: 'httpHeaderAuth', sendBody: true, specifyBody: 'json',
    jsonBody: `={{ { number: $('${source}').item.json.telefone_e164.replace(/^\\+/, ''), text: $('${source}').item.json.mensagem } }}`,
    options: { timeout: 30000, redirect: { redirect: { followRedirects: false } } } },
});
const link = (nodes) => Object.fromEntries(nodes.slice(0, -1).map((n, i) => [n.name, { main: [[{ node: nodes[i + 1].name, type: 'main', index: 0 }]] }]));
const janela = `(cfg.janela_envio_inicio IS NULL AND cfg.janela_envio_fim IS NULL OR cfg.janela_envio_inicio IS NOT NULL AND cfg.janela_envio_fim IS NOT NULL AND (CASE WHEN cfg.janela_envio_inicio <= cfg.janela_envio_fim THEN (now() AT TIME ZONE e.fuso_horario)::time >= cfg.janela_envio_inicio AND (now() AT TIME ZONE e.fuso_horario)::time < cfg.janela_envio_fim ELSE (now() AT TIME ZONE e.fuso_horario)::time >= cfg.janela_envio_inicio OR (now() AT TIME ZONE e.fuso_horario)::time < cfg.janela_envio_fim END))`;

const lembreteValido = `f.estado = 'processando' AND f.tipo IN ('lembrete_24h','lembrete_2h')
  AND e.status_operacional = 'ativo' AND a.status = 'confirmado' AND a.inicio_em > now()
  AND c.telefone_e164 IS NOT NULL AND c.anonimizado_em IS NULL
  AND (CASE WHEN f.tipo = 'lembrete_24h' THEN cfg.lembrete_24h_ativo AND a.inicio_em > now() + interval '2 hours'
            ELSE cfg.lembrete_2h_ativo END) AND ${janela}`;

const reservarLembretes = `WITH candidatos AS (
  SELECT f.id FROM public.fila_mensagens f
  JOIN public.empresas e ON e.id = f.empresa_id
  JOIN public.empresa_configuracoes cfg ON cfg.empresa_id = e.id
  JOIN public.agendamentos a ON a.id = f.agendamento_id AND a.empresa_id = f.empresa_id
  JOIN public.clientes c ON c.id = f.cliente_id AND c.empresa_id = f.empresa_id
  WHERE f.estado = 'pendente' AND f.tipo IN ('lembrete_24h','lembrete_2h')
    AND f.programado_para <= now() AND e.status_operacional = 'ativo'
    AND a.status = 'confirmado' AND a.inicio_em > now()
    AND c.telefone_e164 IS NOT NULL AND c.anonimizado_em IS NULL
    AND (CASE WHEN f.tipo = 'lembrete_24h' THEN cfg.lembrete_24h_ativo AND a.inicio_em > now() + interval '2 hours'
              ELSE cfg.lembrete_2h_ativo END)
    AND ${janela}
  ORDER BY f.programado_para, f.criado_em LIMIT 25 FOR UPDATE OF f SKIP LOCKED
), reservados AS (
  UPDATE public.fila_mensagens f SET estado = 'processando', processando_em = now(), tentativas = f.tentativas + 1
  FROM candidatos x WHERE f.id = x.id RETURNING f.*
)
SELECT f.id AS fila_id, f.tipo::text AS tipo, f.agendamento_id, a.inicio_em, e.nome_fantasia,
       e.instancia_evolution, e.fuso_horario, c.telefone_e164, c.nome AS nome_cliente,
       s.nome AS nome_servico, p.nome AS nome_profissional
FROM reservados f
JOIN public.agendamentos a ON a.id = f.agendamento_id AND a.empresa_id = f.empresa_id
JOIN public.empresas e ON e.id = f.empresa_id
JOIN public.clientes c ON c.id = f.cliente_id AND c.empresa_id = f.empresa_id
JOIN public.servicos s ON s.id = a.servico_id AND s.empresa_id = f.empresa_id
JOIN public.profissionais p ON p.id = a.profissional_id AND p.empresa_id = f.empresa_id;`;

const prepararLembrete = `const v = $json;
const tz = v.fuso_horario || 'America/Sao_Paulo';
const data = new Date(v.inicio_em);
const quando = new Intl.DateTimeFormat('pt-BR', {timeZone: tz, day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit'}).format(data);
const nome = v.nome_cliente || 'cliente';
const mensagem = v.tipo === 'lembrete_24h'
  ? 'Olá, ' + nome + '! Lembramos do seu agendamento de ' + v.nome_servico + ' com ' + v.nome_profissional + ' em ' + v.nome_fantasia + ', dia ' + quando + '.'
  : 'Olá, ' + nome + '! Seu agendamento de ' + v.nome_servico + ' com ' + v.nome_profissional + ' em ' + v.nome_fantasia + ' está previsto para ' + quando + '.';
return {json: {...v, mensagem}};`;

const revalidarLembrete = `WITH invalido AS (
  UPDATE public.fila_mensagens f SET estado = 'cancelado', cancelado_em = now(), processando_em = NULL,
    ultimo_erro = 'Inelegivel antes do envio'
  WHERE f.id = $1::uuid AND f.estado = 'processando' AND NOT EXISTS (
    SELECT 1 FROM public.agendamentos a
    JOIN public.empresas e ON e.id = a.empresa_id
    JOIN public.empresa_configuracoes cfg ON cfg.empresa_id = e.id
    JOIN public.clientes c ON c.id = f.cliente_id AND c.empresa_id = f.empresa_id
    WHERE a.id = f.agendamento_id AND a.empresa_id = f.empresa_id AND ${lembreteValido}
  ) RETURNING f.id
)
SELECT EXISTS (SELECT 1 FROM public.fila_mensagens f
  JOIN public.agendamentos a ON a.id = f.agendamento_id AND a.empresa_id = f.empresa_id
  JOIN public.empresas e ON e.id = f.empresa_id
  JOIN public.empresa_configuracoes cfg ON cfg.empresa_id = e.id
  JOIN public.clientes c ON c.id = f.cliente_id AND c.empresa_id = f.empresa_id
  WHERE f.id = $1::uuid AND ${lembreteValido}) AS autorizado;`;

const reativacaoValida = `f.estado = 'processando' AND f.tipo = 'reativacao' AND a.status = 'concluido'
  AND a.concluido_em <= now() - make_interval(days => s.prazo_reativacao_dias)
  AND s.prazo_reativacao_dias IS NOT NULL AND cfg.reativacao_automatica
  AND c.aceita_reativacao AND c.anonimizado_em IS NULL AND c.telefone_e164 IS NOT NULL
  AND e.status_operacional = 'ativo' AND ${janela}
  AND NOT EXISTS (SELECT 1 FROM public.agendamentos futuro WHERE futuro.empresa_id = a.empresa_id
    AND futuro.cliente_id = a.cliente_id AND futuro.status = 'confirmado' AND futuro.inicio_em > now())
  AND NOT EXISTS (SELECT 1 FROM public.agendamentos recente WHERE recente.empresa_id = a.empresa_id
    AND recente.cliente_id = a.cliente_id AND recente.status = 'concluido' AND recente.concluido_em > a.concluido_em)`;

const gerarReativacoes = `WITH ultimos AS (
  SELECT DISTINCT ON (a.empresa_id, a.cliente_id) a.id AS agendamento_id, a.empresa_id, a.cliente_id,
    a.concluido_em, s.prazo_reativacao_dias
  FROM public.agendamentos a
  JOIN public.servicos s ON s.id = a.servico_id AND s.empresa_id = a.empresa_id
  JOIN public.clientes c ON c.id = a.cliente_id AND c.empresa_id = a.empresa_id
  JOIN public.empresas e ON e.id = a.empresa_id
  JOIN public.empresa_configuracoes cfg ON cfg.empresa_id = e.id
  WHERE a.status = 'concluido' AND a.concluido_em IS NOT NULL
    AND cfg.reativacao_automatica AND c.aceita_reativacao AND c.anonimizado_em IS NULL
    AND c.telefone_e164 IS NOT NULL AND e.status_operacional = 'ativo'
    AND NOT EXISTS (SELECT 1 FROM public.agendamentos futuro WHERE futuro.empresa_id = a.empresa_id
      AND futuro.cliente_id = a.cliente_id AND futuro.status = 'confirmado' AND futuro.inicio_em > now())
  ORDER BY a.empresa_id, a.cliente_id, a.concluido_em DESC
), criados AS (
  INSERT INTO public.fila_mensagens (empresa_id, cliente_id, agendamento_id, tipo, chave_idempotencia, programado_para, contexto)
  SELECT empresa_id, cliente_id, agendamento_id, 'reativacao',
    format('agendamento:%s:reativacao', agendamento_id),
    concluido_em + make_interval(days => prazo_reativacao_dias),
    '{"origem":"atendimento_concluido"}'::jsonb
  FROM ultimos WHERE prazo_reativacao_dias IS NOT NULL
    AND concluido_em + make_interval(days => prazo_reativacao_dias) <= now()
  LIMIT 200 ON CONFLICT (chave_idempotencia) DO NOTHING RETURNING id
)
SELECT count(*)::integer AS geradas FROM criados;`;

const reservarReativacoes = `WITH candidatos AS (
  SELECT f.id FROM public.fila_mensagens f
  JOIN public.agendamentos a ON a.id = f.agendamento_id AND a.empresa_id = f.empresa_id
  JOIN public.servicos s ON s.id = a.servico_id AND s.empresa_id = a.empresa_id
  JOIN public.clientes c ON c.id = f.cliente_id AND c.empresa_id = f.empresa_id
  JOIN public.empresas e ON e.id = f.empresa_id
  JOIN public.empresa_configuracoes cfg ON cfg.empresa_id = e.id
  WHERE f.estado = 'pendente' AND f.tipo = 'reativacao' AND f.programado_para <= now()
    AND ${reativacaoValida.replace("f.estado = 'processando' AND ", '')}
  ORDER BY f.programado_para, f.criado_em LIMIT 25 FOR UPDATE OF f SKIP LOCKED
), reservados AS (
  UPDATE public.fila_mensagens f SET estado = 'processando', processando_em = now(), tentativas = f.tentativas + 1
  FROM candidatos x WHERE f.id = x.id RETURNING f.*
)
SELECT f.id AS fila_id, f.agendamento_id, e.nome_fantasia, e.instancia_evolution,
       c.telefone_e164, c.nome AS nome_cliente, s.nome AS nome_servico
FROM reservados f
JOIN public.agendamentos a ON a.id = f.agendamento_id AND a.empresa_id = f.empresa_id
JOIN public.servicos s ON s.id = a.servico_id AND s.empresa_id = f.empresa_id
JOIN public.empresas e ON e.id = f.empresa_id
JOIN public.clientes c ON c.id = f.cliente_id AND c.empresa_id = f.empresa_id;`;

const prepararReativacao = `const v = $json;
const nome = v.nome_cliente || 'cliente';
const mensagem = 'Olá, ' + nome + '! Já faz um tempo desde seu atendimento de ' + v.nome_servico + ' em ' + v.nome_fantasia + '. Gostaria de ver um novo horário?';
return {json: {...v, mensagem}};`;

const revalidarReativacao = `WITH invalido AS (
  UPDATE public.fila_mensagens f SET estado = 'cancelado', cancelado_em = now(), processando_em = NULL,
    ultimo_erro = 'Inelegivel antes do envio'
  WHERE f.id = $1::uuid AND f.estado = 'processando' AND NOT EXISTS (
    SELECT 1 FROM public.agendamentos a
    JOIN public.servicos s ON s.id = a.servico_id AND s.empresa_id = a.empresa_id
    JOIN public.empresas e ON e.id = a.empresa_id
    JOIN public.empresa_configuracoes cfg ON cfg.empresa_id = e.id
    JOIN public.clientes c ON c.id = f.cliente_id AND c.empresa_id = f.empresa_id
    WHERE a.id = f.agendamento_id AND a.empresa_id = f.empresa_id AND ${reativacaoValida}
  ) RETURNING f.id
)
SELECT EXISTS (SELECT 1 FROM public.fila_mensagens f
  JOIN public.agendamentos a ON a.id = f.agendamento_id AND a.empresa_id = f.empresa_id
  JOIN public.servicos s ON s.id = a.servico_id AND s.empresa_id = a.empresa_id
  JOIN public.empresas e ON e.id = f.empresa_id
  JOIN public.empresa_configuracoes cfg ON cfg.empresa_id = e.id
  JOIN public.clientes c ON c.id = f.cliente_id AND c.empresa_id = f.empresa_id
  WHERE f.id = $1::uuid AND ${reativacaoValida}) AS autorizado;`;

const gate = (name, x) => ({ id: randomUUID(), name, type: 'n8n-nodes-base.if', typeVersion: 2, position: [x, 0],
  parameters: { conditions: { options: { caseSensitive: true, leftValue: '', typeValidation: 'strict', version: 2 }, combinator: 'and', conditions: [
    { id: randomUUID(), leftValue: '={{ $json.autorizado }}', rightValue: true, operator: { type: 'boolean', operation: 'true', singleValue: true } },
  ] } } });
const confirm = (source, x) => postgres('Confirmar envio',
  `SELECT public.marcar_fila_mensagem_enviada($1::uuid, $2::text) AS confirmado
   WHERE $2::text IS NOT NULL AND $2::text <> '';`,
  `={{ [$('${source}').item.json.fila_id, $json.key?.id ?? null] }}`, x);

const reminderNodes = [
  schedule(1), postgres('Reservar lembretes V2', reservarLembretes, null, 240),
  code('Montar lembrete', prepararLembrete, 480),
  postgres('Revalidar lembrete', revalidarLembrete, "={{ [$('Reservar lembretes V2').item.json.fila_id] }}", 720),
  gate('Pode enviar?', 960), http('Enviar lembrete', 'Montar lembrete', 1200), confirm('Reservar lembretes V2', 1440),
];
const reminderLinks = link(reminderNodes);
reminderLinks['Pode enviar?'] = { main: [[{ node: 'Enviar lembrete', type: 'main', index: 0 }], []] };

const reactivationNodes = [
  schedule(5), postgres('Gerar reativações V2', gerarReativacoes, null, 240),
  postgres('Reservar reativações V2', reservarReativacoes, null, 480),
  code('Montar reativação', prepararReativacao, 720),
  postgres('Revalidar reativação', revalidarReativacao, "={{ [$('Reservar reativações V2').item.json.fila_id] }}", 960),
  gate('Pode enviar?', 1200), http('Enviar reativação', 'Montar reativação', 1440), confirm('Reservar reativações V2', 1680),
];
const reactivationLinks = link(reactivationNodes);
reactivationLinks['Pode enviar?'] = { main: [[{ node: 'Enviar reativação', type: 'main', index: 0 }], []] };

// Override the generic linear connection map so the false branch never reaches HTTP.
const write = (filename, name, nodes, connections) => writeFileSync(join(pastaSaida, filename), JSON.stringify({ name, nodes, connections, settings: {
  executionOrder: 'v1', timezone: 'America/Sao_Paulo', saveDataErrorExecution: 'none', saveDataSuccessExecution: 'none', executionTimeout: 120,
}, active: false, pinData: {}, tags: [] }, null, 2) + '\n');
write('lembretes-v2.json', 'Agenda24h - Lembretes V2 (homologacao)', reminderNodes, reminderLinks);
write('reativacao-pos-atendimento-v2.json', 'Agenda24h - Reativacao pos-atendimento V2 (homologacao)', reactivationNodes, reactivationLinks);
