-- Somente leitura; após aplicar migration-atendimento-v3.sql em homologação.
select p.proname,pg_get_function_identity_arguments(p.oid) as argumentos,
 has_function_privilege('agenda24h_atendimento',p.oid,'execute') as automacao_executa,
 has_function_privilege('anon',p.oid,'execute') as anon_executa,
 has_function_privilege('authenticated',p.oid,'execute') as authenticated_executa
from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname like 'a24_v3_%';
select rolname,rolsuper,rolbypassrls,rolcreaterole,rolcreatedb from pg_roles where rolname='agenda24h_atendimento';
select tgname,tgenabled from pg_trigger where tgname in ('atendimento_v3_integridade','atendimento_v3_privacidade');
select estado,count(*) from atendimento_v3.turnos group by estado;
select estado,count(*) from atendimento_v3.alertas group by estado;
select erro,count(*) from atendimento_v3.turnos where erro is not null group by erro;
