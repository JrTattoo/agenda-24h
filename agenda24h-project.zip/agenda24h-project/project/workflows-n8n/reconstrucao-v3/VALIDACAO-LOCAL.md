# Resultado local — 19/09/2026

Comando: `node --test workflows-n8n/reconstrucao-v3/tests/*.test.mjs`, a partir da raiz do projeto.

Resultado registrado pelo runner Node: **46 testes, 46 aprovados, 0 falhas, 0 ignorados**.

- PostgreSQL isolado PGlite 0.3.14 com extensão btree_gist, migrations oficiais locais e migration V3 completa.
- Dados exclusivamente fictícios; nenhum banco remoto consultado/alterado.
- Validou regras, isolamento, deduplicação, sessão, buffering, pausa/retomada, áudio, formatos não suportados, alertas, anonimização e privilégios.
- Validou sintaxe dos nós Code, referências internas, parametrização SQL, autenticação declarada, ausência de credenciais e estado inativo dos sete JSONs.
- Regressões específicas: reagendamento ocupado, parâmetros de reserva, UUID em consultas, limite de 24h inclusivo, buffer posterior, lembretes de volta ao horário original e eco antes do retorno HTTP.

**Não comprova:** importação/execução no n8n instalado, chamadas reais da Evolution/OpenAI, entrega WhatsApp, confirmação interpretada pelo modelo, capacidade, concorrência de conexões no servidor ou implantação. Esses itens permanecem no roteiro TESTES.md.
