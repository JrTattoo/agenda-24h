import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root = dirname(fileURLToPath(import.meta.url));
const origem = process.argv[2];
if (!origem) throw new Error('Informe o export JSON do WF1 V3.');
const instancia = process.argv[3];
if (!instancia || !/^[A-Za-z0-9_-]{1,100}$/.test(instancia)) throw new Error('Informe o nome exato e válido da instância Evolution.');
const w = JSON.parse(readFileSync(origem, 'utf8'));
const find = name => {
  const node = w.nodes.find(n => n.name === name);
  if (!node) throw new Error(`Nó obrigatório ausente: ${name}`);
  return node;
};
for (const name of ['Webhook Evolution', 'Guard', 'Recebido', 'Transcrever?', 'Salvar transcricao',
  'Registrar falha de audio', 'Processar pendencias', 'Reservar conversa', 'Contexto reservado',
  'Ha conversa?', 'Ha alerta?', 'Confirmar envio', 'Envio indeterminado']) find(name);
if (w.nodes.filter(n => n.name === 'Processar pendencias')[0].type !== 'n8n-nodes-base.scheduleTrigger') {
  throw new Error('O export não corresponde ao WF1 V3 esperado.');
}

const id = s => {
  const h = createHash('sha256').update(`agenda24h-evento5s:${s}`).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-8${h.slice(17, 20)}-${h.slice(20, 32)}`;
};
const add = (name, type, parameters, position) => {
  const node = { id: id(name), name, type, typeVersion: type.endsWith('.wait') ? 1.1 : type.endsWith('.code') ? 2 : 2.2, position, parameters };
  if (type.endsWith('.wait')) node.webhookId = id(`wait:${name}`);
  w.nodes.push(node);
  return node;
};
const edge = (from, to, branch = 0) => {
  const main = (w.connections[from] ??= {}).main ??= [];
  while (main.length <= branch) main.push([]);
  if (!main[branch].some(e => e.node === to)) main[branch].push({ node: to, type: 'main', index: 0 });
};
const clear = (from, branch = 0) => {
  if (w.connections[from]?.main?.[branch]) w.connections[from].main[branch] = [];
};
const condition = (name, expression, position) => add(name, 'n8n-nodes-base.if', {
  conditions: { options: { caseSensitive: true, leftValue: '', typeValidation: 'strict', version: 2 },
    conditions: [{ id: id(`condition:${name}`), leftValue: expression, rightValue: true,
      operator: { type: 'boolean', operation: 'true', singleValue: true } }], combinator: 'and' }, options: {},
}, position);

delete w.id;
delete w.versionId;
delete w.meta;
w.name = 'WF1 - Agenda24h V3 - Linear por Webhook 5s (homologacao)';
w.active = false;
w.pinData = {};
w.settings.executionTimeout = 10800; // Esperas pontuais podem atravessar pausa humana/limite de segurança.
const webhook = find('Webhook Evolution');
webhook.parameters.path += '-evento5s';
webhook.webhookId = id('webhook-evento5s');
const validarEvento = find('Validar evento');
if (!validarEvento.parameters.jsCode.includes('PREENCHER_INSTANCIA_EXATA')) throw new Error('Marcador da instância não encontrado em Validar evento.');
validarEvento.parameters.jsCode = validarEvento.parameters.jsCode.replace('PREENCHER_INSTANCIA_EXATA', instancia);
validarEvento.parameters.jsCode = validarEvento.parameters.jsCode.replace("if(esperado.startsWith('PREENCHER_'))throw Error('Configure a instância antes de ativar.');\n", '');
validarEvento.parameters.jsCode = validarEvento.parameters.jsCode.replace('const valido=', 'let valido=');
const markerFormato = "if(normalizado==='texto'&&!texto.trim())normalizado='outro';";
if (!validarEvento.parameters.jsCode.includes(markerFormato)) throw new Error('Filtro de formato não encontrado.');
validarEvento.parameters.jsCode = validarEvento.parameters.jsCode.replace(markerFormato,
  `${markerFormato}\nif(!k.fromMe && !['texto','audio'].includes(normalizado))valido=false;`);
// O registro de entrada usa a mesma RPC do Guard V3, mas fica no próprio WF1.
// Assim o caminho principal não depende de associar manualmente um subworkflow.
const guard = find('Guard');
guard.type = 'n8n-nodes-base.postgres';
guard.typeVersion = 2.5;
guard.parameters = {
  operation: 'executeQuery',
  query: 'SELECT public.a24_v3_receber($1::text,$2::jsonb) AS resultado;',
  options: { connectionTimeout: 10,
    queryReplacement: '={{ [$("Validar evento").first().json.instancia, JSON.stringify($("Validar evento").first().json.evento)] }}' },
};
delete guard.credentials;
add('Normalizar entrada', 'n8n-nodes-base.code', {
  jsCode: 'const r=$json.resultado; return [{json:r&&typeof r==="object"?r:{acao:"ignorar"}}];',
}, [1320, 0]);
clear('Guard');
edge('Guard', 'Normalizar entrada');
edge('Normalizar entrada', 'Recebido');
w.nodes = w.nodes.filter(n => n.name !== 'Processar pendencias');
delete w.connections['Processar pendencias'];

condition('Processar entrada?', '={{ ["registrada","transcrever"].includes($json.acao) && !!$json.mensagem_id }}', [1540, 0]);
add('Aguardar 5s entre mensagens', 'n8n-nodes-base.wait', { resume: 'timeInterval', amount: 5, unit: 'seconds' }, [2860, 0]);
condition('Deve aguardar?', '={{ Number($json.retry_seconds) > 0 }}', [880, 980]);
add('Aguardar pendencia desta conversa', 'n8n-nodes-base.wait', {
  resume: 'timeInterval', amount: '={{ Math.max(1, Math.min(7200, Number($json.retry_seconds) || 15)) }}', unit: 'seconds',
}, [1100, 980]);

clear('Recebido');
edge('Recebido', 'Processar entrada?');
edge('Processar entrada?', 'Transcrever?');
clear('Transcrever?', 1);
edge('Transcrever?', 'Aguardar 5s entre mensagens', 1);
edge('Salvar transcricao', 'Aguardar 5s entre mensagens');
edge('Registrar falha de audio', 'Aguardar 5s entre mensagens');
edge('Aguardar 5s entre mensagens', 'Reservar conversa');
const reserve = find('Reservar conversa');
reserve.parameters.query = 'SELECT public.a24_v3_reservar_evento($1::text,$2::uuid) AS resultado;';
reserve.parameters.options.queryReplacement = '={{ [$("Validar evento").first().json.instancia, $("Normalizar entrada").first().json.mensagem_id] }}';
edge('Ha conversa?', 'Deve aguardar?', 1);
edge('Deve aguardar?', 'Aguardar pendencia desta conversa');
edge('Aguardar pendencia desta conversa', 'Reservar conversa');
edge('Registrar alerta enviado', 'Aguardar pendencia desta conversa');
edge('Registrar falha alerta', 'Aguardar pendencia desta conversa');

// Uma execução só pode referenciar o contexto da iteração atual, não o primeiro retorno vazio.
for (const node of w.nodes) {
  const serialized = JSON.stringify(node.parameters);
  node.parameters = JSON.parse(serialized
    .replaceAll("$('Contexto reservado').first()", "$('Contexto reservado').last()")
    .replaceAll("$('Guard').first().json", "$('Normalizar entrada').first().json"));
}
const note = find('Leia antes de ativar');
note.parameters.content = '## WF1 V3 — caminho linear acionado por mensagem\nWebhook → validar → registrar pela RPC V3 → HTTP 200 → transcrever se áudio → aguardar 5s → reservar somente a conversa do evento → agente/tools → envio controlado. Não há Schedule Trigger nem varredura global. Se a conversa já estiver processando, somente esta execução aguarda e reavalia até o turno encerrar/expirar. Requer as migrations V3 e credencial PostgreSQL exclusiva; não publicar antes de homologar.';

// O export V3 trazia a credencial do provisionamento Supabase no webhook e no
// aviso HTTP; ela não autentica a Evolution nem deve ser copiada para o WF1.
// A credencial PostgreSQL compartilhada também aponta para host com timeout.
// Mantemos apenas a OpenAI já usada pelo export; as outras devem ser vinculadas
// explicitamente no n8n conforme a finalidade de cada nó.
for (const node of w.nodes) {
  if (node.type === 'n8n-nodes-base.postgres' || node.credentials?.httpHeaderAuth) delete node.credentials;
}

const source = readFileSync(resolve(root, 'migration-atendimento-v3.sql'), 'utf8');
const start = source.indexOf('create function public.a24_v3_reservar(p_instancia text) returns jsonb');
const end = source.indexOf('\nend $$;', start) + '\nend $$;'.length;
if (start < 0 || end < 0) throw new Error('Função de reserva V3 não encontrada.');
let sql = source.slice(start, end);
function replaceOnce(before, after) {
  if (!sql.includes(before)) throw new Error(`Contrato SQL não encontrado: ${before.slice(0, 60)}`);
  sql = sql.replace(before, after);
}
replaceOnce('create function public.a24_v3_reservar(p_instancia text)',
  'create or replace function public.a24_v3_reservar_evento(p_instancia text,p_mensagem uuid)');
replaceOnce(" if not found then return jsonb_build_object('pronto',false); end if;\n -- Serializa reserva",
  " if not found or p_mensagem is null or not exists(select 1 from public.mensagens where id=p_mensagem and empresa_id=e.id and direcao='entrada') then return jsonb_build_object('pronto',false); end if;\n -- Serializa reserva");
replaceOnce(" where c.empresa_id=e.id and cl.anonimizado_em is null and cl.status_cadastro<>'bloqueado'",
  " where c.empresa_id=e.id and c.id=(select conversa_id from public.mensagens where id=p_mensagem and empresa_id=e.id) and cl.anonimizado_em is null and cl.status_cadastro<>'bloqueado'");
replaceOnce("m.recebida_em>now()-interval '15 seconds'", "m.recebida_em>now()-interval '5 seconds'");
replaceOnce("if (select count(*) from atendimento_v3.turnos where empresa_id=e.id and criado_em>now()-interval '1 minute')>=cfg.limite_ia_por_empresa_min then\n  return jsonb_build_object('pronto',false); end if;",
  "if (select count(*) from atendimento_v3.turnos where empresa_id=e.id and criado_em>now()-interval '1 minute')>=cfg.limite_ia_por_empresa_min then\n  return jsonb_build_object('pronto',false,'retry_seconds',60); end if;");
replaceOnce(" if not found then return jsonb_build_object('pronto',false); end if;\n select count(*) into n from atendimento_v3.turnos",
` if not found then
  select case
    when c.modo_atendimento='humano' and c.pausado_ate>now() then least(7200,greatest(1,ceil(extract(epoch from c.pausado_ate-now()))::integer))
    when exists(select 1 from atendimento_v3.limites l where l.conversa_id=c.id and l.bloqueado_ate>now()) then
      (select least(7200,greatest(1,ceil(extract(epoch from l.bloqueado_ate-now()))::integer)) from atendimento_v3.limites l where l.conversa_id=c.id)
    when exists(select 1 from atendimento_v3.turnos t where t.conversa_id=c.id and t.estado in ('processando','enviando')) then 15
    when exists(select 1 from public.mensagens m where m.conversa_id=c.id and m.direcao='entrada' and m.estado_processamento='pendente') then 5
    else null end into n
  from public.conversas c join public.clientes cl on cl.id=c.cliente_id
  where c.empresa_id=e.id and c.id=(select conversa_id from public.mensagens where id=p_mensagem and empresa_id=e.id)
    and cl.anonimizado_em is null and cl.status_cadastro<>'bloqueado'
    and exists(select 1 from public.mensagens m where m.conversa_id=c.id and m.direcao='entrada' and m.estado_processamento='pendente');
  return jsonb_build_object('pronto',false,'retry_seconds',n);
 end if;
 select count(*) into n from atendimento_v3.turnos`);
replaceOnce("return jsonb_build_object('pronto',false,'motivo','limite');",
  "return jsonb_build_object('pronto',false,'motivo','limite','retry_seconds',7200);");
const outDir = resolve(root, 'evento5s');
mkdirSync(outDir, { recursive: true });
writeFileSync(resolve(outDir, 'wf1-linear-v3-5s.json'), JSON.stringify(w, null, 2) + '\n');
writeFileSync(resolve(outDir, 'migration-webhook-evento5s.sql'),
  `begin;\n${sql}\nrevoke all on function public.a24_v3_reservar_evento(text,uuid) from public,anon,authenticated,service_role;\ngrant execute on function public.a24_v3_reservar_evento(text,uuid) to agenda24h_atendimento;\ncommit;\n`);
console.log('Cópia de homologação e migration geradas em evento5s/. Conexão e banco devem ser validados antes da ativação.');
