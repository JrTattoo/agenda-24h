# Comparação dos dois WF1 e decisão para o fluxo linear

Fontes: `WF1 - Principal Agenda24h (OpenAI).json` (primeiro workflow indicado pelo usuário) e `WF1 - Agenda24h V3 - Texto e Audio.json` (export posterior).

| Parte | Primeiro WF1 | WF1 V3 recebido | `wf1-linear-v3-5s.json` |
|---|---|---|---|
| Entrada | Um webhook inicia o atendimento de cada mensagem | Webhook registra; Schedule Trigger a cada 10 s inicia a reserva | Um webhook inicia e percorre o atendimento; nenhum Schedule Trigger |
| Espera/consolidação | Redis sobrescreve o buffer e espera 15 s; só a última execução prossegue | Banco acumula mensagens; consumidor espera 15 s | Banco acumula sem sobrescrever; cada entrada espera 5 s e reserva só sua conversa |
| Cadastro | `contratantes`, `leads`, `tag`, IDs legados | `empresas`, `clientes`, `conversas`, mensagens e UUIDs V2, com funções de atendimento V3 | Mesmos contratos V2/V3; sem referências ao cadastro legado |
| Guard | Subworkflow `_guard_antiloop` antigo | Subworkflow Guard V3 não associado no export | Registro de entrada via `a24_v3_receber` diretamente no principal; Guard V3 permanece para as tools de nome e transferência |
| Mensagens | Texto, áudio e imagem analisada | Texto/áudio; demais formatos recebem orientação determinística | Só texto/áudio do cliente entram; imagem, vídeo e demais formatos não geram resposta |
| Memória | Redis Chat Memory | Histórico de 24 h obtido pela reserva no banco | Histórico do banco; sem Redis Chat Memory |
| Tools | Cinco tools legadas com parâmetros como telefone/tag e ID numérico | Sete tools V3 com UUIDs e token de turno fixado pelo workflow | As sete tools V3, sem repassar identidade escolhida pela IA |
| Envio | Envia blocos via Evolution | Autoriza/finaliza envio no banco e envia via Evolution | Preserva autorização, envio e finalização V3 |

## Caminho principal

`Webhook → Validar evento → Registrar entrada V3 → HTTP 200 → Transcrever áudio (se houver) → Esperar 5 s → Reservar apenas a conversa da mensagem → Agente e tools → Autorizar envio → Evolution → Confirmar envio`.

Há uma exceção controlada: quando outra execução **da mesma conversa** ainda está respondendo, a execução dessa mensagem fica suspensa e reavalia a reserva após a espera retornada pelo banco. Isso não é uma varredura global nem um Schedule Trigger. Falha de conexão encerra a execução com erro, sem criar um agendador de dez segundos.

## Dependências para rodar

Este JSON é um artefato de homologação inativo. No Supabase inspecionado, a empresa `salaoexemplar` existe em `em_validacao`, mas a migration V3 e o papel `agenda24h_atendimento` ainda não foram instalados. A instalação e a ativação da empresa são etapas separadas da comparação dos workflows. Os nós PostgreSQL ficam sem credencial para impedir a reutilização acidental da conexão compartilhada que apresentou timeout. O webhook da Evolution não foi alterado.
