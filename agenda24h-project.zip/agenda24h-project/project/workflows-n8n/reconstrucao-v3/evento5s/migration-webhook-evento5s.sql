begin;
create or replace function public.a24_v3_reservar_evento(p_instancia text,p_mensagem uuid) returns jsonb
language plpgsql security definer set search_path=pg_catalog as $$
declare e public.empresas%rowtype; cv public.conversas%rowtype; cfg public.empresa_configuracoes%rowtype; ids uuid[]; tok uuid; txt text; unsupported bool; audio_fail bool; long_text bool; hist jsonb; n int; pend record; alerta atendimento_v3.alertas%rowtype;
begin
 select * into e from public.empresas where instancia_evolution=p_instancia and status_operacional='ativo';
 if not found or p_mensagem is null or not exists(select 1 from public.mensagens where id=p_mensagem and empresa_id=e.id and direcao='entrada') then return jsonb_build_object('pronto',false); end if;
 -- Serializa reserva e contador por empresa. Não mantém lock durante chamada externa.
 perform pg_advisory_xact_lock(hashtextextended('worker-v3:'||e.id,0));
 select * into cfg from public.empresa_configuracoes where empresa_id=e.id;
 -- Histórico conversacional de 24h; descarte operacional de conteúdo em 30 dias.
 update atendimento_v3.turnos set resposta=null,chave_operacao=null where empresa_id=e.id and criado_em<now()-interval '30 days' and resposta is not null;
 update public.mensagens set conteudo_texto=null,metadados=null where empresa_id=e.id and excluir_em<=now() and conteudo_texto is not null;
 select * into alerta from atendimento_v3.alertas where empresa_id=e.id and estado='pendente' order by criado_em limit 1 for update;
 if found then
  update atendimento_v3.alertas set estado='enviando' where id=alerta.id;
  return jsonb_build_object('pronto',false,'alerta',true,'alerta_id',alerta.id,'instancia',p_instancia,'numero',alerta.numero,
   'texto','O atendimento automático atingiu o limite de segurança em uma conversa e foi pausado por duas horas. Confira o registro operacional da Agenda24h. Referência: '||alerta.conversa_id);
 end if;
 -- Execução interrompida não é repetida automaticamente após possível mutação/envio.
 update public.mensagens m set estado_processamento='falhou',erro_sanitizado='EXECUCAO_EXPIRADA'
 from atendimento_v3.turnos t where t.empresa_id=e.id and t.estado in ('processando','enviando')
 and t.expira_em<now() and m.id=any(t.mensagens) and m.estado_processamento='processando';
 update atendimento_v3.turnos set estado='falhou',erro='EXECUCAO_EXPIRADA_REVISAR' where empresa_id=e.id and estado in ('processando','enviando') and expira_em<now();
 -- Ecos reconciliados pelo finalizar já são processados. Saídas restantes são intervenções humanas.
 for pend in select m.* from public.mensagens m where m.empresa_id=e.id and m.direcao='saida'
 and m.estado_processamento='recebida' and m.metadados->>'classificar_saida'='true'
 and m.recebida_em<now()-interval '5 seconds'
 and not exists(select 1 from atendimento_v3.turnos tt where tt.conversa_id=m.conversa_id and tt.estado='enviando')
 order by m.recebida_em loop
  perform 1 from public.conversas where id=pend.conversa_id for update;
  update public.conversas set modo_atendimento='humano',pausado_ate=greatest(now(),pend.recebida_em+interval '30 minutes'),
   ultima_mensagem_humana_em=pend.recebida_em,versao_controle=versao_controle+1 where id=pend.conversa_id;
  update public.mensagens set estado_processamento='ignorada',processada_em=now() where conversa_id=pend.conversa_id
   and direcao='entrada' and recebida_em<=pend.recebida_em and estado_processamento in ('recebida','pendente','processando');
  update atendimento_v3.turnos set estado='invalidado' where conversa_id=pend.conversa_id and estado='processando';
  update public.mensagens set estado_processamento='processada',metadados=null where id=pend.id;
 end loop;
 update public.mensagens set estado_processamento='pendente',tipo_mensagem='outro',metadados='{"falha_audio":true}'
 where empresa_id=e.id and tipo_mensagem='audio' and estado_processamento='recebida' and recebida_em<now()-interval '3 minutes';
 if (select count(*) from atendimento_v3.turnos where empresa_id=e.id and criado_em>now()-interval '1 minute')>=cfg.limite_ia_por_empresa_min then
  return jsonb_build_object('pronto',false,'retry_seconds',60); end if;
 select c.* into cv from public.conversas c join public.clientes cl on cl.id=c.cliente_id
 where c.empresa_id=e.id and c.id=(select conversa_id from public.mensagens where id=p_mensagem and empresa_id=e.id) and cl.anonimizado_em is null and cl.status_cadastro<>'bloqueado'
 and (c.modo_atendimento='ia' or c.pausado_ate<=now())
 and not exists(select 1 from atendimento_v3.turnos t where t.conversa_id=c.id and t.estado in ('processando','enviando'))
 and not exists(select 1 from atendimento_v3.limites l where l.conversa_id=c.id and l.bloqueado_ate>now())
 and exists(select 1 from public.mensagens m where m.conversa_id=c.id and m.estado_processamento='pendente' and m.direcao='entrada')
 and not exists(select 1 from public.mensagens m where m.conversa_id=c.id and m.direcao='entrada' and
 (m.estado_processamento='recebida' or (m.estado_processamento='pendente' and m.recebida_em>now()-interval '5 seconds')))
 order by c.ultima_mensagem_cliente_em limit 1 for update of c skip locked;
 if not found then
  select case
    when c.modo_atendimento='humano' and c.pausado_ate>now() then least(7200,greatest(1,ceil(extract(epoch from c.pausado_ate-now()))::integer))
    when exists(select 1 from atendimento_v3.limites l where l.conversa_id=c.id and l.bloqueado_ate>now()) then
      (select least(7200,greatest(1,ceil(extract(epoch from l.bloqueado_ate-now()))::integer)) from atendimento_v3.limites l where l.conversa_id=c.id)
    when exists(select 1 from atendimento_v3.turnos t where t.conversa_id=c.id and t.estado in ('processando','enviando')) then 15
    when exists(select 1 from public.mensagens m where m.conversa_id=c.id and m.direcao='entrada' and m.estado_processamento='pendente') then 5
    else null end into n
  from public.conversas c join public.clientes cl on cl.id=c.cliente_id
  where c.empresa_id=e.id and c.id=(select conversa_id from public.mensagens where id=p_mensagem and empresa_id=e.id)
    and cl.anonimizado_em is null and cl.status_cadastro<>'bloqueado'
    and exists(select 1 from public.mensagens m where m.conversa_id=c.id and m.direcao='entrada' and m.estado_processamento='pendente');
  return jsonb_build_object('pronto',false,'retry_seconds',n);
 end if;
 select count(*) into n from atendimento_v3.turnos where conversa_id=cv.id and criado_em>now()-interval '5 minutes';
 if n>=cfg.limite_ia_por_contato_5min then
  insert into atendimento_v3.limites values(cv.id,now()+interval '2 hours') on conflict(conversa_id) do update set bloqueado_ate=excluded.bloqueado_ate;
  insert into public.logs_auditoria(empresa_id,entidade_tipo,entidade_id,acao,ator_tipo,resultado,metadados_sanitizados)
  values(e.id,'conversa',cv.id,'limite_ia','sistema','pausado','{"duracao_min":120}');
  if cfg.numero_notificacao ~ '^[+]?[1-9][0-9]{7,14}$' then
   insert into atendimento_v3.alertas(empresa_id,conversa_id,numero) values(e.id,cv.id,regexp_replace(cfg.numero_notificacao,'[^0-9]','','g'));
  end if;
  return jsonb_build_object('pronto',false,'motivo','limite','retry_seconds',7200);
 end if;
 select array_agg(id order by recebida_em,id),string_agg(conteudo_texto,E'\n' order by recebida_em,id) filter(where tipo_mensagem in ('texto','audio')),
 bool_or(tipo_mensagem='outro' and coalesce((metadados->>'falha_audio')::boolean,false)=false and coalesce((metadados->>'texto_longo')::boolean,false)=false),
 bool_or(coalesce((metadados->>'falha_audio')::boolean,false)),bool_or(coalesce((metadados->>'texto_longo')::boolean,false)) into ids,txt,unsupported,audio_fail,long_text
 from (select * from public.mensagens where conversa_id=cv.id and estado_processamento='pendente' and direcao='entrada' order by recebida_em,id limit 30) x;
 update public.conversas set modo_atendimento='ia',pausado_ate=null where id=cv.id;
 insert into atendimento_v3.turnos(empresa_id,conversa_id,cliente_id,versao,mensagens) values(e.id,cv.id,cv.cliente_id,cv.versao_controle,ids) returning token into tok;
 update public.mensagens set estado_processamento='processando' where id=any(ids);
 select coalesce(jsonb_agg(jsonb_build_object('origem',h.origem,'texto',h.conteudo_texto) order by h.recebida_em),'[]') into hist
 from(select origem,conteudo_texto,recebida_em from public.mensagens where conversa_id=cv.id and estado_processamento='processada'
 and conteudo_texto is not null and recebida_em>now()-interval '24 hours' order by recebida_em desc limit 12) h;
 return jsonb_build_object('pronto',true,'token',tok,'instancia',p_instancia,'jid',(select whatsapp_jid from public.clientes where id=cv.cliente_id),
 'nome',(select nome from public.clientes where id=cv.cliente_id),'mensagem',coalesce(txt,''),'nao_suportado',unsupported,'falha_audio',audio_fail,'texto_longo',long_text,
 'historico',hist,'contexto',public.carregar_contexto_ia(e.id),'agora',to_char(now() at time zone e.fuso_horario,'YYYY-MM-DD"T"HH24:MI:SS'),'fuso',e.fuso_horario);
end $$;
revoke all on function public.a24_v3_reservar_evento(text,uuid) from public,anon,authenticated,service_role;
grant execute on function public.a24_v3_reservar_evento(text,uuid) to agenda24h_atendimento;
commit;
