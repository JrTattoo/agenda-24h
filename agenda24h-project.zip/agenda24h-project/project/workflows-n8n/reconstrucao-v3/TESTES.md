# Homologação — Agenda24h V3

Estado: testes locais automatizados; jornada externa ainda não executada.

## Evidência local

Executar `node --test tests/*.test.mjs` nesta pasta. A saída deve terminar com zero falhas.

A bateria cria um banco descartável a partir das migrations locais, aplica a nova migration e usa empresas, clientes e telefones fictícios. Testa reservas, replay idempotente, exclusão GiST, limite diário, buffer, expediente, vínculo serviço-profissional, alteração e cancelamento, fronteira exata das 24 horas, bloqueio de estados finais, isolamento, áudio, fila, transferência e privilégios. Há também verificações de referências dos JSONs, sintaxe de todos os nós Code, formatos e autenticação configurada.

## Ordem de teste no n8n

| Etapa | Cenário | Resultado esperado |
|---|---|---|
| Buscar | Consultar sem IDs; depois serviço/profissional reais | Catálogo, preços e horários corretos, somente da empresa |
| Verificar | Livre, ocupado, buffer, fora do expediente, feriado e profissional não habilitado | Mesmo resultado que as regras do banco |
| Agendar | Sem nome, sem confirmação, com confirmação | Recusas claras; uma única reserva confirmada no caso válido |
| Meus | Cliente sem reservas e com várias | Lista vazia ou UUIDs corretos, sem dados de outra pessoa |
| Gerenciar | Livre/ocupado; menos/exatamente/mais de 24h; cancelado/concluído/faltou | Só a alteração elegível é gravada; ID permanece no reagendamento |
| Guard | Mesmo message ID repetido; mensagem manual; eco antes/depois do HTTP | Sem duplicação e sem falsa pausa pelo bot |
| Principal | Texto, texto estendido, PTT OGG, imagem, vídeo, documento, figurinha | Texto/áudio atendidos; demais recebem aviso sem análise |

As tools usam token de um turno real. Para teste manual, registrar uma mensagem fictícia pelo principal, aguardar a reserva e usar o token somente dentro da execução segura. Não copiar tokens para prints públicos nem expô-los ao cliente. Tokens encerrados/expirados devem ser recusados.

## Concorrência real no PostgreSQL de homologação

PGlite não substitui este teste. Usar duas conexões independentes, mesma empresa e profissional e clientes fictícios diferentes, em data futura válida.

1. Na conexão A iniciar transação, executar `public.criar_agendamento` com os IDs fictícios e não confirmar ainda.
2. Na B iniciar transação e tentar o mesmo slot. B deve aguardar A.
3. Confirmar A. B deve falhar por conflito, e o banco deve ter exatamente uma reserva confirmada para aquele intervalo.
4. Repetir com profissionais diferentes e limite diário de uma reserva. Apenas uma operação pode ser aceita para aquele dia.
5. Repetir com uma remarcação concorrendo com uma nova reserva para o mesmo slot.
6. Encerrar/reverter as transações que falharam. Cancelar as reservas fictícias pela operação oficial; preservar a evidência de contagem e eventos. Não executar limpeza em massa.

## Pausa humana e retomada

1. Cliente envia mensagem; atendente responde manualmente: IA pausa.
2. Cliente envia durante a pausa: mensagem fica pendente.
3. Atendente responde depois: pendência anterior não deve receber resposta da IA.
4. Cliente envia outra mensagem sem resposta humana: após 30 minutos, consumidor responde mesmo sem novo webhook.
5. Nova mensagem manual renova os 30 minutos.
6. Intervenção enquanto o agente pensa invalida seu token; tools e envio devem ser recusados.
7. Saída do bot antes do retorno HTTP não deve ser confundida com humano; usar latência artificial na homologação.

## Falhas e operação

- Transcrição sem texto, mídia inválida, timeout da Evolution e falha OpenAI: aviso controlado ou estado operacional de falha, sem confirmação inventada.
- Timeout após gravar agendamento: consultar agenda antes de repetir. Mesma mutação no mesmo turno retorna a reserva original.
- Falha de envio: registro indeterminado, sem retry automático.
- Reiniciar o n8n entre recebimento e processamento: mensagem persistida deve ser retomada. Reiniciar durante envio: revisar ocorrência expirada antes de reenviar.
- Atingir limite por contato: pausa de duas horas, mensagem mantida, apenas um alerta por episódio quando há número configurado.
- Validar assinatura/autenticação do webhook: pedido sem cabeçalho válido não entra. Outra instância no corpo não entra nesse principal.
- Testar anonimização: encerrar turnos ativos e limpar conteúdo auxiliar; nunca recuperar uma conversa anonimizada pela memória.
- Conferir que execuções automáticas/manuais não salvam dados de conversas ou credenciais no histórico do n8n.

## Critério para produção

Registrar versão do n8n/Evolution, IDs dos workflows, data, responsável e resultado de cada cenário. Só considerar a jornada pronta quando os testes externos, concorrência, regressão do portal e revalidação do comparecimento tiverem passado. Testes locais não autorizam marcar essas frentes como concluídas.
