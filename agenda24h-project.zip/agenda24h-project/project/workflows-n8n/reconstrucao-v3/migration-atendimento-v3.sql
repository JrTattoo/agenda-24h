-- Agenda24h atendimento V3. PREPARADO LOCALMENTE, não aplicado.
-- Depende das migrations V2 001-009. Não depende da migration de comparecimento.
begin;
create schema atendimento_v3;
revoke all on schema atendimento_v3 from public, anon, authenticated, service_role;
create role agenda24h_atendimento login noinherit nosuperuser nocreatedb nocreaterole noreplication nobypassrls;
grant usage on schema public to agenda24h_atendimento;
alter role agenda24h_atendimento set statement_timeout = '25s';
alter role agenda24h_atendimento set lock_timeout = '5s';

-- Corrige o literal da expressão regular do contrato local V2 (barra duplicada).
alter table public.clientes drop constraint if exists clientes_telefone_ou_anonimo_check;
alter table public.clientes add constraint clientes_telefone_ou_anonimo_check
check ((anonimizado_em is null and telefone_e164 is not null and telefone_e164 ~ '^[+][1-9][0-9]{7,14}$')
 or (anonimizado_em is not null and telefone_e164 is null));

create table atendimento_v3.turnos (
 token uuid primary key default gen_random_uuid(), empresa_id uuid not null references public.empresas(id),
 conversa_id uuid not null references public.conversas(id), cliente_id uuid not null references public.clientes(id),
 versao integer not null, mensagens uuid[] not null,
 estado text not null default 'processando' check(estado in ('processando','enviando','enviado','falhou','invalidado')),
 criado_em timestamptz not null default clock_timestamp(), expira_em timestamptz not null default clock_timestamp()+interval '5 minutes',
 resposta text, chave_operacao jsonb, resultado_operacao jsonb, transferencia_solicitada boolean not null default false,
 evolution_message_id text, erro text
);
create unique index turno_ativo_conversa on atendimento_v3.turnos(conversa_id) where estado in ('processando','enviando');
create index turnos_empresa_tempo on atendimento_v3.turnos(empresa_id,criado_em);
create table atendimento_v3.limites (
 conversa_id uuid primary key references public.conversas(id), bloqueado_ate timestamptz
);
create table atendimento_v3.alertas (
 id uuid primary key default gen_random_uuid(),empresa_id uuid not null references public.empresas(id),
 conversa_id uuid not null references public.conversas(id),criado_em timestamptz not null default now(),
 estado text not null default 'pendente',numero text not null,evolution_message_id text
);
alter table atendimento_v3.turnos enable row level security;
alter table atendimento_v3.limites enable row level security;
alter table atendimento_v3.alertas enable row level security;
revoke all on all tables in schema atendimento_v3 from public, anon, authenticated, service_role;

create function atendimento_v3.limpar_cliente_anonimizado() returns trigger
language plpgsql security definer set search_path=pg_catalog as $$
begin
 if new.anonimizado_em is not null then
  update atendimento_v3.turnos set resposta=null,chave_operacao=null,resultado_operacao=null,
   estado=case when estado in ('processando','enviando') then 'invalidado' else estado end where cliente_id=new.id;
 end if;
 return new;
end $$;
create trigger atendimento_v3_privacidade after update of anonimizado_em on public.clientes
for each row execute function atendimento_v3.limpar_cliente_anonimizado();

create function atendimento_v3.validar_slot(e uuid,p uuid,s uuid,t timestamptz,ignorar uuid default null)
returns boolean language plpgsql security definer set search_path=pg_catalog as $$
declare f text; d int; limite int;
begin
 if t is null or not isfinite(t) then raise exception 'Data inválida'; end if;
 select fuso_horario into f from public.empresas where id=e and status_operacional='ativo';
 if not found then raise exception 'Empresa indisponível'; end if;
 select coalesce(ps.duracao_min_override,sv.duracao_min) into d
 from public.profissional_servicos ps join public.servicos sv on sv.id=ps.servico_id and sv.empresa_id=ps.empresa_id
 where ps.empresa_id=e and ps.profissional_id=p and ps.servico_id=s and ps.ativo;
 if d is null then raise exception 'Serviço ou profissional inválido'; end if;
 if (t at time zone f)::date <> ((t+make_interval(mins=>d)) at time zone f)::date then
  raise exception 'Atendimento atravessa o encerramento do dia'; end if;
 select limite_agendamentos_diarios into limite from public.empresa_configuracoes where empresa_id=e;
 if limite is not null and (select count(*) from public.agendamentos a where a.empresa_id=e and a.status='confirmado'
 and a.id is distinct from ignorar and (a.inicio_em at time zone f)::date=(t at time zone f)::date)>=limite then
  raise exception 'Limite diário atingido'; end if;
 return public.verificar_disponibilidade(e,p,s,t,ignorar);
end $$;

-- Proteção no banco inclusive para outros escritores; nenhuma alteração de status final é bloqueada.
create function atendimento_v3.proteger_gravacao() returns trigger language plpgsql security definer set search_path=pg_catalog as $$
declare b int;
begin
 if new.status <> 'confirmado' then return new; end if;
 if TG_OP='UPDATE' then
  if new.empresa_id=old.empresa_id and new.cliente_id=old.cliente_id and new.profissional_id=old.profissional_id
   and new.servico_id=old.servico_id and new.inicio_em=old.inicio_em and new.duracao_min=old.duracao_min
   and new.fim_atendimento_em=old.fim_atendimento_em and new.fim_bloqueio_em=old.fim_bloqueio_em and new.status=old.status then return new; end if;
 end if;
 perform pg_advisory_xact_lock(hashtextextended('agenda-v3:'||new.empresa_id,0));
 perform atendimento_v3.validar_slot(new.empresa_id,new.profissional_id,new.servico_id,new.inicio_em,new.id);
 select buffer_posterior_min into b from public.empresa_configuracoes where empresa_id=new.empresa_id;
 select coalesce(ps.duracao_min_override,s.duracao_min),coalesce(ps.preco_override,s.preco)
 into new.duracao_min,new.preco from public.profissional_servicos ps
 join public.servicos s on s.id=ps.servico_id and s.empresa_id=ps.empresa_id
 where ps.empresa_id=new.empresa_id and ps.profissional_id=new.profissional_id and ps.servico_id=new.servico_id and ps.ativo;
 new.fim_atendimento_em:=new.inicio_em+make_interval(mins=>new.duracao_min);
 new.fim_bloqueio_em:=new.fim_atendimento_em+make_interval(mins=>b);
 return new;
end $$;
create trigger atendimento_v3_integridade before insert or update on public.agendamentos
for each row execute function atendimento_v3.proteger_gravacao();

create function public.a24_v3_receber(p_instancia text,p_evento jsonb) returns jsonb
language plpgsql security definer set search_path=pg_catalog as $$
declare e uuid; c uuid; cv public.conversas%rowtype; mid uuid; telefone text; jid text; eid text; tipo text; humana boolean;
begin
 select id into e from public.empresas where instancia_evolution=p_instancia and status_operacional='ativo';
 if e is null then return jsonb_build_object('acao','ignorar'); end if;
 jid:=p_evento->>'jid'; eid:=p_evento->>'message_id'; tipo:=p_evento->>'tipo';
 if jid is null or jid !~ '^[1-9][0-9]{7,14}@s.whatsapp.net$' or nullif(eid,'') is null
 or length(eid)>200 or tipo is null or tipo not in ('texto','audio','outro') or jsonb_typeof(p_evento->'from_me') is distinct from 'boolean' then
  return jsonb_build_object('acao','ignorar'); end if;
 telefone:='+'||split_part(jid,'@',1); humana:=(p_evento->>'from_me')::boolean;
 perform pg_advisory_xact_lock(hashtextextended(e::text||':'||telefone,0));
 if exists(select 1 from public.mensagens where empresa_id=e and evolution_message_id=eid)
 or exists(select 1 from public.fila_mensagens where empresa_id=e and evolution_message_id=eid)
 or exists(select 1 from atendimento_v3.alertas where empresa_id=e and evolution_message_id=eid) then
  return jsonb_build_object('acao','ignorar','motivo','duplicata_ou_eco'); end if;
 insert into public.clientes(empresa_id,telefone_e164,whatsapp_jid,ultimo_contato_em)
 values(e,telefone,jid,now()) on conflict(empresa_id,telefone_e164) do update set ultimo_contato_em=now()
 returning id into c;
 if exists(select 1 from public.clientes where id=c and (status_cadastro='bloqueado' or anonimizado_em is not null)) then
  return jsonb_build_object('acao','ignorar'); end if;
 insert into public.conversas(empresa_id,cliente_id,telefone_e164) values(e,c,telefone)
 on conflict(empresa_id,cliente_id) do nothing;
 select * into cv from public.conversas where empresa_id=e and cliente_id=c for update;
 if length(p_evento->>'texto')>12000 then
  tipo:='outro';p_evento:=jsonb_set(p_evento,'{texto}','null'::jsonb)||'{"texto_longo":true}'::jsonb;
 end if;
 insert into public.mensagens(empresa_id,conversa_id,cliente_id,evolution_message_id,direcao,origem,tipo_mensagem,conteudo_texto,estado_processamento,excluir_em,metadados)
 values(e,cv.id,c,eid,case when humana then 'saida'::public.mensagem_direcao else 'entrada'::public.mensagem_direcao end,
 case when humana then 'humano'::public.mensagem_origem else 'cliente'::public.mensagem_origem end,tipo::public.mensagem_tipo,
 left(p_evento->>'texto',12000),case when humana then 'processada'::public.processamento_status
 when tipo='audio' then 'recebida'::public.processamento_status else 'pendente'::public.processamento_status end,now()+interval '30 days',
 case when p_evento->>'texto_longo'='true' then '{"texto_longo":true}'::jsonb else null end) returning id into mid;
 if humana then
  -- Se o HTTP de saída ainda não retornou seu ID, aguardar reconciliação antes de chamar o eco de humano.
  if exists(select 1 from atendimento_v3.turnos where conversa_id=cv.id and estado='enviando' and expira_em>now())
  or exists(select 1 from atendimento_v3.alertas where empresa_id=e and numero=split_part(jid,'@',1) and estado='enviando' and criado_em>now()-interval '2 minutes') then
   update public.mensagens set estado_processamento='recebida',metadados='{"classificar_saida":true}' where id=mid;
   return jsonb_build_object('acao','registrada','motivo','saida_em_classificacao');
  end if;
  update public.conversas set modo_atendimento='humano',pausado_ate=now()+interval '30 minutes',ultima_mensagem_humana_em=now(),versao_controle=versao_controle+1 where id=cv.id;
  update public.mensagens set estado_processamento='ignorada',processada_em=now() where conversa_id=cv.id
   and direcao='entrada' and estado_processamento in ('recebida','pendente','processando');
  update atendimento_v3.turnos set estado='invalidado' where conversa_id=cv.id and estado='processando';
  return jsonb_build_object('acao','ignorar','motivo','humano');
 end if;
 update public.conversas set ultima_mensagem_cliente_em=now() where id=cv.id;
 return jsonb_build_object('acao',case when tipo='audio' then 'transcrever' else 'registrada' end,'mensagem_id',mid,'instancia',p_instancia);
end $$;

create function public.a24_v3_audio(p_mensagem uuid,p_texto text) returns jsonb
language plpgsql security definer set search_path=pg_catalog as $$
begin
 if length(p_texto)>12000 then p_texto:=null; end if;
 update public.mensagens set conteudo_texto=case when nullif(btrim(p_texto),'') is null then null else left(btrim(p_texto),12000) end,
 tipo_mensagem=case when nullif(btrim(p_texto),'') is null then 'outro'::public.mensagem_tipo else 'audio'::public.mensagem_tipo end,
 metadados=case when nullif(btrim(p_texto),'') is null then '{"falha_audio":true}'::jsonb else '{}'::jsonb end,
 estado_processamento='pendente' where id=p_mensagem and tipo_mensagem='audio' and estado_processamento='recebida';
 return jsonb_build_object('sucesso',true);
end $$;

create function public.a24_v3_reservar(p_instancia text) returns jsonb
language plpgsql security definer set search_path=pg_catalog as $$
declare e public.empresas%rowtype; cv public.conversas%rowtype; cfg public.empresa_configuracoes%rowtype; ids uuid[]; tok uuid; txt text; unsupported bool; audio_fail bool; long_text bool; hist jsonb; n int; pend record; alerta atendimento_v3.alertas%rowtype;
begin
 select * into e from public.empresas where instancia_evolution=p_instancia and status_operacional='ativo';
 if not found then return jsonb_build_object('pronto',false); end if;
 -- Serializa reserva e contador por empresa. Não mantém lock durante chamada externa.
 perform pg_advisory_xact_lock(hashtextextended('worker-v3:'||e.id,0));
 select * into cfg from public.empresa_configuracoes where empresa_id=e.id;
 -- Histórico conversacional de 24h; descarte operacional de conteúdo em 30 dias.
 update atendimento_v3.turnos set resposta=null,chave_operacao=null where empresa_id=e.id and criado_em<now()-interval '30 days' and resposta is not null;
 update public.mensagens set conteudo_texto=null,metadados=null where empresa_id=e.id and excluir_em<=now() and conteudo_texto is not null;
 select * into alerta from atendimento_v3.alertas where empresa_id=e.id and estado='pendente' order by criado_em limit 1 for update;
 if found then
  update atendimento_v3.alertas set estado='enviando' where id=alerta.id;
  return jsonb_build_object('pronto',false,'alerta',true,'alerta_id',alerta.id,'instancia',p_instancia,'numero',alerta.numero,
   'texto','O atendimento automático atingiu o limite de segurança em uma conversa e foi pausado por duas horas. Confira o registro operacional da Agenda24h. Referência: '||alerta.conversa_id);
 end if;
 -- Execução interrompida não é repetida automaticamente após possível mutação/envio.
 update public.mensagens m set estado_processamento='falhou',erro_sanitizado='EXECUCAO_EXPIRADA'
 from atendimento_v3.turnos t where t.empresa_id=e.id and t.estado in ('processando','enviando')
 and t.expira_em<now() and m.id=any(t.mensagens) and m.estado_processamento='processando';
 update atendimento_v3.turnos set estado='falhou',erro='EXECUCAO_EXPIRADA_REVISAR' where empresa_id=e.id and estado in ('processando','enviando') and expira_em<now();
 -- Ecos reconciliados pelo finalizar já são processados. Saídas restantes são intervenções humanas.
 for pend in select m.* from public.mensagens m where m.empresa_id=e.id and m.direcao='saida'
 and m.estado_processamento='recebida' and m.metadados->>'classificar_saida'='true'
 and m.recebida_em<now()-interval '5 seconds'
 and not exists(select 1 from atendimento_v3.turnos tt where tt.conversa_id=m.conversa_id and tt.estado='enviando')
 order by m.recebida_em loop
  perform 1 from public.conversas where id=pend.conversa_id for update;
  update public.conversas set modo_atendimento='humano',pausado_ate=greatest(now(),pend.recebida_em+interval '30 minutes'),
   ultima_mensagem_humana_em=pend.recebida_em,versao_controle=versao_controle+1 where id=pend.conversa_id;
  update public.mensagens set estado_processamento='ignorada',processada_em=now() where conversa_id=pend.conversa_id
   and direcao='entrada' and recebida_em<=pend.recebida_em and estado_processamento in ('recebida','pendente','processando');
  update atendimento_v3.turnos set estado='invalidado' where conversa_id=pend.conversa_id and estado='processando';
  update public.mensagens set estado_processamento='processada',metadados=null where id=pend.id;
 end loop;
 update public.mensagens set estado_processamento='pendente',tipo_mensagem='outro',metadados='{"falha_audio":true}'
 where empresa_id=e.id and tipo_mensagem='audio' and estado_processamento='recebida' and recebida_em<now()-interval '3 minutes';
 if (select count(*) from atendimento_v3.turnos where empresa_id=e.id and criado_em>now()-interval '1 minute')>=cfg.limite_ia_por_empresa_min then
  return jsonb_build_object('pronto',false); end if;
 select c.* into cv from public.conversas c join public.clientes cl on cl.id=c.cliente_id
 where c.empresa_id=e.id and cl.anonimizado_em is null and cl.status_cadastro<>'bloqueado'
 and (c.modo_atendimento='ia' or c.pausado_ate<=now())
 and not exists(select 1 from atendimento_v3.turnos t where t.conversa_id=c.id and t.estado in ('processando','enviando'))
 and not exists(select 1 from atendimento_v3.limites l where l.conversa_id=c.id and l.bloqueado_ate>now())
 and exists(select 1 from public.mensagens m where m.conversa_id=c.id and m.estado_processamento='pendente' and m.direcao='entrada')
 and not exists(select 1 from public.mensagens m where m.conversa_id=c.id and m.direcao='entrada' and
 (m.estado_processamento='recebida' or (m.estado_processamento='pendente' and m.recebida_em>now()-interval '15 seconds')))
 order by c.ultima_mensagem_cliente_em limit 1 for update of c skip locked;
 if not found then return jsonb_build_object('pronto',false); end if;
 select count(*) into n from atendimento_v3.turnos where conversa_id=cv.id and criado_em>now()-interval '5 minutes';
 if n>=cfg.limite_ia_por_contato_5min then
  insert into atendimento_v3.limites values(cv.id,now()+interval '2 hours') on conflict(conversa_id) do update set bloqueado_ate=excluded.bloqueado_ate;
  insert into public.logs_auditoria(empresa_id,entidade_tipo,entidade_id,acao,ator_tipo,resultado,metadados_sanitizados)
  values(e.id,'conversa',cv.id,'limite_ia','sistema','pausado','{"duracao_min":120}');
  if cfg.numero_notificacao ~ '^[+]?[1-9][0-9]{7,14}$' then
   insert into atendimento_v3.alertas(empresa_id,conversa_id,numero) values(e.id,cv.id,regexp_replace(cfg.numero_notificacao,'[^0-9]','','g'));
  end if;
  return jsonb_build_object('pronto',false,'motivo','limite');
 end if;
 select array_agg(id order by recebida_em,id),string_agg(conteudo_texto,E'\n' order by recebida_em,id) filter(where tipo_mensagem in ('texto','audio')),
 bool_or(tipo_mensagem='outro' and coalesce((metadados->>'falha_audio')::boolean,false)=false and coalesce((metadados->>'texto_longo')::boolean,false)=false),
 bool_or(coalesce((metadados->>'falha_audio')::boolean,false)),bool_or(coalesce((metadados->>'texto_longo')::boolean,false)) into ids,txt,unsupported,audio_fail,long_text
 from (select * from public.mensagens where conversa_id=cv.id and estado_processamento='pendente' and direcao='entrada' order by recebida_em,id limit 30) x;
 update public.conversas set modo_atendimento='ia',pausado_ate=null where id=cv.id;
 insert into atendimento_v3.turnos(empresa_id,conversa_id,cliente_id,versao,mensagens) values(e.id,cv.id,cv.cliente_id,cv.versao_controle,ids) returning token into tok;
 update public.mensagens set estado_processamento='processando' where id=any(ids);
 select coalesce(jsonb_agg(jsonb_build_object('origem',h.origem,'texto',h.conteudo_texto) order by h.recebida_em),'[]') into hist
 from(select origem,conteudo_texto,recebida_em from public.mensagens where conversa_id=cv.id and estado_processamento='processada'
 and conteudo_texto is not null and recebida_em>now()-interval '24 hours' order by recebida_em desc limit 12) h;
 return jsonb_build_object('pronto',true,'token',tok,'instancia',p_instancia,'jid',(select whatsapp_jid from public.clientes where id=cv.cliente_id),
 'nome',(select nome from public.clientes where id=cv.cliente_id),'mensagem',coalesce(txt,''),'nao_suportado',unsupported,'falha_audio',audio_fail,'texto_longo',long_text,
 'historico',hist,'contexto',public.carregar_contexto_ia(e.id),'agora',to_char(now() at time zone e.fuso_horario,'YYYY-MM-DD"T"HH24:MI:SS'),'fuso',e.fuso_horario);
end $$;

create function public.a24_v3_tool(p_token uuid,p_acao text,p_args jsonb) returns jsonb
language plpgsql security definer set search_path=pg_catalog as $$
declare t atendimento_v3.turnos%rowtype; cv public.conversas%rowtype; e public.empresas%rowtype; cfg public.empresa_configuracoes%rowtype;
 a public.agendamentos%rowtype; prof uuid; serv uuid; dt timestamptz; data_busca date; d date; slot record; saida jsonb:='[]'; catalogo jsonb;
 r jsonb; aid uuid; mutation bool; chave jsonb; motivo text; nome text; h record; preco numeric; prazo int;
begin
 select * into t from atendimento_v3.turnos where token=p_token;
 if not found then return jsonb_build_object('sucesso',false,'codigo','SESSAO_INVALIDA'); end if;
 select * into cv from public.conversas where id=t.conversa_id for update;
 select * into t from atendimento_v3.turnos where token=p_token for update;
 if t.estado<>'processando' or t.expira_em<=now() or cv.versao_controle<>t.versao or cv.modo_atendimento<>'ia' then
 return jsonb_build_object('sucesso',false,'codigo','SESSAO_ENCERRADA'); end if;
 select * into e from public.empresas where id=t.empresa_id and status_operacional='ativo';
 if not found or not exists(select 1 from public.clientes where id=t.cliente_id and anonimizado_em is null and status_cadastro<>'bloqueado') then
 return jsonb_build_object('sucesso',false,'codigo','ATENDIMENTO_INDISPONIVEL'); end if;
 select * into cfg from public.empresa_configuracoes where empresa_id=t.empresa_id;
 if p_acao='nome' then
  nome:=btrim(p_args->>'nome');
  if nome is null or length(nome)<2 or length(nome)>100 or nome ~ '[0-9<>\n\r]' then return jsonb_build_object('sucesso',false,'codigo','NOME_INVALIDO'); end if;
  perform public.definir_nome_cliente(t.empresa_id,t.cliente_id,nome);
  return jsonb_build_object('sucesso',true,'nome',nome);
 elsif p_acao='humano' then
  update public.conversas set modo_atendimento='humano',pausado_ate=now()+interval '30 minutes',versao_controle=versao_controle+1 where id=cv.id;
  update atendimento_v3.turnos set transferencia_solicitada=true where token=p_token;
  -- A resposta de transferência será emitida deterministicamente pela etapa de envio.
  return jsonb_build_object('sucesso',true,'codigo','TRANSFERIDO','numero',cfg.numero_atendimento_humano);
 elsif p_acao='meus' then
  select coalesce(jsonb_agg(to_jsonb(x)),'[]') into r from public.listar_agendamentos_cliente(t.empresa_id,t.cliente_id) x;
  return jsonb_build_object('sucesso',true,'agendamentos',r);
 end if;
 mutation:=p_acao in ('agendar','reagendar','cancelar');
 if p_acao not in ('buscar','verificar','agendar','reagendar','cancelar') then return jsonb_build_object('sucesso',false,'codigo','ACAO_INVALIDA'); end if;
 chave:=jsonb_build_object('acao',p_acao,'args',p_args);
 if mutation and t.chave_operacao is not null then
  if t.chave_operacao=chave then return t.resultado_operacao||'{"repeticao":true}'::jsonb; end if;
  return jsonb_build_object('sucesso',false,'codigo','UMA_ALTERACAO_POR_TURNO','mensagem','Confirme a próxima alteração em uma nova mensagem.');
 end if;
 if mutation and coalesce((p_args->>'confirmado')::boolean,false)=false then return jsonb_build_object('sucesso',false,'codigo','CONFIRMACAO_NECESSARIA'); end if;
 if mutation then perform pg_advisory_xact_lock(hashtextextended('agenda-v3:'||t.empresa_id,0)); end if;
 if p_acao in ('cancelar','reagendar') then
  select * into a from public.agendamentos where id=(p_args->>'agendamento_id')::uuid and empresa_id=t.empresa_id and cliente_id=t.cliente_id for update;
  if not found then return jsonb_build_object('sucesso',false,'codigo','AGENDAMENTO_NAO_ENCONTRADO'); end if;
  if a.status<>'confirmado' then return jsonb_build_object('sucesso',false,'codigo','ESTADO_INCOMPATIVEL'); end if;
  perform 1 from public.fila_mensagens where agendamento_id=a.id and estado in ('pendente','processando') for update;
  if exists(select 1 from public.fila_mensagens where agendamento_id=a.id and estado='processando') then
   return jsonb_build_object('sucesso',false,'codigo','LEMBRETE_EM_PROCESSAMENTO','mensagem','Tente novamente em instantes.'); end if;
  prazo:=cfg.antecedencia_cancelamento_min;
  if a.inicio_em<now()+make_interval(mins=>prazo) then return jsonb_build_object('sucesso',false,'codigo','PRAZO_ALTERACAO',
   'antecedencia_min',prazo,'numero_reserva',cfg.numero_reserva,'mensagem','Alteração automática fora do prazo permitido.'); end if;
  prof:=a.profissional_id; serv:=a.servico_id;
 else
  prof:=nullif(p_args->>'profissional_id','')::uuid; serv:=nullif(p_args->>'servico_id','')::uuid;
 end if;
 if p_acao='buscar' then
  select coalesce(jsonb_agg(jsonb_build_object('servico_id',s.id,'servico',s.nome,'profissional_id',p.id,'profissional',p.nome,
   'duracao_min',coalesce(ps.duracao_min_override,s.duracao_min),'preco',coalesce(ps.preco_override,s.preco),'requer_avaliacao',s.requer_avaliacao)),'[]') into catalogo
  from public.profissional_servicos ps join public.servicos s on s.id=ps.servico_id and s.empresa_id=ps.empresa_id
  join public.profissionais p on p.id=ps.profissional_id and p.empresa_id=ps.empresa_id
  where ps.empresa_id=t.empresa_id and ps.ativo and s.ativo and p.ativo;
  if serv is null or prof is null then return jsonb_build_object('sucesso',true,'catalogo',catalogo,'horarios','[]'::jsonb,'mensagem','Escolha serviço e profissional para consultar horários.'); end if;
  if not exists(select 1 from jsonb_array_elements(catalogo) x where x->>'servico_id'=serv::text and x->>'profissional_id'=prof::text) then raise exception 'Serviço ou profissional inválido'; end if;
  data_busca:=coalesce(nullif(p_args->>'data','')::date,(now() at time zone e.fuso_horario)::date);
  if data_busca<(now() at time zone e.fuso_horario)::date or data_busca>(now() at time zone e.fuso_horario)::date+365 then raise exception 'Data fora da janela de consulta'; end if;
  for d in select data_busca+i from generate_series(0,6) i loop
   for slot in select * from public.buscar_horarios_disponiveis(t.empresa_id,prof,serv,d,30::smallint) loop
    begin
     perform atendimento_v3.validar_slot(t.empresa_id,prof,serv,slot.inicio_em);
     saida:=saida||jsonb_build_array(to_jsonb(slot));
    exception when raise_exception then null; end;
    exit when jsonb_array_length(saida)>=10;
   end loop;
   exit when jsonb_array_length(saida)>=10;
  end loop;
  return jsonb_build_object('sucesso',true,'catalogo',catalogo,'horarios',saida,'fuso',e.fuso_horario);
 end if;
 if p_acao<>'cancelar' then
  -- Exigir offset para nunca interpretar hora local no fuso do servidor.
  if coalesce(p_args->>'inicio_em','') !~ '^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(Z|[+-]\d{2}:\d{2})$' then
   return jsonb_build_object('sucesso',false,'codigo','DATA_COM_FUSO_OBRIGATORIA'); end if;
  dt:=(p_args->>'inicio_em')::timestamptz;
  perform atendimento_v3.validar_slot(t.empresa_id,prof,serv,dt,case when p_acao='reagendar' then a.id else null end);
 end if;
 if p_acao='verificar' then return jsonb_build_object('sucesso',true,'disponivel',true,'inicio_em',dt,'fuso',e.fuso_horario); end if;
 if p_acao='agendar' then
  aid:=public.criar_agendamento(t.empresa_id,t.cliente_id,prof,serv,dt);
 elsif p_acao='reagendar' then
  aid:=public.reagendar_agendamento(t.empresa_id,t.cliente_id,a.id,prof,serv,dt);
 else
  perform public.cancelar_agendamento(t.empresa_id,t.cliente_id,a.id); aid:=a.id;
 end if;
 select jsonb_build_object('sucesso',true,'agendamento_id',x.id,'status',x.status,'inicio_em',x.inicio_em,'fuso',e.fuso_horario,'acao',p_acao) into r from public.agendamentos x where x.id=aid;
 update atendimento_v3.turnos set chave_operacao=chave,resultado_operacao=r where token=p_token;
 return r;
exception
 when invalid_text_representation or invalid_datetime_format or datetime_field_overflow then return jsonb_build_object('sucesso',false,'codigo','ENTRADA_INVALIDA');
 when exclusion_violation then return jsonb_build_object('sucesso',false,'codigo','HORARIO_OCUPADO');
 when raise_exception then
  -- Mensagens controladas das regras de negócio; não expor SQL/credenciais.
  motivo:=SQLERRM;
  if motivo not in ('Horário não respeita a antecedência mínima','Horário fora do expediente da empresa','Horário fora do expediente do profissional',
  'Horário bloqueado na agenda','Horário já ocupado','Profissional não está habilitado para este serviço','Serviço ou profissional inválido',
  'Limite diário atingido','Atendimento atravessa o encerramento do dia','Data fora da janela de consulta','Cliente inválido para agendamento') then motivo:='Não foi possível executar a operação.'; end if;
  return jsonb_build_object('sucesso',false,'codigo','REGRA_AGENDA','mensagem',motivo);
end $$;

create function public.a24_v3_preparar_envio(p_token uuid,p_resposta text) returns jsonb
language plpgsql security definer set search_path=pg_catalog as $$
declare t atendimento_v3.turnos%rowtype; cv public.conversas%rowtype; texto text; cfg public.empresa_configuracoes%rowtype;
begin
 select * into t from atendimento_v3.turnos where token=p_token;
 if not found or t.estado<>'processando' or t.expira_em<=now() then return jsonb_build_object('enviar',false); end if;
 select * into cv from public.conversas where id=t.conversa_id for update;
 select * into t from atendimento_v3.turnos where token=p_token for update;
 if t.estado<>'processando' or t.expira_em<=now() then return jsonb_build_object('enviar',false); end if;
 if not exists(select 1 from public.empresas where id=t.empresa_id and status_operacional='ativo') or not exists(select 1 from public.clientes where id=t.cliente_id and anonimizado_em is null and status_cadastro<>'bloqueado') then
  update atendimento_v3.turnos set estado='invalidado' where token=p_token;
  update public.mensagens set estado_processamento='ignorada' where id=any(t.mensagens) and estado_processamento='processando';
  return jsonb_build_object('enviar',false);
 end if;
 if cv.versao_controle<>t.versao or cv.modo_atendimento<>'ia' then
  -- Somente transferência pedida por esta execução; intervenção humana invalida o turno no recebimento.
  if t.transferencia_solicitada and cv.modo_atendimento='humano' and cv.versao_controle=t.versao+1 then
   select * into cfg from public.empresa_configuracoes where empresa_id=t.empresa_id;
   texto:=coalesce(nullif(cfg.mensagem_transferencia,''),'Vou encaminhar seu pedido para atendimento humano.')
    ||case when cfg.numero_atendimento_humano is not null then ' Contato: '||cfg.numero_atendimento_humano else '' end;
  else return jsonb_build_object('enviar',false); end if;
 else texto:=nullif(btrim(p_resposta),''); end if;
 if texto is null then texto:='Não consegui concluir seu atendimento agora. Por favor, tente novamente em instantes.'; end if;
 update atendimento_v3.turnos set estado='enviando',resposta=texto,expira_em=now()+interval '2 minutes' where token=p_token;
 return jsonb_build_object('enviar',true,'token',p_token,'texto',texto,
 'instancia',(select instancia_evolution from public.empresas where id=t.empresa_id),'jid',(select whatsapp_jid from public.clientes where id=t.cliente_id));
end $$;

create function public.a24_v3_finalizar(p_token uuid,p_evolution_id text) returns jsonb
language plpgsql security definer set search_path=pg_catalog as $$
declare t atendimento_v3.turnos%rowtype;
begin
 select * into t from atendimento_v3.turnos where token=p_token;
 if not found or t.estado<>'enviando' then return jsonb_build_object('sucesso',false); end if;
 perform 1 from public.conversas where id=t.conversa_id for update;
 select * into t from atendimento_v3.turnos where token=p_token for update;
 if t.estado<>'enviando' then return jsonb_build_object('sucesso',false); end if;
 if nullif(p_evolution_id,'') is null then
  update atendimento_v3.turnos set estado='falhou',erro='ENVIO_INDETERMINADO_REVISAR' where token=p_token;
  update public.mensagens set estado_processamento='falhou',erro_sanitizado='ENVIO_INDETERMINADO_REVISAR' where id=any(t.mensagens) and estado_processamento='processando';
  insert into public.logs_auditoria(empresa_id,entidade_tipo,entidade_id,acao,ator_tipo,resultado) values(t.empresa_id,'conversa',t.conversa_id,'envio_whatsapp','sistema','indeterminado');
  return jsonb_build_object('sucesso',false);
 end if;
 insert into public.mensagens(empresa_id,conversa_id,cliente_id,evolution_message_id,direcao,origem,tipo_mensagem,conteudo_texto,estado_processamento,excluir_em)
 values(t.empresa_id,t.conversa_id,t.cliente_id,p_evolution_id,'saida','ia','texto',t.resposta,'processada',now()+interval '30 days')
 on conflict(empresa_id,evolution_message_id) do update set origem='ia',estado_processamento='processada',metadados=null,
 conteudo_texto=excluded.conteudo_texto where public.mensagens.conversa_id=excluded.conversa_id;
 update atendimento_v3.turnos set estado='enviado',evolution_message_id=p_evolution_id where token=p_token;
 update public.mensagens set estado_processamento='processada',processada_em=now() where id=any(t.mensagens) and estado_processamento='processando';
 update public.conversas set ultima_mensagem_ia_em=now() where id=t.conversa_id;
 return jsonb_build_object('sucesso',true);
end $$;

create function public.a24_v3_alerta_finalizar(p_id uuid,p_evolution_id text) returns jsonb
language plpgsql security definer set search_path=pg_catalog as $$
declare a atendimento_v3.alertas%rowtype;
begin
 select * into a from atendimento_v3.alertas where id=p_id and estado='enviando' for update;
 if not found then return jsonb_build_object('sucesso',false); end if;
 update atendimento_v3.alertas set estado=case when nullif(p_evolution_id,'') is null then 'falhou' else 'enviado' end,
 evolution_message_id=nullif(p_evolution_id,'') where id=p_id and estado='enviando';
 update public.mensagens set estado_processamento='processada',origem='automacao',metadados=null
 where empresa_id=a.empresa_id and evolution_message_id=p_evolution_id and direcao='saida';
 return jsonb_build_object('sucesso',true);
end $$;

revoke all on all functions in schema atendimento_v3 from public,anon,authenticated,service_role;
revoke all on function public.a24_v3_receber(text,jsonb),public.a24_v3_audio(uuid,text),public.a24_v3_reservar(text),
 public.a24_v3_tool(uuid,text,jsonb),public.a24_v3_preparar_envio(uuid,text),public.a24_v3_finalizar(uuid,text),public.a24_v3_alerta_finalizar(uuid,text) from public,anon,authenticated,service_role;
grant execute on function public.a24_v3_receber(text,jsonb),public.a24_v3_audio(uuid,text),public.a24_v3_reservar(text),
 public.a24_v3_tool(uuid,text,jsonb),public.a24_v3_preparar_envio(uuid,text),public.a24_v3_finalizar(uuid,text),public.a24_v3_alerta_finalizar(uuid,text) to agenda24h_atendimento;
create or replace function public.cancelar_agendamento(
  p_empresa_id uuid,
  p_cliente_id uuid,
  p_agendamento_id uuid,
  p_motivo text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_agendamento public.agendamentos%rowtype;
  v_min_cancelamento smallint;
begin
  select a.* into v_agendamento
  from public.agendamentos a
  where a.id = p_agendamento_id
    and a.empresa_id = p_empresa_id
    and a.cliente_id = p_cliente_id
  for update;

  if not found then
    raise exception 'Agendamento não encontrado';
  end if;

  select antecedencia_cancelamento_min into v_min_cancelamento
  from public.empresa_configuracoes
  where empresa_id = p_empresa_id;

  if v_agendamento.status <> 'confirmado' then
    raise exception 'Agendamento não pode ser cancelado';
  end if;

  if v_agendamento.inicio_em < now() + make_interval(mins => v_min_cancelamento) then
    raise exception 'Cancelamento automático não permitido neste prazo';
  end if;

  update public.agendamentos
  set status = 'cancelado', cancelado_em = now(), motivo_cancelamento = p_motivo
  where id = p_agendamento_id and empresa_id = p_empresa_id;

  update public.fila_mensagens
  set estado = 'cancelado', cancelado_em = now()
  where empresa_id = p_empresa_id
    and agendamento_id = p_agendamento_id
    and estado in ('pendente', 'processando');

  insert into public.agendamento_eventos (
    empresa_id, agendamento_id, tipo, origem, ator_tipo, motivo
  ) values (
    p_empresa_id, p_agendamento_id, 'cancelado', 'cliente_whatsapp', 'cliente', p_motivo
  );
end;
$$;

create or replace function public.reagendar_agendamento(
  p_empresa_id uuid,
  p_cliente_id uuid,
  p_agendamento_id uuid,
  p_profissional_id uuid,
  p_servico_id uuid,
  p_novo_inicio_em timestamptz,
  p_motivo text default null
)
returns uuid
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_agendamento public.agendamentos%rowtype;
  v_min_cancelamento smallint;
  v_config public.empresa_configuracoes%rowtype;
  v_duracao_min smallint;
  v_preco numeric(12,2);
begin
  select a.* into v_agendamento
  from public.agendamentos a
  where a.id = p_agendamento_id
    and a.empresa_id = p_empresa_id
    and a.cliente_id = p_cliente_id
  for update;

  if not found then
    raise exception 'Agendamento não encontrado';
  end if;

  select antecedencia_cancelamento_min into v_min_cancelamento
  from public.empresa_configuracoes
  where empresa_id = p_empresa_id;

  if v_agendamento.status <> 'confirmado' then
    raise exception 'Agendamento não pode ser remarcado';
  end if;

  if v_agendamento.inicio_em < now() + make_interval(mins => v_min_cancelamento) then
    raise exception 'Remarcação automática não permitida neste prazo';
  end if;

  perform public.verificar_disponibilidade(
    p_empresa_id, p_profissional_id, p_servico_id, p_novo_inicio_em, p_agendamento_id
  );

  select * into v_config from public.empresa_configuracoes where empresa_id = p_empresa_id;

  select coalesce(ps.duracao_min_override, s.duracao_min),
         coalesce(ps.preco_override, s.preco)
  into v_duracao_min, v_preco
  from public.profissional_servicos ps
  join public.servicos s on s.id = ps.servico_id and s.empresa_id = ps.empresa_id
  where ps.empresa_id = p_empresa_id
    and ps.profissional_id = p_profissional_id
    and ps.servico_id = p_servico_id
    and ps.ativo and s.ativo;

  update public.agendamentos
  set profissional_id = p_profissional_id,
      servico_id = p_servico_id,
      inicio_em = p_novo_inicio_em,
      fim_atendimento_em = p_novo_inicio_em + make_interval(mins => v_duracao_min),
      fim_bloqueio_em = p_novo_inicio_em + make_interval(mins => v_duracao_min + v_config.buffer_posterior_min),
      duracao_min = v_duracao_min,
      preco = v_preco
  where id = p_agendamento_id and empresa_id = p_empresa_id;

  update public.fila_mensagens
  set estado = 'cancelado', cancelado_em = now()
  where empresa_id = p_empresa_id
    and agendamento_id = p_agendamento_id
    and estado in ('pendente', 'processando');

  perform public.programar_lembretes_agendamento(
    p_empresa_id, p_cliente_id, p_agendamento_id, p_novo_inicio_em
  );

  insert into public.agendamento_eventos (
    empresa_id, agendamento_id, tipo, origem, ator_tipo, dados_anteriores, dados_novos, motivo
  ) values (
    p_empresa_id, p_agendamento_id, 'reagendado', 'cliente_whatsapp', 'cliente',
    jsonb_build_object('inicio_em', v_agendamento.inicio_em, 'profissional_id', v_agendamento.profissional_id, 'servico_id', v_agendamento.servico_id),
    jsonb_build_object('inicio_em', p_novo_inicio_em, 'profissional_id', p_profissional_id, 'servico_id', p_servico_id),
    p_motivo
  );

  return p_agendamento_id;
end;
$$;

create or replace function public.programar_lembretes_agendamento(
  p_empresa_id uuid,
  p_cliente_id uuid,
  p_agendamento_id uuid,
  p_inicio_em timestamptz
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_config public.empresa_configuracoes%rowtype;
  v_quando timestamptz;
begin
  select * into v_config
  from public.empresa_configuracoes
  where empresa_id = p_empresa_id;

  if v_config.lembrete_24h_ativo then
    v_quando := p_inicio_em - interval '24 hours';
    if v_quando > now() then
      insert into public.fila_mensagens (
        empresa_id, cliente_id, agendamento_id, tipo, chave_idempotencia, programado_para
      ) values (
        p_empresa_id, p_cliente_id, p_agendamento_id, 'lembrete_24h',
        format('agendamento:%s:lembrete_24h:%s', p_agendamento_id, p_inicio_em), v_quando
      ) on conflict (chave_idempotencia) do update set estado='pendente',programado_para=excluded.programado_para,
       cancelado_em=null,processando_em=null,ultimo_erro=null,tentativas=0
       where public.fila_mensagens.estado='cancelado';
    end if;
  end if;

  if v_config.lembrete_2h_ativo then
    v_quando := p_inicio_em - interval '2 hours';
    if v_quando > now() then
      insert into public.fila_mensagens (
        empresa_id, cliente_id, agendamento_id, tipo, chave_idempotencia, programado_para
      ) values (
        p_empresa_id, p_cliente_id, p_agendamento_id, 'lembrete_2h',
        format('agendamento:%s:lembrete_2h:%s', p_agendamento_id, p_inicio_em), v_quando
      ) on conflict (chave_idempotencia) do update set estado='pendente',programado_para=excluded.programado_para,
       cancelado_em=null,processando_em=null,ultimo_erro=null,tentativas=0
       where public.fila_mensagens.estado='cancelado';
    end if;
  end if;
end;
$$;
commit;
