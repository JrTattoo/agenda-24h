# Validação local do WF1 — 22/09/2026

Alvo: `json/principal.json`, workflow **WF1 - Agenda24h V3 - Texto e Audio**.

## Resultado

Comando executado nesta pasta: `node --test tests/*.test.mjs`.

**49 testes aprovados, 0 falhas.** A bateria anterior tinha 46 testes; foram acrescentadas simulações de entrada da Evolution, validação de arquivo de áudio e composição das respostas determinísticas.

## Cenários cobertos

- Entrada: texto curto/estendido, texto vazio, áudio PTT, imagem com legenda, eventos de status, instância diferente, ID ausente ou longo demais, identidade incompleta, grupo e `@lid` sem mapeamento.
- Áudio: MIME válido, MIME inadequado, conteúdo ausente, formato inválido e tamanho acima do limite técnico.
- Resposta: falha de transcrição, mídia sem suporte, texto longo, saída vazia do agente e erro do atendimento.
- Banco isolado: deduplicação, mensagens consecutivas, catálogo, nome, disponibilidade, agendamento idempotente, lembretes, cancelamento/remarcação, isolamento entre empresas/clientes, pausa humana, retomada, eco do bot, envio incerto e anonimização.
- Estrutura dos sete JSONs: referências internas, sintaxe dos nós Code, configuração declarada de autenticação e estado inativo.

## Limite da evidência

Os testes executam o código dos nós Code e o contrato SQL em PostgreSQL isolado. Não executam o motor do n8n, o modelo OpenAI, a Evolution nem o WhatsApp. Portanto, não comprovam que a IA interpretará corretamente confirmações, datas relativas e pedidos ambíguos, nem que áudio OGG real, credenciais, nós importados e entrega de mensagens funcionarão na instalação.

## Homologação ainda necessária

1. Conferir o schema remoto e importar/configurar os workflows em ambiente de teste.
2. Testar texto e áudio reais pela instância Evolution de teste.
3. Testar com o modelo: nome, dúvidas, datas relativas, confirmação explícita, cancelamento/remarcação, pedido humano, erros de tool e tentativas de obter dados de terceiros.
4. Validar concorrência com duas conexões reais, pausas, retomada após reinício e falhas de envio.
5. Registrar resultado e evidência de cada cenário antes de ativar para clientes.
