-- SOMENTE LEITURA. Executar no banco de homologação antes da migration.
-- Nenhuma senha, token ou conteúdo de conversa é consultado.
select current_database() as banco, version() as versao;
select x.nome,to_regclass('public.'||x.nome) is not null as existe
from unnest(array['empresas','empresa_configuracoes','clientes','conversas','mensagens',
 'profissionais','servicos','profissional_servicos','horarios_empresa','horarios_profissionais',
 'excecoes_agenda','agendamentos','agendamento_eventos','fila_mensagens','logs_auditoria']) x(nome);
select column_name,data_type from information_schema.columns
where table_schema='public' and table_name='empresa_configuracoes'
and column_name in ('numero_notificacao','numero_reserva','limite_ia_por_contato_5min','limite_ia_por_empresa_min','limite_agendamentos_diarios');
select x.assinatura,to_regprocedure(x.assinatura) is not null as existe from unnest(array[
 'public.verificar_disponibilidade(uuid,uuid,uuid,timestamp with time zone,uuid)',
 'public.buscar_horarios_disponiveis(uuid,uuid,uuid,date,smallint)',
 'public.criar_agendamento(uuid,uuid,uuid,uuid,timestamp with time zone,public.agendamento_origem,text,uuid)',
 'public.reagendar_agendamento(uuid,uuid,uuid,uuid,uuid,timestamp with time zone,text)',
 'public.cancelar_agendamento(uuid,uuid,uuid,text)',
 'public.listar_agendamentos_cliente(uuid,uuid)',
 'public.carregar_contexto_ia(uuid)',
 'public.definir_nome_cliente(uuid,uuid,text)']) x(assinatura);
select conname,contype,pg_get_constraintdef(oid) as definicao from pg_constraint
where conrelid=to_regclass('public.agendamentos') and conname='agendamentos_sem_sobreposicao_profissional';
select exists(select 1 from pg_roles where rolname='agenda24h_atendimento') as papel_ja_existe,
 exists(select 1 from pg_namespace where nspname='atendimento_v3') as schema_ja_existe;
-- Se papel/schema já existem, NÃO reaplicar a migration nem apagá-los automaticamente.
select count(*) as telefones_incompativeis from public.clientes
where anonimizado_em is null and (telefone_e164 is null or telefone_e164 !~ '^[+][1-9][0-9]{7,14}$');
select codigo,instancia_evolution,status_operacional,fuso_horario from public.empresas order by codigo;
