import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {resolve,dirname} from 'node:path';
import {createHash} from 'node:crypto';
const dir=dirname(fileURLToPath(import.meta.url));
const cfg=JSON.parse(readFileSync(process.argv[2]||resolve(dir,'config.exemplo.json'),'utf8'));
if(!/^https?:\/\/[^/]+$/.test(cfg.evolutionUrl)||!/^[a-zA-Z0-9_/-]+$/.test(cfg.webhookPath))throw Error('URL ou caminho inválido');
mkdirSync(resolve(dir,'json'),{recursive:true});
// Mantém as RPCs oficiais, corrigindo apenas a fronteira inclusiva das 24 horas.
const baseAgenda=readFileSync(resolve(dir,'../../supabase/migrations/202609090003_funcoes_agenda.sql'),'utf8');
const boundary=['cancelar_agendamento','reagendar_agendamento','programar_lembretes_agendamento'].map(name=>{
 const start=baseAgenda.indexOf('create or replace function public.'+name+'(');
 const end=baseAgenda.indexOf('$$;',start)+3;
 if(start<0||end<3)throw Error('RPC oficial ausente: '+name);
 let source=baseAgenda.slice(start,end).replace('v_agendamento.inicio_em <= now()','v_agendamento.inicio_em < now()');
 if(name==='programar_lembretes_agendamento')source=source.replaceAll('on conflict (chave_idempotencia) do nothing;',`on conflict (chave_idempotencia) do update set estado='pendente',programado_para=excluded.programado_para,
       cancelado_em=null,processando_em=null,ultimo_erro=null,tentativas=0
       where public.fila_mensagens.estado='cancelado';`);
 return source;
}).join('\n\n');
writeFileSync(resolve(dir,'migration-atendimento-v3.sql'),readFileSync(resolve(dir,'banco.sql'),'utf8').replace(/commit;\s*$/,()=>boundary+'\ncommit;\n'));
const ident=s=>{let x=createHash('sha256').update(s).digest('hex');return `${x.slice(0,8)}-${x.slice(8,12)}-4${x.slice(13,16)}-8${x.slice(17,20)}-${x.slice(20,32)}`;};
function workflow(name){return {name,nodes:[],connections:{},active:false,pinData:{},settings:{executionOrder:'v1',timezone:'America/Sao_Paulo',executionTimeout:240,saveDataErrorExecution:'none',saveDataSuccessExecution:'none',saveManualExecutions:false,saveExecutionProgress:false,availableInMCP:false},tags:[]};}
function add(w,name,type,parameters={},version=1,extra={}){const n={id:ident(w.name+name),name,type,typeVersion:version,position:[w.nodes.length*220,0],parameters,...extra};w.nodes.push(n);return name;}
const code=(w,n,s)=>add(w,n,'n8n-nodes-base.code',{jsCode:s},2);
function edge(w,a,b,index=0,type='main'){w.connections[a]??={};w.connections[a][type]??=[];while(w.connections[a][type].length<=index)w.connections[a][type].push([]);w.connections[a][type][index].push({node:b,type,index:0});}
function pg(w,n,q,args,onError){return add(w,n,'n8n-nodes-base.postgres',{operation:'executeQuery',query:q,options:{queryReplacement:args,connectionTimeout:10}},2.5,onError?{onError}:{});}
function iff(w,n,expr){return add(w,n,'n8n-nodes-base.if',{conditions:{options:{caseSensitive:true,leftValue:'',typeValidation:'strict',version:2},conditions:[{id:ident(n),leftValue:expr,rightValue:true,operator:{type:'boolean',operation:'true',singleValue:true}}],combinator:'and'},options:{}},2.2);}
const trigger=(w,fields)=>add(w,'Entrada','n8n-nodes-base.executeWorkflowTrigger',{workflowInputs:{values:fields.map(name=>({name}))}},1.1);
const save=(w,file)=>writeFileSync(resolve(dir,'json',file),JSON.stringify(w,null,2)+'\n');
const unwrap=`const r=$json.resultado; return [{json:r&&typeof r==='object'?r:{sucesso:false,codigo:'SERVICO_INDISPONIVEL',mensagem:'Não foi possível executar esta operação agora.'}}];`;
const names={guard:'_guard_antiloop V3',buscar:'_tool_buscarhorarios V3',verificar:'_tool_verificardisponibilidade V3',agendar:'_tool_agendarhorario V3',meus:'_tool_meusagendamentos V3',gerenciar:'_tool_gerenciar_agendamento V3'};
for(const k of ['buscar','verificar','agendar','meus','gerenciar']){
 const w=workflow(names[k]);trigger(w,['token','dados']);
 code(w,'Validar contrato',`const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
let args;try{args=JSON.parse($json.dados||'{}')}catch{args=null}
const permitido=${JSON.stringify(k==='gerenciar'?['reagendar','cancelar']:[k])};
const acao=${k==='gerenciar'?"args?.acao":JSON.stringify(k)};
if(!uuid.test($json.token||'')||!args||Array.isArray(args)||typeof args!=='object'||!permitido.includes(acao))return [{json:{valido:false,sucesso:false,codigo:'ENTRADA_INVALIDA'}}];
// A tool não aceita empresa/cliente/telefone fornecidos pelo modelo.
const allowed=['servico_id','profissional_id','inicio_em','agendamento_id','confirmado','data','acao'];
args=Object.fromEntries(Object.entries(args).filter(([k])=>allowed.includes(k)));delete args.acao;
return [{json:{valido:true,token:$json.token,acao,args}}];`);
 iff(w,'Contrato valido?','={{ $json.valido === true }}');
 pg(w,'Executar no banco','SELECT public.a24_v3_tool($1::uuid,$2::text,$3::jsonb) AS resultado;','={{ [$json.token, $json.acao, JSON.stringify($json.args)] }}','continueRegularOutput');
 code(w,'Resultado',unwrap);edge(w,'Entrada','Validar contrato');edge(w,'Validar contrato','Contrato valido?');edge(w,'Contrato valido?','Executar no banco');
 code(w,'Entrada recusada',`return [{json:{sucesso:false,codigo:'ENTRADA_INVALIDA'}}];`);edge(w,'Contrato valido?','Entrada recusada',1);edge(w,'Executar no banco','Resultado');save(w,`${k}.json`);
}
{
 const w=workflow(names.guard);trigger(w,['instancia','evento','token','dados']);
 iff(w,'Evento recebido?','={{ !!$json.evento }}');
 pg(w,'Registrar evento','SELECT public.a24_v3_receber($1::text,$2::jsonb) AS resultado;','={{ [$json.instancia, $json.evento] }}');
 code(w,'Validar acao',`let a;try{a=JSON.parse($json.dados)}catch{a={}}
if(!['nome','humano'].includes(a.acao))return [{json:{token:$json.token,acao:'invalida',args:{}}}];
return [{json:{token:$json.token,acao:a.acao,args:a.acao==='nome'?{nome:a.nome}:{}}}];`);
 pg(w,'Atualizar atendimento','SELECT public.a24_v3_tool($1::uuid,$2::text,$3::jsonb) AS resultado;','={{ [$json.token, $json.acao, JSON.stringify($json.args)] }}','continueRegularOutput');
 code(w,'Resultado',unwrap);edge(w,'Entrada','Evento recebido?');edge(w,'Evento recebido?','Registrar evento');edge(w,'Evento recebido?','Validar acao',1);edge(w,'Registrar evento','Resultado');edge(w,'Validar acao','Atualizar atendimento');edge(w,'Atualizar atendimento','Resultado');save(w,'guard.json');
}
const w=workflow('WF1 - Agenda24h V3 - Texto e Audio');
add(w,'Webhook Evolution','n8n-nodes-base.webhook',{httpMethod:'POST',path:cfg.webhookPath,authentication:'headerAuth',responseMode:'responseNode',options:{}},2,{webhookId:ident(cfg.webhookPath)});
code(w,'Validar evento',`const esperado=${JSON.stringify(cfg.instancia)};
if(esperado.startsWith('PREENCHER_'))throw Error('Configure a instância antes de ativar.');
const b=$json.body||{},d=b.data||{},k=d.key||{},m=d.message||{};
const evento=String(b.event||'').toLowerCase().replaceAll('_','.');
const jid=String(k.remoteJid||'');
const valido=evento==='messages.upsert'&&b.instance===esperado&&typeof k.fromMe==='boolean'&&/^[1-9][0-9]{7,14}@s.whatsapp.net$/.test(jid)&&typeof k.id==='string'&&k.id.length>0&&k.id.length<=200;
const tipo=d.messageType;let texto='',normalizado='outro';
if(tipo==='conversation'&&typeof m.conversation==='string'){texto=m.conversation;normalizado='texto'}
if(tipo==='extendedTextMessage'&&typeof m.extendedTextMessage?.text==='string'){texto=m.extendedTextMessage.text;normalizado='texto'}
if(tipo==='audioMessage'&&m.audioMessage)normalizado='audio';
if(normalizado==='texto'&&!texto.trim())normalizado='outro';
return [{json:{valido,instancia:esperado,evento:{jid,message_id:k.id,from_me:k.fromMe,tipo:normalizado,texto},audio_segundos:Number(m.audioMessage?.seconds)||0}}];`);
iff(w,'Evento valido?','={{ $json.valido }}');
add(w,'Ignorar evento','n8n-nodes-base.respondToWebhook',{respondWith:'json',responseBody:'={"ok":true,"status":"ignorado"}',options:{responseCode:200}},1.1);
iff(w,'Mensagem propria?','={{ $json.evento.from_me }}');
add(w,'Aguardar registro do envio','n8n-nodes-base.wait',{resume:'timeInterval',amount:5,unit:'seconds'},1.1,{webhookId:ident('echo-delay')});
function inputMap(value){return {mappingMode:'defineBelow',value,matchingColumns:[],schema:Object.keys(value).map(id=>({id,displayName:id,required:false,defaultMatch:false,display:true,canBeUsedToMatch:true,type:'string'})),attemptToConvertTypes:false,convertFieldsToString:false};}
add(w,'Guard','n8n-nodes-base.executeWorkflow',{workflowId:{__rl:true,value:cfg.workflows.guard,mode:'id'},workflowInputs:inputMap({instancia:"={{ $('Validar evento').first().json.instancia }}",evento:"={{ JSON.stringify($('Validar evento').first().json.evento) }}",token:'',dados:''}),options:{waitForSubWorkflow:true}},1.3);
add(w,'Recebido','n8n-nodes-base.respondToWebhook',{respondWith:'json',responseBody:'={"ok":true,"status":"recebido"}',options:{responseCode:200}},1.1);
iff(w,'Transcrever?','={{ $json.acao === "transcrever" }}');
add(w,'Buscar audio','n8n-nodes-base.httpRequest',{method:'POST',url:`={{ ${JSON.stringify(cfg.evolutionUrl+'/chat/getBase64FromMediaMessage/')} + encodeURIComponent($('Validar evento').first().json.instancia) }}`,authentication:'genericCredentialType',genericAuthType:'httpHeaderAuth',sendBody:true,specifyBody:'json',jsonBody:"={{ {message:{key:{id:$('Validar evento').first().json.evento.message_id,remoteJid:$('Validar evento').first().json.evento.jid,fromMe:false}},convertToMp4:false} }}",options:{timeout:30000}},4.2,{onError:'continueErrorOutput'});
code(w,'Validar arquivo audio',`const base64=$json.base64;const mime=String($json.mimetype||'audio/ogg').split(';')[0];
// Limite técnico conservador; duração comercial permanece configurável.
if(typeof base64!=='string'||!base64.length||base64.length>24000000||!mime.startsWith('audio/'))throw Error('Audio inválido ou acima do limite técnico.');
return [{json:{base64,mimetype:mime}}];`);
w.nodes.at(-1).onError='continueErrorOutput';
add(w,'Audio para arquivo','n8n-nodes-base.convertToFile',{operation:'toBinary',sourceProperty:'base64',options:{fileName:'audio.ogg',mimeType:'={{ $json.mimetype }}'}},1.1,{onError:'continueErrorOutput'});
add(w,'Transcrever audio','@n8n/n8n-nodes-langchain.openAi',{resource:'audio',operation:'transcribe',options:{}},1.8,{onError:'continueErrorOutput'});
pg(w,'Salvar transcricao','SELECT public.a24_v3_audio($1::uuid,$2::text) AS resultado;',"={{ [$('Guard').first().json.mensagem_id, $json.text || ''] }}");
pg(w,'Registrar falha de audio','SELECT public.a24_v3_audio($1::uuid,NULL) AS resultado;',"={{ [$('Guard').first().json.mensagem_id] }}");
edge(w,'Webhook Evolution','Validar evento');edge(w,'Validar evento','Evento valido?');edge(w,'Evento valido?','Mensagem propria?');edge(w,'Evento valido?','Ignorar evento',1);edge(w,'Mensagem propria?','Aguardar registro do envio');edge(w,'Mensagem propria?','Guard',1);edge(w,'Aguardar registro do envio','Guard');edge(w,'Guard','Recebido');edge(w,'Recebido','Transcrever?');edge(w,'Transcrever?','Buscar audio');edge(w,'Buscar audio','Validar arquivo audio');edge(w,'Validar arquivo audio','Audio para arquivo');edge(w,'Audio para arquivo','Transcrever audio');edge(w,'Transcrever audio','Salvar transcricao');
for(const n of ['Buscar audio','Validar arquivo audio','Audio para arquivo','Transcrever audio'])edge(w,n,'Registrar falha de audio',1);

// Consumidor periódico no mesmo principal: retoma pendências sem depender de nova mensagem.
add(w,'Processar pendencias','n8n-nodes-base.scheduleTrigger',{rule:{interval:[{field:'seconds',secondsInterval:10}]}},1.2);
pg(w,'Reservar conversa','SELECT public.a24_v3_reservar($1::text) AS resultado;',`={{ [${JSON.stringify(cfg.instancia)}] }}`);
code(w,'Contexto reservado',`return [{json:$json.resultado||{pronto:false}}];`);iff(w,'Ha conversa?','={{ $json.pronto === true }}');
iff(w,'Tem texto?','={{ !!$json.mensagem?.trim() }}');
code(w,'Resposta de formato',`const c=$('Contexto reservado').first().json;
const avisos=[];
if(c.falha_audio)avisos.push('Não consegui transcrever seu áudio. Pode reenviar ou escrever sua mensagem?');
if(c.texto_longo)avisos.push('Sua mensagem está muito longa. Pode dividir em mensagens menores?');
if(c.nao_suportado)avisos.push('Consigo receber mensagens de texto e áudio. Pode reenviar sua mensagem em um desses formatos? 😊');
return [{json:{output:avisos.join('\\n\\n')}}];`);
const prompt=readFileSync(resolve(dir,'prompt.txt'),'utf8');
add(w,'Maria','@n8n/n8n-nodes-langchain.agent',{promptType:'define',text:"={{ JSON.stringify({nome:$json.nome,agora:$json.agora,fuso:$json.fuso,historico:$json.historico,mensagem:$json.mensagem}) }}",options:{systemMessage:'='+prompt,maxIterations:6}},3,{onError:'continueErrorOutput'});
add(w,'Modelo de atendimento','@n8n/n8n-nodes-langchain.lmChatOpenAi',{model:{__rl:true,value:'gpt-5-mini',mode:'list'},options:{}},1.2);
edge(w,'Modelo de atendimento','Maria',0,'ai_languageModel');
const toolsSpec=[
 ['buscar','buscar_horarios','Obter catálogo de serviços/profissionais e preços. Com IDs de serviço/profissional, buscar horários. dados JSON: {servico_id?,profissional_id?,data?}, data YYYY-MM-DD.'],
 ['verificar','verificar_disponibilidade','Verificar horário específico. dados JSON: {servico_id,profissional_id,inicio_em}. Exigir ISO com offset do fuso da empresa.'],
 ['agendar','agendar_horario','Somente após nome salvo e confirmação explícita do cliente sobre serviço, profissional e horário. dados JSON: {servico_id,profissional_id,inicio_em,confirmado:true}.'],
 ['meus','meus_agendamentos','Consultar agendamentos futuros do cliente com UUIDs. dados JSON: {}. Obrigatória antes de cancelar/remarcar.'],
 ['gerenciar','gerenciar_agendamento','Após confirmação explícita. dados JSON: {acao:"cancelar" ou "reagendar",agendamento_id,inicio_em (só reagendar),confirmado:true}. IDs de meus_agendamentos.'],
 ['guard','registrar_nome','Registrar apenas o nome informado pelo cliente. dados JSON: {acao:"nome",nome:"nome informado"}. Nunca usar nome do perfil sem confirmação.'],
 ['guard','transferir_humano','Quando o cliente pedir uma pessoa, pausar o automático. dados JSON: {acao:"humano"}.']
];
for(const [k,name,description] of toolsSpec){
 add(w,name,'@n8n/n8n-nodes-langchain.toolWorkflow',{description,workflowId:{__rl:true,value:cfg.workflows[k],mode:'id'},workflowInputs:inputMap({token:"={{ $('Contexto reservado').first().json.token }}",dados:`={{ $fromAI('dados', ${JSON.stringify(description)}, 'string') }}`})},2.2);edge(w,name,'Maria',0,'ai_tool');
}
code(w,'Falha no atendimento',`return [{json:{output:'Não consegui concluir seu atendimento agora. Se você pediu uma reserva ou alteração, consulte seus agendamentos antes de repetir a operação.'}}];`);
code(w,'Preparar resposta',`const c=$('Contexto reservado').first().json;let output=typeof $json.output==='string'?$json.output.trim():'';
if(!output)output='Não consegui concluir seu atendimento agora. Por favor, tente novamente em instantes.';
if(c.nao_suportado&&c.mensagem?.trim())output+='\\n\\nConsigo receber apenas texto e áudio. Reenvie o outro conteúdo em um desses formatos.';
if(c.falha_audio&&c.mensagem?.trim())output+='\\n\\nNão consegui transcrever um dos áudios. Pode reenviá-lo ou escrever a mensagem?';
if(c.texto_longo&&c.mensagem?.trim())output+='\\n\\nUma das mensagens ficou muito longa. Pode dividi-la em mensagens menores?';
return [{json:{token:c.token,output}}];`);
pg(w,'Autorizar envio','SELECT public.a24_v3_preparar_envio($1::uuid,$2::text) AS resultado;','={{ [$json.token,$json.output] }}');
code(w,'Envio autorizado',`return [{json:$json.resultado||{enviar:false}}];`);iff(w,'Pode enviar?','={{ $json.enviar === true }}');
add(w,'Enviar WhatsApp','n8n-nodes-base.httpRequest',{method:'POST',url:`={{ ${JSON.stringify(cfg.evolutionUrl+'/message/sendText/')} + encodeURIComponent($json.instancia) }}`,authentication:'genericCredentialType',genericAuthType:'httpHeaderAuth',sendBody:true,specifyBody:'json',jsonBody:'={{ {number:$json.jid,text:$json.texto} }}',options:{timeout:30000}},4.2,{onError:'continueErrorOutput'});
pg(w,'Confirmar envio','SELECT public.a24_v3_finalizar($1::uuid,$2::text) AS resultado;',"={{ [$('Envio autorizado').first().json.token, $json.key?.id || null] }}");
pg(w,'Envio indeterminado','SELECT public.a24_v3_finalizar($1::uuid,NULL) AS resultado;',"={{ [$('Envio autorizado').first().json.token] }}");
edge(w,'Processar pendencias','Reservar conversa');edge(w,'Reservar conversa','Contexto reservado');edge(w,'Contexto reservado','Ha conversa?');edge(w,'Ha conversa?','Tem texto?');edge(w,'Tem texto?','Maria');edge(w,'Tem texto?','Resposta de formato',1);edge(w,'Maria','Preparar resposta');edge(w,'Maria','Falha no atendimento',1);edge(w,'Falha no atendimento','Preparar resposta');edge(w,'Resposta de formato','Preparar resposta');edge(w,'Preparar resposta','Autorizar envio');edge(w,'Autorizar envio','Envio autorizado');edge(w,'Envio autorizado','Pode enviar?');edge(w,'Pode enviar?','Enviar WhatsApp');edge(w,'Enviar WhatsApp','Confirmar envio');edge(w,'Enviar WhatsApp','Envio indeterminado',1);
iff(w,'Ha alerta?','={{ $json.alerta === true }}');
add(w,'Avisar responsavel','n8n-nodes-base.httpRequest',{method:'POST',url:`={{ ${JSON.stringify(cfg.evolutionUrl+'/message/sendText/')} + encodeURIComponent($json.instancia) }}`,authentication:'genericCredentialType',genericAuthType:'httpHeaderAuth',sendBody:true,specifyBody:'json',jsonBody:'={{ {number:$json.numero,text:$json.texto} }}',options:{timeout:30000}},4.2,{onError:'continueErrorOutput'});
pg(w,'Registrar alerta enviado','SELECT public.a24_v3_alerta_finalizar($1::uuid,$2::text) AS resultado;',"={{ [$('Contexto reservado').first().json.alerta_id,$json.key?.id || null] }}");
pg(w,'Registrar falha alerta','SELECT public.a24_v3_alerta_finalizar($1::uuid,NULL) AS resultado;',"={{ [$('Contexto reservado').first().json.alerta_id] }}");
edge(w,'Ha conversa?','Ha alerta?',1);edge(w,'Ha alerta?','Avisar responsavel');edge(w,'Avisar responsavel','Registrar alerta enviado');edge(w,'Avisar responsavel','Registrar falha alerta',1);
const layout={
 'Webhook Evolution':[0,0],'Validar evento':[220,0],'Evento valido?':[440,0],'Ignorar evento':[660,-200],
 'Mensagem propria?':[660,0],'Aguardar registro do envio':[880,-100],'Guard':[1100,0],'Recebido':[1320,0],
 'Transcrever?':[1540,0],'Buscar audio':[1760,0],'Validar arquivo audio':[1980,0],'Audio para arquivo':[2200,0],
 'Transcrever audio':[2420,0],'Salvar transcricao':[2640,0],'Registrar falha de audio':[2420,240],
 'Processar pendencias':[0,700],'Reservar conversa':[220,700],'Contexto reservado':[440,700],
 'Ha conversa?':[660,700],'Tem texto?':[880,700],'Maria':[1220,700],'Resposta de formato':[1220,480],
 'Falha no atendimento':[1500,480],'Preparar resposta':[1760,700],'Autorizar envio':[1980,700],
 'Envio autorizado':[2200,700],'Pode enviar?':[2420,700],'Enviar WhatsApp':[2640,700],
 'Confirmar envio':[2860,700],'Envio indeterminado':[2860,920],'Modelo de atendimento':[1000,960],
 'Ha alerta?':[660,1500],'Avisar responsavel':[880,1500],'Registrar alerta enviado':[1100,1400],'Registrar falha alerta':[1100,1620]
};
let toolIndex=0;w.nodes.forEach(n=>{n.position=layout[n.name]||(n.type.endsWith('.toolWorkflow')?[200+(toolIndex++)*240,1160]:[0,0])});
add(w,'Leia antes de ativar','n8n-nodes-base.stickyNote',{content:'## Agenda24h V3 — homologação\nImporte primeiro as seis tools. Configure IDs, credenciais e instância exata. Aplique a migration em banco de teste.\n\nWebhook autenticado; áudio e texto apenas. Worker a cada 10s, com 15s para agrupar mensagens.\n\nConsulte README.md para implantação e limitações.',height:240,width:600},1,{position:[0,-350]});
save(w,'principal.json');
console.log('7 workflows gerados, inativos. Configuração: '+(cfg.instancia.startsWith('PREENCHER_')?'modelo pendente de configuração':'instância preenchida'));
