# Agenda24h — reconstrução dos workflows V3

Preparado em 19/09/2026. **Artefatos locais para homologação; não importados no n8n e não aplicados no servidor.** Os sete arquivos originais recebidos foram preservados.

V3 identifica a versão dos workflows. O banco continua sendo o modelo oficial **V2** (`empresas`, `clientes`, IDs UUID), e não o modelo legado de `contratantes`/`leads`/`tag` dos exports recebidos.

## Arquivos de importação

| Ordem | Arquivo | Workflow |
|---|---|---|
| 1 | [json/buscar.json](json/buscar.json) | Catálogo e horários por serviço/profissional |
| 2 | [json/verificar.json](json/verificar.json) | Disponibilidade de um horário específico |
| 3 | [json/agendar.json](json/agendar.json) | Reserva transacional e idempotente |
| 4 | [json/meus.json](json/meus.json) | Agendamentos do cliente com UUIDs |
| 5 | [json/gerenciar.json](json/gerenciar.json) | Cancelamento e reagendamento |
| 6 | [json/guard.json](json/guard.json) | Registro/deduplicação, pausa humana, nome e transferência |
| 7 | [json/principal.json](json/principal.json) | Recebimento de texto/áudio e consumidor de pendências |

Todos são entregues inativos, sem credenciais e sem IDs de workflows antigos. O principal é um modelo por empresa; as seis tools são compartilhadas.

## Comportamento implementado

- Texto curto, texto estendido e áudio entram no atendimento. Imagem, vídeo, documento, localização, figurinha, contato e outros formatos produzem resposta determinística pedindo texto/áudio. Nenhuma mídia visual é analisada.
- Eventos de grupo, status, instância diferente, formato de identidade inválido e eventos sem ID são ignorados. Mensagens de `@lid` ainda não são resolvidas para telefone: exigem validação/adaptação com amostra sanitizada da Evolution instalada; não são confundidas com números telefônicos.
- Deduplicação pelo ID da Evolution e empresa. Texto é registrado antes do HTTP 200; áudio é registrado antes do HTTP 200 e transcrito em seguida. Falha/expiração da transcrição gera aviso, sem salvar `[midia]` como nome.
- O principal tem duas entradas independentes: webhook e agendamento a cada 10 segundos. O consumidor espera 15 segundos sem novas mensagens, reserva uma conversa e junta até 30 mensagens pendentes, sem sobrescrever as anteriores. O restante fica para o próximo turno.
- Contexto de até 12 mensagens processadas das últimas 24h. A mensagem atual é mantida separada do histórico. O nome é registrado somente quando informado, por tool específica ligada ao guard.
- Empresa, cliente e conversa são resolvidos no banco. A IA recebe somente um token interno fixado pelo workflow; não escolhe empresa/telefone/cliente. As tools aceitam IDs do catálogo, data e parâmetros de negócio.
- Serviços e preços respeitam o vínculo profissional-serviço e seus valores específicos. Disponibilidade e gravação usam as mesmas regras de expediente, duração, antecedência, exceções, buffer posterior e limite diário.
- Agendamento exige nome ativo e confirmação explícita indicada pela IA. O prompt solicita recapitulação prévia. O banco exige `confirmado=true`; isso valida o contrato, mas **não prova sozinho** que o cliente confirmou em linguagem natural — esse comportamento precisa de teste com o modelo.
- Uma alteração de agenda por turno. Repetir a mesma operação retorna o resultado já registrado; uma segunda operação diferente exige nova mensagem. Reagendamento mantém serviço e profissional, como a tool antiga.
- Cancelamento/remarcação respeitam a antecedência configurada (24h no padrão); a fronteira exata é inclusiva. Dentro do prazo proibido, o resultado informa o número reserva quando cadastrado.
- Reserva concluída, cancelada ou marcada como falta não pode ser alterada por estas tools. Se há lembrete em processamento, a alteração é recusada momentaneamente. Não foram alterados o workflow nem a função de comparecimento.
- Pausa humana de 30 minutos renovada a cada intervenção manual. Mensagens anteriores à resposta humana deixam de aguardar IA. Mensagens posteriores permanecem pendentes e podem ser retomadas pelo consumidor sem uma nova mensagem do cliente.
- Ecos registrados pelo bot/fila não ativam a pausa. Um eco recebido enquanto a chamada de envio está em andamento aguarda reconciliação pelo ID retornado. Uma saída manual nesse intervalo é classificada após o envio concluir/expirar.
- Limites de IA por conversa/empresa vêm das configurações. O limite por conversa cria uma pausa de duas horas, preserva pendências e agenda um aviso único ao `numero_notificacao`, se válido. Sem esse número, fica o registro operacional.
- Falha de envio com resultado incerto não é reenviada automaticamente: isso evita duplicar mensagens e confirmações. A ocorrência fica para revisão. Falha que interrompe a execução inteira vence por prazo e também fica registrada.

## Alterações de banco necessárias

[migration-atendimento-v3.sql](migration-atendimento-v3.sql) é a migration executável gerada a partir de `banco.sql`, das duas RPCs oficiais de alteração da agenda e da função de programação de lembretes. Não executar o arquivo-fonte `banco.sql` isoladamente.

Requer o contrato V2 presente nas migrations 001–009, incluindo `numero_notificacao` da 008. Cria schema privado, sessão de processamento, controle de pausa/alerta e sete funções públicas restritas a um novo papel `agenda24h_atendimento`. Esse papel não recebe leitura direta das tabelas nem acesso às RPCs antigas.

Também:

1. Corrige a expressão de telefone do contrato local, exigindo E.164 e telefone presente para cliente não anonimizado. Dados inválidos existentes fazem a migration falhar; não são corrigidos silenciosamente.
2. Adiciona validação antes de gravar reservas confirmadas, incluindo limite diário, duração e buffer oficiais. Isso também afeta outros escritores da agenda; testar o portal na homologação.
3. Preserva a constraint GiST contra sobreposição e adiciona serialização por empresa às alterações.
4. Corrige `<=` para `<` nas duas funções de cancelamento/remarcação, mantendo a elegibilidade quando faltam exatamente 24 horas.
5. Limpa conteúdo auxiliar quando o cliente é anonimizado. A rotina de privacidade oficial continua responsável por limpar as tabelas públicas.
6. Reativa lembretes anteriormente cancelados quando uma remarcação volta ao horário original, sem criar duplicatas. Mensagens já enviadas não são reativadas.

As definições locais das RPCs devem ser comparadas ao servidor antes de aplicar: a migration não deve substituir alterações remotas desconhecidas. `preflight.sql` verifica existência/contrato, não prova equivalência integral dos corpos.

## Instalação em homologação, um por um

1. Conferir backup e executar [preflight.sql](preflight.sql) no banco de teste. Todas as dependências devem existir, a constraint de exclusão deve aparecer, telefones incompatíveis devem ser zero e o papel/schema novos devem estar ausentes.
2. Comparar as funções oficiais atuais com as versões do projeto. Aplicar `migration-atendimento-v3.sql` somente na homologação e executar [verificar-instalacao.sql](verificar-instalacao.sql).
3. Definir a senha do novo papel pelo gerenciador seguro do banco e criar a credencial Postgres no n8n com esse usuário. Não colocar senha em JSON ou documentação. Configurar acesso à base pela infraestrutura existente.
4. Importar as seis tools na ordem acima. Selecionar a credencial Postgres V3 em todos os nós Postgres. Não usar o usuário de comparecimento. Copiar os seis IDs atribuídos pelo n8n.
5. Copiar `config.exemplo.json` para `config.local.json`. Informar a instância exata da empresa-teste e os seis IDs. Não incluir credenciais. Gerar novamente com `node gerar.mjs config.local.json` e importar **somente o principal** recém-gerado. As tools já importadas não precisam ser reimportadas.
6. No principal, selecionar Postgres V3, OpenAI nos dois nós OpenAI e a credencial Header Auth da Evolution nos nós HTTP. No webhook, selecionar uma **outra** credencial Header Auth para validar a origem do evento; configurar o mesmo cabeçalho na Evolution ou em proxy autenticado. Não reutilizar/publicar a chave da API como URL.
7. Conferir os vínculos das sete ferramentas do agente e do nó Guard. Duas ferramentas do agente (`registrar_nome` e `transferir_humano`) apontam para o mesmo workflow Guard; por isso são sete ferramentas e seis subworkflows.
8. Usar uma instância/número de teste e caminho novo, sem dois principais respondendo ao mesmo número. Ativar somente o principal de homologação, pois o schedule depende de ativação. Executar [TESTES.md](TESTES.md).
9. Só depois dos testes integrados planejar a troca do webhook real. Os arquivos não fazem essa troca automaticamente.

## Limites técnicos e verificações ainda necessárias

- Os JSONs foram verificados estruturalmente e os códigos executados em testes locais. **Não foram importados/executados nesta instalação do n8n**; versões dos nós, bindings, autenticação e credenciais devem ser conferidos nela.
- Os testes de banco usam PostgreSQL embarcado PGlite, incluindo `btree_gist`. Não equivalem a um teste de duas conexões simultâneas no PostgreSQL do servidor. O roteiro inclui esse teste.
- Um consumidor reserva uma conversa por disparo, permitindo execuções sobrepostas em conversas diferentes. Capacidade de 50 empresas não foi medida.
- Memória de 24h, descarte de conteúdo após 30 dias, texto até 12.000 caracteres e mídia até 24.000.000 caracteres base64 são **valores técnicos desta versão**, não novas regras comerciais confirmadas. Revisar antes de ativar. Textos acima do limite recebem pedido para dividir em mensagens menores; transcrição acima do limite recebe aviso para reenviar/escrever. A limpeza de conteúdo roda durante o processamento de empresa ativa; empresas suspensas precisam da rotina de retenção administrativa.
- Áudio tem tempo máximo de processamento de três minutos. Não foi definido limite comercial de duração; o tamanho máximo é conservador. Tipo/nome do arquivo e o retorno real da Evolution precisam de teste com OGG/PTT do número de teste.
- Uma mensagem manual pode chegar quando um envio HTTP já começou; não é possível cancelar retroativamente a requisição. A revalidação reduz essa janela e pausa os próximos turnos.
- APIs de envio não oferecem aqui garantia de entrega exatamente uma vez. Em timeout/resultado indeterminado, revisar a Evolution e os registros antes de qualquer reenvio manual. Não foi implementada uma tentativa automática cega.
- A IA ainda precisa ser avaliada com pedidos ambíguos, confirmação, áudio, datas relativas e tentativas de obter dados de outra pessoa. Limites no banco não substituem esses testes.
- Os alertas de loop usam identificação operacional da conversa, não o conteúdo da mensagem. Atraso de webhook de alerta antes do registro do ID deve ser incluído na homologação.

## Voltar atrás

Desativar o principal V3 e restaurar o destino anterior do webhook interrompe o novo atendimento. Não apagar o schema ou desfazer a migration automaticamente: preservar registros e revisar os efeitos do trigger compartilhado no banco. Restaurar uma versão anterior das três funções existentes alteradas exige comparação com o backup e decisão explícita; não é parte da simples troca de webhook.

## Reproduzir localmente

`node gerar.mjs` gera modelos ainda sem configuração. `node --test tests/*.test.mjs` executa a bateria. Os testes reutilizam o PGlite já instalado em `../comparecimento/node_modules`; nenhum acesso ao servidor, WhatsApp ou OpenAI é realizado.

Referências de formato consultadas: [parâmetros do Postgres no n8n](https://github.com/n8n-io/n8n/blob/master/packages/nodes-base/nodes/Postgres/v2/actions/database/executeQuery.operation.ts), [Schedule Trigger](https://github.com/n8n-io/n8n/blob/master/packages/nodes-base/nodes/Schedule/ScheduleTrigger.node.ts). Os tipos/versões de OpenAI, agente, áudio e chamadas de workflow foram baseados nos exports fornecidos pelo usuário.
