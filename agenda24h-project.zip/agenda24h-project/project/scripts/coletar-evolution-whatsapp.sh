#!/usr/bin/env bash
set -euo pipefail
umask 077

CONTAINER="evolution-api"
STAMP="$(date +%Y%m%d-%H%M%S)"
REPORT="$HOME/inventario-evolution-whatsapp-${STAMP}.txt"
BASE_URL="http://127.0.0.1:8081"

if ! docker inspect "$CONTAINER" >/dev/null 2>&1; then
    echo "ERRO: container '$CONTAINER' nao encontrado." >&2
    exit 1
fi

get_env_value() {
    local wanted="$1"
    docker inspect "$CONTAINER" \
        --format '{{range .Config.Env}}{{println .}}{{end}}' 2>/dev/null |
        awk -F= -v wanted="$wanted" '$1 == wanted {sub(/^[^=]*=/, ""); print; exit}'
}

API_KEY="$(get_env_value AUTHENTICATION_API_KEY || true)"

{
    echo "INVENTARIO SANITIZADO - EVOLUTION API / WHATSAPP"
    echo "Data: $(date --iso-8601=seconds)"
    echo

    echo "============================================================"
    echo "CONTAINER E IMAGEM"
    echo "============================================================"
    docker inspect "$CONTAINER" --format \
        'Nome={{.Name}} | Imagem={{.Config.Image}} | Estado={{.State.Status}} | Inicio={{.State.StartedAt}} | Reinicios={{.RestartCount}}'
    docker inspect "$CONTAINER" --format \
        'PoliticaRestart={{.HostConfig.RestartPolicy.Name}} | MaxTentativas={{.HostConfig.RestartPolicy.MaximumRetryCount}}'
    docker image inspect "$(docker inspect "$CONTAINER" --format '{{.Image}}')" --format \
        'ImageID={{.Id}} | Criada={{.Created}} | RepoDigests={{json .RepoDigests}}' 2>/dev/null || true
    echo

    echo "============================================================"
    echo "VERSAO DECLARADA"
    echo "============================================================"
    docker inspect "$CONTAINER" --format '{{range $k,$v := .Config.Labels}}{{if eq $k "org.opencontainers.image.version"}}{{$v}}{{end}}{{end}}' 2>/dev/null || true
    docker exec "$CONTAINER" sh -lc '
        for f in /evolution/package.json /evolution/dist/package.json /app/package.json package.json; do
            if [ -r "$f" ]; then
                node -e "try{const p=require(\"$f\"); console.log(p.name+\" \"+p.version)}catch(e){}" 2>/dev/null
                break
            fi
        done
    ' 2>/dev/null || true
    echo

    echo "============================================================"
    echo "CONFIGURACOES NAO SENSIVEIS"
    echo "============================================================"
    for key in \
        SERVER_URL SERVER_PORT SERVER_TYPE \
        DATABASE_PROVIDER DATABASE_SAVE_DATA_INSTANCE \
        DATABASE_SAVE_DATA_NEW_MESSAGE DATABASE_SAVE_MESSAGE_UPDATE \
        DATABASE_SAVE_DATA_CONTACTS DATABASE_SAVE_DATA_CHATS \
        CACHE_REDIS_ENABLED CACHE_LOCAL_ENABLED \
        WEBHOOK_GLOBAL_ENABLED WEBHOOK_GLOBAL_WEBHOOK_BY_EVENTS \
        AUTHENTICATION_EXPOSE_IN_FETCH_INSTANCES \
        LOG_LEVEL DEL_INSTANCE; do
        value="$(get_env_value "$key" || true)"
        if [ -n "$value" ]; then
            printf '%s=%s\n' "$key" "$value"
        fi
    done
    echo
    echo "Nomes de variaveis configuradas (valores ocultos):"
    docker inspect "$CONTAINER" --format '{{range .Config.Env}}{{println .}}{{end}}' 2>/dev/null |
        sed 's/=.*//' | sort -u
    echo

    echo "============================================================"
    echo "PORTAS, REDES E PERSISTENCIA"
    echo "============================================================"
    docker inspect "$CONTAINER" --format 'Portas={{json .HostConfig.PortBindings}}'
    echo "Redes:"
    docker inspect "$CONTAINER" --format '{{range $name,$cfg := .NetworkSettings.Networks}}{{println $name}}{{end}}'
    echo "Mounts:"
    docker inspect "$CONTAINER" --format '{{range .Mounts}}{{println .Type "|" .Name "| destino=" .Destination}}{{end}}'
    echo "Compose:"
    docker inspect "$CONTAINER" --format \
        'Projeto={{index .Config.Labels "com.docker.compose.project"}} | Diretorio={{index .Config.Labels "com.docker.compose.project.working_dir"}} | Arquivos={{index .Config.Labels "com.docker.compose.project.config_files"}}'
    echo

    echo "============================================================"
    echo "SAUDE LOCAL E REGISTROS"
    echo "============================================================"
    http_code="$(curl --silent --show-error --max-time 10 --output /dev/null --write-out '%{http_code}' "$BASE_URL" 2>/dev/null || true)"
    echo "HTTP local na raiz: ${http_code:-falha}"
    recent_errors="$(docker logs --since 24h "$CONTAINER" 2>&1 | grep -Eic 'error|exception|failed|failure|disconnect' || true)"
    recent_reconnects="$(docker logs --since 24h "$CONTAINER" 2>&1 | grep -Eic 'reconnect|connection.update|connection update' || true)"
    echo "Linhas com indicios de erro/desconexao nas ultimas 24h: $recent_errors"
    echo "Linhas com indicios de reconexao nas ultimas 24h: $recent_reconnects"
    echo "O conteudo dos logs nao foi incluido para evitar dados pessoais."
    echo

    echo "============================================================"
    echo "INSTANCIAS E WEBHOOKS - DADOS MASCARADOS"
    echo "============================================================"
} > "$REPORT"

if [ -z "$API_KEY" ]; then
    {
        echo "Nao foi possivel localizar AUTHENTICATION_API_KEY no container."
        echo "Nenhuma chamada autenticada foi realizada."
    } >> "$REPORT"
else
    python3 - "$BASE_URL" 3<<<"$API_KEY" <<'PY' >> "$REPORT"
import hashlib
import json
import os
import sys
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlparse
from urllib.request import Request, urlopen

base_url = sys.argv[1].rstrip("/")
with os.fdopen(3, "r", encoding="utf-8") as secret_stream:
    api_key = secret_stream.read().strip()

def get_json(path):
    request = Request(
        base_url + path,
        headers={"apikey": api_key, "Accept": "application/json"},
        method="GET",
    )
    with urlopen(request, timeout=15) as response:
        return json.loads(response.read().decode("utf-8")), response.status

def pick(mapping, *names):
    if not isinstance(mapping, dict):
        return None
    for name in names:
        if mapping.get(name) not in (None, ""):
            return mapping.get(name)
    return None

def public_id(name):
    digest = hashlib.sha256(name.encode("utf-8")).hexdigest()[:10]
    return "inst-" + digest

def masked_url(value):
    if not isinstance(value, str) or not value:
        return "nao informada"
    parsed = urlparse(value)
    if not parsed.scheme or not parsed.netloc:
        return "[URL nao exibida]"
    path_kind = "/"
    parts = [part for part in parsed.path.split("/") if part]
    if parts:
        path_kind += parts[0] + "/[CAMINHO_OCULTO]"
    return f"{parsed.scheme}://{parsed.netloc}{path_kind}"

try:
    payload, status_code = get_json("/instance/fetchInstances")
except (HTTPError, URLError, TimeoutError, json.JSONDecodeError) as exc:
    print("Falha ao consultar instancias:", type(exc).__name__)
    raise SystemExit(0)

if isinstance(payload, list):
    instances = payload
elif isinstance(payload, dict):
    candidate = payload.get("instances") or payload.get("data") or []
    instances = candidate if isinstance(candidate, list) else []
else:
    instances = []

print("Consulta de instancias: HTTP", status_code)
print("Quantidade de instancias:", len(instances))

status_totals = {}
for position, raw in enumerate(instances, start=1):
    if not isinstance(raw, dict):
        continue
    nested = raw.get("instance") if isinstance(raw.get("instance"), dict) else {}
    name = pick(raw, "instanceName", "name") or pick(nested, "instanceName", "name")
    if not isinstance(name, str) or not name:
        name = f"sem-nome-{position}"

    status = (
        pick(raw, "connectionStatus", "status", "state")
        or pick(nested, "connectionStatus", "status", "state")
        or "nao informado"
    )
    integration = pick(raw, "integration") or pick(nested, "integration") or "nao informada"
    status_totals[str(status)] = status_totals.get(str(status), 0) + 1

    print()
    print("Instancia:", public_id(name))
    print("  Estado:", status)
    print("  Integracao:", integration)

    counts = raw.get("_count") if isinstance(raw.get("_count"), dict) else {}
    numeric_counts = {
        str(key): value for key, value in counts.items()
        if isinstance(value, (int, float)) and not isinstance(value, bool)
    }
    if numeric_counts:
        print("  Contagens internas:", json.dumps(numeric_counts, ensure_ascii=False, sort_keys=True))

    try:
        webhook_payload, webhook_status = get_json("/webhook/find/" + quote(name, safe=""))
        webhook = webhook_payload
        while isinstance(webhook, dict) and isinstance(webhook.get("webhook"), dict):
            webhook = webhook["webhook"]
        if not isinstance(webhook, dict):
            webhook = {}

        enabled = pick(webhook, "enabled")
        webhook_url = pick(webhook, "url", "webhookUrl")
        by_events = pick(webhook, "webhookByEvents", "byEvents")
        events = webhook.get("events") if isinstance(webhook.get("events"), list) else []

        print("  Webhook HTTP:", webhook_status)
        print("  Webhook habilitado:", enabled)
        print("  Destino mascarado:", masked_url(webhook_url))
        print("  Webhook por evento:", by_events)
        print("  Eventos:", ", ".join(str(event) for event in events) if events else "nenhum informado")
    except (HTTPError, URLError, TimeoutError, json.JSONDecodeError) as exc:
        print("  Falha ao consultar webhook:", type(exc).__name__)

print()
print("Resumo de estados:", json.dumps(status_totals, ensure_ascii=False, sort_keys=True))
print("Nomes, numeros, JIDs, tokens, chaves e cabecalhos nao foram exibidos.")
PY
fi

{
    echo
    echo "============================================================"
    echo "ROTA CLOUDFLARE - SEM CREDENCIAIS"
    echo "============================================================"
    if [ -r /etc/cloudflared/config.yml ]; then
        awk '
            /^[[:space:]]*hostname:/ {print}
            /^[[:space:]]*service:/ {print}
        ' /etc/cloudflared/config.yml |
        sed -E 's#(https?://[^/:[:space:]]+)(:[0-9]+)?(/.*)?#\1\2/[CAMINHO_OCULTO]#'
    else
        echo "Sem permissao de leitura para /etc/cloudflared/config.yml ou arquivo ausente."
    fi
    echo
    echo "============================================================"
    echo "FIM"
    echo "============================================================"
    echo "Revise este relatorio antes de compartilha-lo."
} >> "$REPORT"

chmod 600 "$REPORT"
unset API_KEY

echo "Coleta concluida."
echo "Relatorio criado em:"
echo "$REPORT"
echo "Nao envie arquivos .env, configuracoes completas ou respostas JSON brutas da API."
