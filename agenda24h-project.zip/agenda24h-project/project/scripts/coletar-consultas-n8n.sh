#!/usr/bin/env bash
set -euo pipefail
umask 077

CONTAINER="n8n"
STAMP="$(date +%Y%m%d-%H%M%S)"
CONTAINER_EXPORT="/tmp/agenda24h-workflows-${STAMP}.json"
HOST_EXPORT="$(mktemp /tmp/agenda24h-workflows.XXXXXX.json)"
REPORT="$HOME/inventario-consultas-n8n-${STAMP}.txt"

cleanup() {
    rm -f -- "$HOST_EXPORT"
    docker exec -u node "$CONTAINER" rm -f -- "$CONTAINER_EXPORT" >/dev/null 2>&1 || true
}
trap cleanup EXIT

echo "Exportando workflows temporariamente (sem exportar credenciais)..."
docker exec -u node "$CONTAINER" \
    n8n export:workflow --all --output="$CONTAINER_EXPORT" >/dev/null

docker cp "$CONTAINER:$CONTAINER_EXPORT" "$HOST_EXPORT" >/dev/null

python3 - "$HOST_EXPORT" <<'PY' | tee "$REPORT"
import json
import re
import sys
import unicodedata
from datetime import datetime, timezone

source = sys.argv[1]
with open(source, "r", encoding="utf-8") as handle:
    exported = json.load(handle)

if isinstance(exported, list):
    workflows = exported
elif isinstance(exported, dict) and isinstance(exported.get("workflows"), list):
    workflows = exported["workflows"]
elif isinstance(exported, dict):
    workflows = [exported]
else:
    raise SystemExit("Formato de exportacao do n8n nao reconhecido.")

sensitive_key = re.compile(
    r"password|passwd|secret|credential|authorization|api.?key|private.?key|"
    r"access.?token|refresh.?token|client.?secret|cookie",
    re.IGNORECASE,
)

secret_value_patterns = [
    re.compile(r"\bsk-[A-Za-z0-9_-]{12,}\b"),
    re.compile(r"\bn8n_api_[A-Za-z0-9_-]{12,}\b", re.IGNORECASE),
    re.compile(r"\bBearer\s+[A-Za-z0-9._~+/-]{10,}=*", re.IGNORECASE),
    re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}\b"),
    re.compile(r"([?&](?:token|key|secret|api_key)=)[^&#\s]+", re.IGNORECASE),
]

def normalize(value):
    value = unicodedata.normalize("NFKD", value)
    return "".join(ch for ch in value if not unicodedata.combining(ch)).lower()

def scrub_string(value):
    cleaned = value
    for pattern in secret_value_patterns:
        if pattern.groups:
            cleaned = pattern.sub(r"\1[REMOVIDO]", cleaned)
        else:
            cleaned = pattern.sub("[REMOVIDO]", cleaned)
    return cleaned

def sanitize(value, key=""):
    if sensitive_key.search(str(key)):
        return "[REMOVIDO: campo potencialmente sensivel]"
    if isinstance(value, dict):
        return {str(k): sanitize(v, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [sanitize(item, key) for item in value]
    if isinstance(value, str):
        return scrub_string(value)
    return value

database_terms = (
    "postgres", "supabase", "mysql", "mssql", "microsoftsql",
    "sqlite", "mongo", "redis", "database", "sql",
)
business_terms = (
    "agend", "dispon", "horar", "lembret", "reativ", "cancel",
    "reagend", "profission", "servic", "bloque", "encaixe",
)

def is_relevant(node):
    node_type = normalize(str(node.get("type", "")))
    node_name = normalize(str(node.get("name", "")))
    return (
        any(term in node_type for term in database_terms)
        or any(term in node_name for term in business_terms)
    )

def print_connections(connections):
    found = False
    for source_name, output_groups in (connections or {}).items():
        if not isinstance(output_groups, dict):
            continue
        for output_type, lanes in output_groups.items():
            if not isinstance(lanes, list):
                continue
            for lane_index, lane in enumerate(lanes):
                if not isinstance(lane, list):
                    continue
                for connection in lane:
                    if not isinstance(connection, dict):
                        continue
                    target = connection.get("node", "?")
                    target_input = connection.get("index", 0)
                    print(
                        f"  {source_name} --{output_type}[{lane_index}]--> "
                        f"{target}[entrada {target_input}]"
                    )
                    found = True
    if not found:
        print("  Nenhuma conexao registrada.")

print("INVENTARIO SANITIZADO DE CONSULTAS E FLUXOS N8N")
print("Gerado em UTC:", datetime.now(timezone.utc).isoformat())
print("Workflows encontrados:", len(workflows))
print("Credenciais, execucoes e dados de clientes nao foram incluidos.")

for workflow in sorted(workflows, key=lambda item: str(item.get("name", "")).lower()):
    name = scrub_string(str(workflow.get("name", "Sem nome")))
    workflow_id = workflow.get("id", "sem-id")
    active = workflow.get("active", False)
    nodes = workflow.get("nodes") or []
    relevant = [node for node in nodes if is_relevant(node)]

    print("\n" + "=" * 72)
    print(f"WORKFLOW: {name}")
    print(f"ID: {workflow_id} | Ativo: {active} | Nos: {len(nodes)}")

    print("\nMAPA DE NOS")
    for node in nodes:
        disabled = bool(node.get("disabled", False))
        print(
            f"  - {node.get('name', 'Sem nome')} | {node.get('type', 'Sem tipo')}"
            f" | desativado={disabled}"
        )

    print("\nCONEXOES")
    print_connections(workflow.get("connections") or {})

    print("\nNOS DE BANCO OU AGENDA")
    if not relevant:
        print("  Nenhum no selecionado pelos filtros.")
        continue

    for node in relevant:
        print("\n" + "-" * 60)
        print("Nome:", node.get("name", "Sem nome"))
        print("Tipo:", node.get("type", "Sem tipo"))
        print("Versao do tipo:", node.get("typeVersion", "nao informada"))
        print("Desativado:", bool(node.get("disabled", False)))
        print("Parametros sanitizados:")
        safe_parameters = sanitize(node.get("parameters") or {})
        print(json.dumps(safe_parameters, ensure_ascii=False, indent=2, sort_keys=True))

print("\n" + "=" * 72)
print("FIM DO INVENTARIO")
print("Revise o relatorio antes de compartilha-lo, pois segredos inseridos em texto livre")
print("podem nao ser reconhecidos automaticamente.")
PY

chmod 600 "$REPORT"

echo
echo "Relatorio criado em:"
echo "$REPORT"
echo
echo "Revise o arquivo antes de envia-lo. Nao envie o JSON temporario dos workflows."
