# Evolution API e integração com WhatsApp

## Estado do documento

Inventário sanitizado coletado em 5 de setembro de 2026, às 20:43 (America/Sao_Paulo). Nenhum nome de instância, telefone, JID, token, chave, cabeçalho ou conteúdo de mensagem foi registrado.

Esta é uma análise de leitura. Nenhuma configuração da Evolution API, WhatsApp, Cloudflare ou n8n foi alterada.

## Resumo executivo

A Evolution API está operacional, responde localmente com HTTP 200 e possui uma instância WhatsApp conectada por Baileys. A instância envia o evento `MESSAGES_UPSERT` para um webhook HTTPS do n8n.

Pontos que precisam de atenção:

- A imagem Docker usa a etiqueta mutável `latest`.
- O container acumulou dois reinícios desde a criação/inicialização observada.
- Foram contadas seis linhas com indícios de erro ou desconexão nas 24 horas anteriores.
- Não houve indicação de reconexão nos registros examinados.
- Somente `MESSAGES_UPSERT` está habilitado no webhook.
- O webhook usa o endereço público do n8n, embora Evolution e n8n estejam na mesma rede Docker.
- A Evolution mantém milhares de mensagens e dezenas de contatos/chats em armazenamento, exigindo política de retenção e privacidade.

## Fluxo observado

```text
Cliente no WhatsApp
        ↓
Evolution API / Baileys
        ↓ MESSAGES_UPSERT
Cloudflare → domínio público do n8n
        ↓
WF1 - Principal Agenda24h (OpenAI)
        ↓
IA + ferramentas n8n + Redis + PostgreSQL
        ↓
Evolution API envia a resposta
        ↓
Cliente no WhatsApp
```

O caminho de retorno foi inferido pelo workflow principal, que contém nós HTTP para envio pela Evolution API.

## Container e versão

| Item | Estado confirmado |
|---|---|
| Container | `evolution-api` |
| Aplicação | Evolution API 2.3.7 |
| Imagem configurada | `evoapicloud/evolution-api:latest` |
| Digest observado | `sha256:966625532d9076a2381e973a271307d107e6f070450de3abeeea8bd18be07252` |
| Estado | Em execução |
| Política de reinício | `always` |
| Reinícios observados | 2 |
| Criação da imagem | 6 de maio de 2026 |

O digest permite identificar exatamente a imagem atual, mas a etiqueta `latest` pode apontar para outra imagem em uma recriação futura. A versão deve ser fixada explicitamente somente depois de confirmar a referência de imagem suportada e testar restauração/rollback.

## Configuração conhecida

| Configuração | Valor confirmado |
|---|---|
| `SERVER_URL` | `http://192.168.0.4:8081` |
| Banco | PostgreSQL |
| Redis | Habilitado |
| Fuso horário | Variável `TZ` presente; valor não coletado |
| Chave global de API | Configurada; valor não coletado |
| Conexão do banco | Configurada; valor ocultado |
| Conexão Redis | Configurada; valor ocultado |

O `SERVER_URL` aponta para IP privado e HTTP, enquanto o serviço também é publicado externamente pelo Cloudflare. É necessário decidir qual deve ser a URL canônica e verificar se a URL privada aparece em respostas, QR codes, callbacks ou integrações externas.

## Rede e persistência

| Item | Estado confirmado |
|---|---|
| Porta do container | 8080 |
| Porta no host | `127.0.0.1:8081` |
| Rede Docker | `multiverso-network` |
| Volume | `evolution_data` |
| Destino do volume | `/evolution/dist/store` |
| Compose | `/home/multiverso/docker/evolution/docker-compose.yml` |

A porta estar vinculada somente a `127.0.0.1` reduz a exposição direta. O acesso externo aparenta passar pelo Cloudflare Tunnel.

Evolution e n8n estão associados à infraestrutura Docker do mesmo servidor. Deve-se confirmar se o container `n8n` também está em `multiverso-network`. Se estiver, o webhook pode potencialmente usar um endereço interno como `http://n8n:5678/...`, evitando uma volta pela internet e dependência do Cloudflare. Essa mudança exige teste porque o n8n diferencia URLs de produção e teste.

## Instâncias

| Item | Estado confirmado |
|---|---|
| Quantidade | 1 |
| Identificador sanitizado | `inst-ca8b26bc75` |
| Estado | `open` |
| Integração | `WHATSAPP-BAILEYS` |
| Chats armazenados | 46 |
| Contatos armazenados | 52 |
| Mensagens armazenadas | 3.868 |

O estado `open` indica que a instância estava conectada no momento da coleta. Uma única observação não confirma estabilidade contínua.

As contagens demonstram que dados de comunicação estão sendo persistidos. É necessário definir prazo de retenção, finalidade, acesso, backup e exclusão de dados pessoais.

### Arquitetura-alvo das instâncias

Cada empresa contratante terá um número próprio e uma instância própria na Evolution API. Essa instância será vinculada ao contratante correto e ao workflow principal individual daquela empresa.

Meta desta etapa:

- até 50 empresas;
- até 50 números de WhatsApp;
- até 50 instâncias Evolution;
- até 50 workflows principais individuais.

O nome da instância não deve ser o único mecanismo de segurança. O banco deverá manter vínculo formal entre o identificador do contratante, o identificador da instância e o workflow correspondente.

Uma mensagem recebida somente poderá continuar para o atendimento depois que a instância for reconhecida e associada a um contratante ativo.

## Webhook

| Item | Estado confirmado |
|---|---|
| Consulta da configuração | HTTP 200 |
| Habilitado | Sim |
| Destino | Domínio HTTPS do n8n, caminho ocultado |
| Webhook separado por evento | Não |
| Evento habilitado | `MESSAGES_UPSERT` |

`MESSAGES_UPSERT` é suficiente para entregar novas mensagens ao atendimento principal. Entretanto, somente esse evento não oferece monitoramento completo da saúde da conexão ou do ciclo de entrega.

Deve-se avaliar a necessidade dos seguintes eventos, conforme a versão e a arquitetura escolhida:

- Atualização de conexão, para detectar quedas.
- Atualização de mensagens, para status de entrega/leitura quando necessário.
- Atualização de QR code, para reconexão assistida.
- Eventos de envio, somente se necessários e com proteção contra loop.

Não se deve habilitar todos os eventos indiscriminadamente. Cada evento adicional aumenta carga, execuções no n8n e risco de loops.

## Relação com o controle de atendimento humano

O workflow `_guard_antiloop` depende de mensagens que indiquem `fromMe` para detectar quando alguém respondeu pelo próprio WhatsApp e suspender a IA durante 30 minutos.

Regra oficial: o prazo é contado desde a última mensagem manual do profissional. Cada nova mensagem manual deve renovar a pausa por mais 30 minutos. Ao completar esse período sem nova intervenção humana, a IA volta automaticamente para aquela conversa.

Mensagens do cliente recebidas durante a pausa devem ser guardadas como pendentes. Se não houver resposta manual, elas serão agrupadas e respondidas automaticamente pela IA ao final dos 30 minutos. Uma resposta manual posterior à mensagem do cliente deve cancelar a resposta automática pendente.

É necessário testar explicitamente se, nesta versão e configuração da Evolution API:

- Uma mensagem manual do profissional gera `MESSAGES_UPSERT`.
- O campo `fromMe` chega com o valor esperado.
- O identificador da mensagem é estável.
- O mesmo evento não é processado duas vezes.
- Mensagens enviadas pelo próprio bot são distinguidas das mensagens manuais.
- Cada nova mensagem manual renova corretamente o prazo no Redis.
- A expiração da pausa reativa somente a conversa correta.
- Mensagens do cliente recebidas durante a pausa não provocam resposta automática indevida.
- A retomada programada responde mensagens pendentes sem exigir uma nova mensagem do cliente.
- Uma resposta humana cancela a resposta automática pendente.
- Execuções concorrentes não enviam duas respostas para a mesma pendência.

## Saúde e estabilidade

| Verificação | Resultado |
|---|---|
| Resposta HTTP local | 200 |
| Reinícios do container | 2 |
| Indícios de erro/desconexão em 24h | 6 linhas |
| Indícios de reconexão em 24h | 0 linhas |

As contagens não revelam a causa. Os dois reinícios podem ter vindo de atualização, reinício manual, falha, falta de memória ou reinício do Docker/servidor.

Uma próxima coleta deve registrar apenas metadados sanitizados dos eventos:

- Horário.
- Nível do log.
- Categoria do erro.
- Código ou tipo da exceção.
- Quantidade de ocorrências.

Não devem ser coletados corpo de mensagem, telefone, JID, nome de cliente, QR code, token ou chave.

## Cloudflare Tunnel

Foram encontradas rotas para:

- n8n em `localhost:5678`.
- Evolution API em `localhost:8081`.
- Baserow em `localhost:8000`.
- Portainer em `localhost:9000`.
- Supabase/Kong em `localhost:8100`.

Os hostnames não apareceram nesta coleta, mas o inventário anterior identificou `evolution.multiverso360.com.br` e `n8n.multiverso360.com.br`.

## Segurança

Pontos positivos:

- Porta da Evolution limitada ao loopback do host.
- Chave da API não apareceu no relatório.
- Banco e Redis são configurados por URI oculta.
- Volume persistente está identificado.

Pontos a verificar:

- Quem pode acessar o domínio público da Evolution API.
- Existência de proteção adicional no Cloudflare.
- Rotação e armazenamento da chave global.
- Se a listagem de instâncias retorna tokens ou metadados desnecessários a clientes autorizados.
- Permissões do arquivo Compose e do `.env`.
- Política de logs e retenção das 3.868 mensagens armazenadas.
- Backup consistente do volume e do banco usado pela Evolution.
- Limite de requisições e proteção contra abuso.

## Regras funcionais de formatos

- Texto e áudio serão aceitos no MVP.
- Imagens e vídeos não serão suportados nem enviados para análise.
- Ao receber imagem ou vídeo, o sistema deverá pedir que o cliente use texto ou áudio.
- Documento, localização, contato e outros formatos permanecem fora do escopo.
- Ainda é necessário definir limite de duração e tamanho para áudio.
- Tratamento de mensagens editadas ou apagadas.
- Tratamento de grupos.
- Tratamento de chamadas.
- Deduplicação pelo ID da mensagem.
- Ordem de mensagens simultâneas.
- Número de tentativas no envio.
- Tempo máximo de espera.
- Política quando o WhatsApp está desconectado.
- Horário permitido para lembretes e reativação.
- Consentimento e descadastro.
- Escalonamento após falha de envio.

## Prioridades do item 4

### Críticas

1. Confirmar que mensagens manuais do profissional ativam corretamente o handoff e que mensagens do bot não ativam falso handoff.
2. Investigar os dois reinícios e classificar os seis indícios de erro sem expor dados pessoais.
3. Definir retenção e exclusão das mensagens, contatos e chats armazenados.

### Altas

1. Fixar uma versão/digest após testes, evitando atualização acidental por `latest`.
2. Criar monitoramento de estado da instância e alerta de desconexão.
3. Confirmar backup e restauração da Evolution API.
4. Testar deduplicação e ordenação de mensagens.
5. Avaliar webhook interno entre Evolution e n8n.

### Médias

1. Definir URL canônica pública ou privada.
2. Revisar eventos adicionais realmente necessários.
3. Documentar limites de mídia, grupos e mensagens especiais.
4. Criar teste periódico de envio e recebimento sem envolver clientes reais.
5. Executar testes progressivos com múltiplas instâncias conectadas antes de declarar capacidade para 50 empresas.

## Situação do item 4

O caminho básico WhatsApp → Evolution API → webhook do n8n está confirmado e operacional no momento da coleta. Estabilidade, entrega, deduplicação, handoff humano, retenção e recuperação ainda precisam de testes específicos antes de o item ser considerado concluído.
