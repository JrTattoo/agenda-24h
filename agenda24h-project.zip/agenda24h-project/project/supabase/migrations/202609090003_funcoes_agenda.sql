-- Agenda 24h V2 — migration 003: contrato transacional da agenda

create or replace function public.verificar_disponibilidade(
  p_empresa_id uuid,
  p_profissional_id uuid,
  p_servico_id uuid,
  p_inicio_em timestamptz,
  p_ignorar_agendamento_id uuid default null
)
returns boolean
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_config public.empresa_configuracoes%rowtype;
  v_empresa public.empresas%rowtype;
  v_duracao_min smallint;
  v_inicio_local timestamp;
  v_fim_atendimento timestamptz;
  v_fim_bloqueio timestamptz;
begin
  select * into v_empresa
  from public.empresas
  where id = p_empresa_id;

  if not found then
    raise exception 'Empresa não encontrada';
  end if;

  select * into v_config
  from public.empresa_configuracoes
  where empresa_id = p_empresa_id;

  if not found then
    raise exception 'Configuração da empresa não encontrada';
  end if;

  if v_empresa.status_operacional <> 'ativo' then
    raise exception 'Empresa não está ativa para agendamentos';
  end if;

  select coalesce(ps.duracao_min_override, s.duracao_min)
  into v_duracao_min
  from public.profissional_servicos ps
  join public.servicos s on s.id = ps.servico_id and s.empresa_id = ps.empresa_id
  join public.profissionais p on p.id = ps.profissional_id and p.empresa_id = ps.empresa_id
  where ps.empresa_id = p_empresa_id
    and ps.profissional_id = p_profissional_id
    and ps.servico_id = p_servico_id
    and ps.ativo
    and s.ativo
    and p.ativo;

  if v_duracao_min is null then
    raise exception 'Profissional não está habilitado para este serviço';
  end if;

  if p_inicio_em < now() + make_interval(mins => v_config.antecedencia_minima_min) then
    raise exception 'Horário não respeita a antecedência mínima';
  end if;

  v_fim_atendimento := p_inicio_em + make_interval(mins => v_duracao_min);
  v_fim_bloqueio := v_fim_atendimento + make_interval(mins => v_config.buffer_posterior_min);
  v_inicio_local := p_inicio_em at time zone v_empresa.fuso_horario;

  if not exists (
    select 1
    from public.horarios_empresa h
    where h.empresa_id = p_empresa_id
      and h.ativo
      and h.dia_semana = extract(dow from v_inicio_local)::smallint
      and h.inicio <= v_inicio_local::time
      and h.fim >= (v_inicio_local + make_interval(mins => v_duracao_min))::time
  ) then
    raise exception 'Horário fora do expediente da empresa';
  end if;

  if not exists (
    select 1
    from public.horarios_profissionais h
    where h.empresa_id = p_empresa_id
      and h.profissional_id = p_profissional_id
      and h.ativo
      and h.dia_semana = extract(dow from v_inicio_local)::smallint
      and h.inicio <= v_inicio_local::time
      and h.fim >= (v_inicio_local + make_interval(mins => v_duracao_min))::time
  ) then
    raise exception 'Horário fora do expediente do profissional';
  end if;

  if exists (
    select 1
    from public.excecoes_agenda x
    where x.empresa_id = p_empresa_id
      and x.bloqueia_agenda
      and (x.profissional_id is null or x.profissional_id = p_profissional_id)
      and x.inicio_em < v_fim_bloqueio
      and x.fim_em > p_inicio_em
  ) then
    raise exception 'Horário bloqueado na agenda';
  end if;

  if exists (
    select 1
    from public.agendamentos a
    where a.empresa_id = p_empresa_id
      and a.profissional_id = p_profissional_id
      and a.status = 'confirmado'
      and a.id is distinct from p_ignorar_agendamento_id
      and a.inicio_em < v_fim_bloqueio
      and a.fim_bloqueio_em > p_inicio_em
  ) then
    raise exception 'Horário já ocupado';
  end if;

  return true;
end;
$$;

create or replace function public.programar_lembretes_agendamento(
  p_empresa_id uuid,
  p_cliente_id uuid,
  p_agendamento_id uuid,
  p_inicio_em timestamptz
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_config public.empresa_configuracoes%rowtype;
  v_quando timestamptz;
begin
  select * into v_config
  from public.empresa_configuracoes
  where empresa_id = p_empresa_id;

  if v_config.lembrete_24h_ativo then
    v_quando := p_inicio_em - interval '24 hours';
    if v_quando > now() then
      insert into public.fila_mensagens (
        empresa_id, cliente_id, agendamento_id, tipo, chave_idempotencia, programado_para
      ) values (
        p_empresa_id, p_cliente_id, p_agendamento_id, 'lembrete_24h',
        format('agendamento:%s:lembrete_24h:%s', p_agendamento_id, p_inicio_em), v_quando
      ) on conflict (chave_idempotencia) do nothing;
    end if;
  end if;

  if v_config.lembrete_2h_ativo then
    v_quando := p_inicio_em - interval '2 hours';
    if v_quando > now() then
      insert into public.fila_mensagens (
        empresa_id, cliente_id, agendamento_id, tipo, chave_idempotencia, programado_para
      ) values (
        p_empresa_id, p_cliente_id, p_agendamento_id, 'lembrete_2h',
        format('agendamento:%s:lembrete_2h:%s', p_agendamento_id, p_inicio_em), v_quando
      ) on conflict (chave_idempotencia) do nothing;
    end if;
  end if;
end;
$$;

create or replace function public.buscar_horarios_disponiveis(
  p_empresa_id uuid,
  p_profissional_id uuid,
  p_servico_id uuid,
  p_data date,
  p_intervalo_min smallint default 30
)
returns table (
  inicio_em timestamptz,
  fim_atendimento_em timestamptz,
  preco numeric(12,2)
)
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_empresa public.empresas%rowtype;
  v_duracao_min smallint;
  v_preco numeric(12,2);
  v_inicio_candidato timestamptz;
begin
  if p_intervalo_min <= 0 then
    raise exception 'Intervalo de busca inválido';
  end if;

  select * into v_empresa from public.empresas where id = p_empresa_id;
  if not found then
    raise exception 'Empresa não encontrada';
  end if;

  select coalesce(ps.duracao_min_override, s.duracao_min),
         coalesce(ps.preco_override, s.preco)
  into v_duracao_min, v_preco
  from public.profissional_servicos ps
  join public.servicos s on s.id = ps.servico_id and s.empresa_id = ps.empresa_id
  join public.profissionais p on p.id = ps.profissional_id and p.empresa_id = ps.empresa_id
  where ps.empresa_id = p_empresa_id
    and ps.profissional_id = p_profissional_id
    and ps.servico_id = p_servico_id
    and ps.ativo and s.ativo and p.ativo;

  if v_duracao_min is null then
    raise exception 'Profissional não está habilitado para este serviço';
  end if;

  for v_inicio_candidato in
    select (slot.horario at time zone v_empresa.fuso_horario)
    from public.horarios_empresa h
    join public.horarios_profissionais hp
      on hp.empresa_id = h.empresa_id
     and hp.profissional_id = p_profissional_id
     and hp.dia_semana = h.dia_semana
     and hp.ativo
    cross join lateral generate_series(
      (p_data + greatest(h.inicio, hp.inicio))::timestamp,
      (p_data + least(h.fim, hp.fim) - make_interval(mins => v_duracao_min))::timestamp,
      make_interval(mins => p_intervalo_min)
    ) as slot(horario)
    where h.empresa_id = p_empresa_id
      and h.ativo
      and h.dia_semana = extract(dow from p_data)::smallint
    order by 1
  loop
    begin
      perform public.verificar_disponibilidade(
        p_empresa_id, p_profissional_id, p_servico_id, v_inicio_candidato, null
      );
      inicio_em := v_inicio_candidato;
      fim_atendimento_em := v_inicio_candidato + make_interval(mins => v_duracao_min);
      preco := v_preco;
      return next;
    exception when others then
      -- Horários indisponíveis são descartados; a gravação final sempre valida de novo.
      null;
    end;
  end loop;
end;
$$;

create or replace function public.criar_agendamento(
  p_empresa_id uuid,
  p_cliente_id uuid,
  p_profissional_id uuid,
  p_servico_id uuid,
  p_inicio_em timestamptz,
  p_origem public.agendamento_origem default 'cliente_whatsapp',
  p_observacoes_cliente text default null,
  p_criado_por_membro_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_config public.empresa_configuracoes%rowtype;
  v_duracao_min smallint;
  v_preco numeric(12,2);
  v_agendamento_id uuid;
begin
  if not exists (
    select 1 from public.clientes c
    where c.id = p_cliente_id
      and c.empresa_id = p_empresa_id
      and c.status_cadastro = 'ativo'
      and c.anonimizado_em is null
  ) then
    raise exception 'Cliente inválido para agendamento';
  end if;

  perform public.verificar_disponibilidade(
    p_empresa_id, p_profissional_id, p_servico_id, p_inicio_em, null
  );

  select c.* into v_config
  from public.empresa_configuracoes c
  where c.empresa_id = p_empresa_id;

  select coalesce(ps.duracao_min_override, s.duracao_min),
         coalesce(ps.preco_override, s.preco)
  into v_duracao_min, v_preco
  from public.profissional_servicos ps
  join public.servicos s on s.id = ps.servico_id and s.empresa_id = ps.empresa_id
  where ps.empresa_id = p_empresa_id
    and ps.profissional_id = p_profissional_id
    and ps.servico_id = p_servico_id
    and ps.ativo and s.ativo;

  insert into public.agendamentos (
    empresa_id, cliente_id, profissional_id, servico_id,
    inicio_em, fim_atendimento_em, fim_bloqueio_em, duracao_min, preco,
    origem, observacoes_cliente, criado_por_membro_id
  ) values (
    p_empresa_id, p_cliente_id, p_profissional_id, p_servico_id,
    p_inicio_em,
    p_inicio_em + make_interval(mins => v_duracao_min),
    p_inicio_em + make_interval(mins => v_duracao_min + v_config.buffer_posterior_min),
    v_duracao_min, v_preco,
    p_origem, p_observacoes_cliente, p_criado_por_membro_id
  ) returning id into v_agendamento_id;

  insert into public.agendamento_eventos (
    empresa_id, agendamento_id, tipo, origem, ator_tipo, membro_empresa_id, dados_novos
  ) values (
    p_empresa_id, v_agendamento_id, 'criado', p_origem,
    case when p_criado_por_membro_id is null then 'cliente' else 'membro_empresa' end,
    p_criado_por_membro_id,
    jsonb_build_object('inicio_em', p_inicio_em, 'duracao_min', v_duracao_min, 'preco', v_preco)
  );

  perform public.programar_lembretes_agendamento(
    p_empresa_id, p_cliente_id, v_agendamento_id, p_inicio_em
  );

  return v_agendamento_id;
end;
$$;

create or replace function public.cancelar_agendamento(
  p_empresa_id uuid,
  p_cliente_id uuid,
  p_agendamento_id uuid,
  p_motivo text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_agendamento public.agendamentos%rowtype;
  v_min_cancelamento smallint;
begin
  select a.* into v_agendamento
  from public.agendamentos a
  where a.id = p_agendamento_id
    and a.empresa_id = p_empresa_id
    and a.cliente_id = p_cliente_id
  for update;

  if not found then
    raise exception 'Agendamento não encontrado';
  end if;

  select antecedencia_cancelamento_min into v_min_cancelamento
  from public.empresa_configuracoes
  where empresa_id = p_empresa_id;

  if v_agendamento.status <> 'confirmado' then
    raise exception 'Agendamento não pode ser cancelado';
  end if;

  if v_agendamento.inicio_em <= now() + make_interval(mins => v_min_cancelamento) then
    raise exception 'Cancelamento automático não permitido neste prazo';
  end if;

  update public.agendamentos
  set status = 'cancelado', cancelado_em = now(), motivo_cancelamento = p_motivo
  where id = p_agendamento_id and empresa_id = p_empresa_id;

  update public.fila_mensagens
  set estado = 'cancelado', cancelado_em = now()
  where empresa_id = p_empresa_id
    and agendamento_id = p_agendamento_id
    and estado in ('pendente', 'processando');

  insert into public.agendamento_eventos (
    empresa_id, agendamento_id, tipo, origem, ator_tipo, motivo
  ) values (
    p_empresa_id, p_agendamento_id, 'cancelado', 'cliente_whatsapp', 'cliente', p_motivo
  );
end;
$$;

create or replace function public.reagendar_agendamento(
  p_empresa_id uuid,
  p_cliente_id uuid,
  p_agendamento_id uuid,
  p_profissional_id uuid,
  p_servico_id uuid,
  p_novo_inicio_em timestamptz,
  p_motivo text default null
)
returns uuid
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_agendamento public.agendamentos%rowtype;
  v_min_cancelamento smallint;
  v_config public.empresa_configuracoes%rowtype;
  v_duracao_min smallint;
  v_preco numeric(12,2);
begin
  select a.* into v_agendamento
  from public.agendamentos a
  where a.id = p_agendamento_id
    and a.empresa_id = p_empresa_id
    and a.cliente_id = p_cliente_id
  for update;

  if not found then
    raise exception 'Agendamento não encontrado';
  end if;

  select antecedencia_cancelamento_min into v_min_cancelamento
  from public.empresa_configuracoes
  where empresa_id = p_empresa_id;

  if v_agendamento.status <> 'confirmado' then
    raise exception 'Agendamento não pode ser remarcado';
  end if;

  if v_agendamento.inicio_em <= now() + make_interval(mins => v_min_cancelamento) then
    raise exception 'Remarcação automática não permitida neste prazo';
  end if;

  perform public.verificar_disponibilidade(
    p_empresa_id, p_profissional_id, p_servico_id, p_novo_inicio_em, p_agendamento_id
  );

  select * into v_config from public.empresa_configuracoes where empresa_id = p_empresa_id;

  select coalesce(ps.duracao_min_override, s.duracao_min),
         coalesce(ps.preco_override, s.preco)
  into v_duracao_min, v_preco
  from public.profissional_servicos ps
  join public.servicos s on s.id = ps.servico_id and s.empresa_id = ps.empresa_id
  where ps.empresa_id = p_empresa_id
    and ps.profissional_id = p_profissional_id
    and ps.servico_id = p_servico_id
    and ps.ativo and s.ativo;

  update public.agendamentos
  set profissional_id = p_profissional_id,
      servico_id = p_servico_id,
      inicio_em = p_novo_inicio_em,
      fim_atendimento_em = p_novo_inicio_em + make_interval(mins => v_duracao_min),
      fim_bloqueio_em = p_novo_inicio_em + make_interval(mins => v_duracao_min + v_config.buffer_posterior_min),
      duracao_min = v_duracao_min,
      preco = v_preco
  where id = p_agendamento_id and empresa_id = p_empresa_id;

  update public.fila_mensagens
  set estado = 'cancelado', cancelado_em = now()
  where empresa_id = p_empresa_id
    and agendamento_id = p_agendamento_id
    and estado in ('pendente', 'processando');

  perform public.programar_lembretes_agendamento(
    p_empresa_id, p_cliente_id, p_agendamento_id, p_novo_inicio_em
  );

  insert into public.agendamento_eventos (
    empresa_id, agendamento_id, tipo, origem, ator_tipo, dados_anteriores, dados_novos, motivo
  ) values (
    p_empresa_id, p_agendamento_id, 'reagendado', 'cliente_whatsapp', 'cliente',
    jsonb_build_object('inicio_em', v_agendamento.inicio_em, 'profissional_id', v_agendamento.profissional_id, 'servico_id', v_agendamento.servico_id),
    jsonb_build_object('inicio_em', p_novo_inicio_em, 'profissional_id', p_profissional_id, 'servico_id', p_servico_id),
    p_motivo
  );

  return p_agendamento_id;
end;
$$;

create or replace function public.listar_agendamentos_cliente(
  p_empresa_id uuid,
  p_cliente_id uuid
)
returns table (
  agendamento_id uuid,
  inicio_em timestamptz,
  fim_atendimento_em timestamptz,
  status public.agendamento_status,
  profissional_id uuid,
  profissional_nome text,
  servico_id uuid,
  servico_nome text,
  preco numeric(12,2)
)
language sql
security definer
set search_path = public
as $$
  select a.id, a.inicio_em, a.fim_atendimento_em, a.status,
         p.id, p.nome, s.id, s.nome, a.preco
  from public.agendamentos a
  join public.profissionais p on p.id = a.profissional_id and p.empresa_id = a.empresa_id
  join public.servicos s on s.id = a.servico_id and s.empresa_id = a.empresa_id
  where a.empresa_id = p_empresa_id
    and a.cliente_id = p_cliente_id
    and a.inicio_em >= now()
    and a.status = 'confirmado'
  order by a.inicio_em;
$$;

revoke all on function public.verificar_disponibilidade(uuid, uuid, uuid, timestamptz, uuid) from public, anon, authenticated;
revoke all on function public.programar_lembretes_agendamento(uuid, uuid, uuid, timestamptz) from public, anon, authenticated;
revoke all on function public.buscar_horarios_disponiveis(uuid, uuid, uuid, date, smallint) from public, anon, authenticated;
revoke all on function public.criar_agendamento(uuid, uuid, uuid, uuid, timestamptz, public.agendamento_origem, text, uuid) from public, anon, authenticated;
revoke all on function public.cancelar_agendamento(uuid, uuid, uuid, text) from public, anon, authenticated;
revoke all on function public.reagendar_agendamento(uuid, uuid, uuid, uuid, uuid, timestamptz, text) from public, anon, authenticated;
revoke all on function public.listar_agendamentos_cliente(uuid, uuid) from public, anon, authenticated;

grant execute on function public.verificar_disponibilidade(uuid, uuid, uuid, timestamptz, uuid) to service_role;
grant execute on function public.buscar_horarios_disponiveis(uuid, uuid, uuid, date, smallint) to service_role;
grant execute on function public.criar_agendamento(uuid, uuid, uuid, uuid, timestamptz, public.agendamento_origem, text, uuid) to service_role;
grant execute on function public.cancelar_agendamento(uuid, uuid, uuid, text) to service_role;
grant execute on function public.reagendar_agendamento(uuid, uuid, uuid, uuid, uuid, timestamptz, text) to service_role;
grant execute on function public.listar_agendamentos_cliente(uuid, uuid) to service_role;
