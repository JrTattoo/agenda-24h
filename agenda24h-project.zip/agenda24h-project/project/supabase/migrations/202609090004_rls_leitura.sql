-- Agenda 24h V2 — migration 004: RLS e leitura segura do portal

create or replace function public.eh_operador_plataforma()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.operadores_plataforma o
    where o.usuario_id = auth.uid() and o.ativo
  );
$$;

create or replace function public.eh_membro_empresa(p_empresa_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.membros_empresa m
    where m.empresa_id = p_empresa_id
      and m.usuario_id = auth.uid()
      and m.ativo
  );
$$;

create or replace function public.eh_administrador_empresa(p_empresa_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.membros_empresa m
    where m.empresa_id = p_empresa_id
      and m.usuario_id = auth.uid()
      and m.ativo
      and m.papel_acesso = 'administrador'
  );
$$;

create or replace function public.eh_profissional_da_empresa(
  p_empresa_id uuid,
  p_profissional_id uuid
)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.membros_empresa m
    where m.empresa_id = p_empresa_id
      and m.usuario_id = auth.uid()
      and m.ativo
      and m.papel_acesso = 'profissional'
      and m.profissional_id = p_profissional_id
  );
$$;

revoke all on function public.eh_operador_plataforma() from public;
revoke all on function public.eh_membro_empresa(uuid) from public;
revoke all on function public.eh_administrador_empresa(uuid) from public;
revoke all on function public.eh_profissional_da_empresa(uuid, uuid) from public;
grant execute on function public.eh_operador_plataforma() to authenticated;
grant execute on function public.eh_membro_empresa(uuid) to authenticated;
grant execute on function public.eh_administrador_empresa(uuid) to authenticated;
grant execute on function public.eh_profissional_da_empresa(uuid, uuid) to authenticated;

grant usage on schema public to authenticated;
grant select on all tables in schema public to authenticated;

-- Plataforma: acesso operacional interno separado dos usuários das empresas.
create policy operadores_plataforma_select on public.operadores_plataforma
for select to authenticated
using (usuario_id = (select auth.uid()) or public.eh_operador_plataforma());

create policy planos_select on public.planos
for select to authenticated
using (public.eh_operador_plataforma() or exists (
  select 1 from public.membros_empresa m where m.usuario_id = (select auth.uid()) and m.ativo
));

-- Empresa e configurações.
create policy empresas_select on public.empresas
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_membro_empresa(id));

create policy empresa_configuracoes_select on public.empresa_configuracoes
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_membro_empresa(empresa_id));

create policy assinaturas_select on public.assinaturas
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_administrador_empresa(empresa_id));

create policy eventos_stripe_select on public.eventos_stripe
for select to authenticated
using (public.eh_operador_plataforma());

-- Usuários, profissionais e catálogo.
create policy membros_empresa_select on public.membros_empresa
for select to authenticated
using (
  public.eh_operador_plataforma()
  or public.eh_administrador_empresa(empresa_id)
  or usuario_id = (select auth.uid())
);

create policy profissionais_select on public.profissionais
for select to authenticated
using (
  public.eh_operador_plataforma()
  or public.eh_administrador_empresa(empresa_id)
  or public.eh_profissional_da_empresa(empresa_id, id)
);

create policy servicos_select on public.servicos
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_membro_empresa(empresa_id));

create policy profissional_servicos_select on public.profissional_servicos
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_membro_empresa(empresa_id));

create policy horarios_empresa_select on public.horarios_empresa
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_membro_empresa(empresa_id));

create policy horarios_profissionais_select on public.horarios_profissionais
for select to authenticated
using (
  public.eh_operador_plataforma()
  or public.eh_administrador_empresa(empresa_id)
  or public.eh_profissional_da_empresa(empresa_id, profissional_id)
);

create policy excecoes_agenda_select on public.excecoes_agenda
for select to authenticated
using (
  public.eh_operador_plataforma()
  or public.eh_administrador_empresa(empresa_id)
  or (profissional_id is null and public.eh_membro_empresa(empresa_id))
  or public.eh_profissional_da_empresa(empresa_id, profissional_id)
);

-- Agenda: profissional vê somente linhas vinculadas ao próprio profissional.
create policy agendamentos_select on public.agendamentos
for select to authenticated
using (
  public.eh_operador_plataforma()
  or public.eh_administrador_empresa(empresa_id)
  or public.eh_profissional_da_empresa(empresa_id, profissional_id)
);

create policy agendamento_eventos_select on public.agendamento_eventos
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_administrador_empresa(empresa_id));

-- Dados pessoais, conversas e automações ficam restritos a administrador/operador.
create policy clientes_select on public.clientes
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_administrador_empresa(empresa_id));

create policy conversas_select on public.conversas
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_administrador_empresa(empresa_id));

create policy mensagens_select on public.mensagens
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_administrador_empresa(empresa_id));

create policy fila_mensagens_select on public.fila_mensagens
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_administrador_empresa(empresa_id));

create policy solicitacoes_privacidade_select on public.solicitacoes_privacidade
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_administrador_empresa(empresa_id));

create policy logs_auditoria_select on public.logs_auditoria
for select to authenticated
using (public.eh_operador_plataforma());

create policy empresa_conteudos_select on public.empresa_conteudos
for select to authenticated
using (public.eh_operador_plataforma() or public.eh_administrador_empresa(empresa_id));

-- Escrita direta permanece bloqueada: criação, alteração e cancelamento de
-- agendamento serão sempre feitos por RPCs controladas ou service_role.
