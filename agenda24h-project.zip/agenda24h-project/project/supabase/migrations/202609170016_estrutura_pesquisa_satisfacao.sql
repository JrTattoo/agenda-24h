-- Estrutura independente de satisfação. Não ativa envios nem altera a fila.
-- Depende das migrations 001/004/005/009, não depende de 013/014.
begin;

create table public.pesquisa_satisfacao_configuracoes (
  empresa_id uuid primary key references public.empresas(id) on delete cascade,
  habilitada boolean not null default false,
  escala_min smallint,
  escala_max smallint,
  atraso_envio_min integer check (atraso_envio_min >= 0),
  intervalo_por_cliente_dias integer check (intervalo_por_cliente_dias > 0),
  validade_resposta_dias integer check (validade_resposta_dias > 0),
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  constraint pesquisa_config_escala check (
    (escala_min is null and escala_max is null)
    or (escala_min is not null and escala_max is not null and escala_min < escala_max)
  ),
  constraint pesquisa_config_habilitacao check (
    not habilitada or (
      escala_min is not null and escala_max is not null
      and atraso_envio_min is not null
      and intervalo_por_cliente_dias is not null
      and validade_resposta_dias is not null
    )
  )
);

create table public.pesquisas_satisfacao (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  cliente_id uuid not null,
  agendamento_id uuid not null,
  estado text not null default 'rascunho'
    check (estado in ('rascunho', 'programada', 'enviada', 'respondida', 'expirada', 'cancelada')),
  -- Escala histórica da pesquisa: uma alteração futura não reinterpreta notas.
  escala_min smallint not null,
  escala_max smallint not null,
  programada_para timestamptz,
  enviada_em timestamptz,
  expira_em timestamptz,
  nota smallint,
  respondida_em timestamptz,
  comentario text check (char_length(comentario) <= 2000),
  comentario_removido_em timestamptz,
  cancelada_em timestamptz,
  motivo_cancelamento text check (char_length(motivo_cancelamento) <= 200),
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (id, empresa_id),
  unique (empresa_id, agendamento_id),
  foreign key (cliente_id, empresa_id) references public.clientes(id, empresa_id) on delete restrict,
  foreign key (agendamento_id, empresa_id) references public.agendamentos(id, empresa_id) on delete restrict,
  check (escala_min < escala_max),
  check (nota is null or nota between escala_min and escala_max),
  check ((nota is null) = (respondida_em is null)),
  check (comentario is null or nota is not null),
  check (estado <> 'programada' or programada_para is not null),
  check (estado not in ('enviada', 'respondida', 'expirada') or
    (enviada_em is not null and expira_em is not null)),
  check (enviada_em is null or (expira_em is not null and expira_em > enviada_em)),
  check (nota is null or (enviada_em is not null and expira_em is not null
    and respondida_em >= enviada_em and respondida_em <= expira_em)),
  check ((estado = 'respondida') = (nota is not null)),
  check ((estado = 'cancelada') = (cancelada_em is not null)),
  check (estado <> 'cancelada' or motivo_cancelamento is not null)
);

create index pesquisas_empresa_envio_idx on public.pesquisas_satisfacao(empresa_id, enviada_em);
create index pesquisas_empresa_resposta_idx on public.pesquisas_satisfacao(empresa_id, respondida_em)
  where nota is not null;
create index pesquisas_cliente_idx on public.pesquisas_satisfacao(empresa_id, cliente_id);

-- Valida vínculo e elegibilidade mesmo em escrita interna de serviço.
create function public.validar_estrutura_pesquisa_satisfacao()
returns trigger language plpgsql set search_path = pg_catalog, public as $$
declare
  v_cliente uuid;
  v_status public.agendamento_status;
  v_concluido timestamptz;
  v_anonimizado timestamptz;
begin
  if tg_op = 'UPDATE' then
    if row(new.empresa_id, new.cliente_id, new.agendamento_id, new.escala_min, new.escala_max)
      is distinct from row(old.empresa_id, old.cliente_id, old.agendamento_id, old.escala_min, old.escala_max) then
      raise exception 'Vínculos e escala histórica da pesquisa não podem ser alterados';
    end if;
  end if;
  select a.cliente_id, a.status, a.concluido_em into v_cliente, v_status, v_concluido
    from public.agendamentos a where a.id = new.agendamento_id and a.empresa_id = new.empresa_id;
  if not found or v_cliente is distinct from new.cliente_id then
    raise exception 'Cliente e atendimento não pertencem ao mesmo vínculo';
  end if;
  select c.anonimizado_em into v_anonimizado from public.clientes c
    where c.id = new.cliente_id and c.empresa_id = new.empresa_id;
  if tg_op = 'INSERT' then
    if v_status <> 'concluido' or v_concluido is null or v_anonimizado is not null then
      raise exception 'Pesquisa requer atendimento concluído e cliente não anonimizado';
    end if;
  end if;
  if v_anonimizado is not null and (new.comentario is not null or new.estado in ('rascunho','programada','enviada')) then
    raise exception 'Cliente anonimizado não pode manter comentário ou pesquisa aberta';
  end if;
  return new;
end;
$$;
create trigger pesquisas_validar before insert or update on public.pesquisas_satisfacao
  for each row execute function public.validar_estrutura_pesquisa_satisfacao();
create trigger pesquisas_atualizado before update on public.pesquisas_satisfacao
  for each row execute function public.definir_atualizado_em();
create trigger pesquisa_config_atualizado before update on public.pesquisa_satisfacao_configuracoes
  for each row execute function public.definir_atualizado_em();

-- Complementa o fluxo de anonimização existente sem substituí-lo.
create function public.limpar_pesquisas_cliente_anonimizado()
returns trigger language plpgsql security definer set search_path = pg_catalog, public as $$
begin
  if new.anonimizado_em is not null and old.anonimizado_em is null then
    update public.pesquisas_satisfacao set
      comentario = null,
      comentario_removido_em = case when comentario is not null then now() else comentario_removido_em end,
      motivo_cancelamento = case when estado in ('rascunho','programada','enviada','cancelada')
        then 'anonimizacao' else null end,
      cancelada_em = case when estado in ('rascunho','programada','enviada') then now() else cancelada_em end,
      estado = case when estado in ('rascunho','programada','enviada') then 'cancelada' else estado end
    where empresa_id = new.empresa_id and cliente_id = new.id;
  end if;
  return new;
end;
$$;
create trigger cliente_limpar_pesquisas after update of anonimizado_em on public.clientes
  for each row execute function public.limpar_pesquisas_cliente_anonimizado();

-- Helper próprio: não depende dos grants auxiliares revogados na migration 009.
create function public.pode_ler_pesquisa_satisfacao(p_empresa_id uuid)
returns boolean language sql stable security definer set search_path = pg_catalog, public as $$
  select exists (select 1 from public.membros_empresa m where m.usuario_id = auth.uid()
    and m.empresa_id = p_empresa_id and m.ativo and m.papel_acesso = 'administrador')
  or exists (select 1 from public.operadores_plataforma o where o.usuario_id = auth.uid() and o.ativo);
$$;

alter table public.pesquisa_satisfacao_configuracoes enable row level security;
alter table public.pesquisas_satisfacao enable row level security;
revoke all on public.pesquisa_satisfacao_configuracoes, public.pesquisas_satisfacao from public, anon, authenticated;
grant select on public.pesquisa_satisfacao_configuracoes, public.pesquisas_satisfacao to authenticated;
grant select, insert, update, delete on public.pesquisa_satisfacao_configuracoes, public.pesquisas_satisfacao to service_role;
revoke all on function public.pode_ler_pesquisa_satisfacao(uuid) from public, anon, authenticated;
grant execute on function public.pode_ler_pesquisa_satisfacao(uuid) to authenticated;
revoke all on function public.validar_estrutura_pesquisa_satisfacao() from public, anon, authenticated;
revoke all on function public.limpar_pesquisas_cliente_anonimizado() from public, anon, authenticated;
create policy pesquisa_config_leitura on public.pesquisa_satisfacao_configuracoes for select to authenticated
  using (public.pode_ler_pesquisa_satisfacao(empresa_id));
create policy pesquisas_leitura on public.pesquisas_satisfacao for select to authenticated
  using (public.pode_ler_pesquisa_satisfacao(empresa_id));

comment on table public.pesquisas_satisfacao is
  'Estrutura de pesquisas e respostas, separada da agenda. Uma pesquisa por atendimento. Ainda sem dispatcher, captura WhatsApp ou métricas integradas.';
comment on table public.pesquisa_satisfacao_configuracoes is
  'Configuração independente por empresa, desabilitada por padrão; parâmetros sem valores de negócio presumidos.';
commit;
