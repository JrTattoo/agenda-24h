-- Valores de fila da pesquisa. Execute esta migration antes da 021.
-- Ela é deliberadamente separada: alguns executores PostgreSQL não permitem
-- usar um valor novo de enum na mesma transação em que ele foi criado.
alter type public.fila_mensagem_tipo add value if not exists 'pesquisa_satisfacao';
alter type public.fila_mensagem_tipo add value if not exists 'convite_google';
alter type public.solicitacao_privacidade_tipo add value if not exists 'descadastro_pesquisa_satisfacao';
alter type public.solicitacao_privacidade_tipo add value if not exists 'descadastro_convite_google';
