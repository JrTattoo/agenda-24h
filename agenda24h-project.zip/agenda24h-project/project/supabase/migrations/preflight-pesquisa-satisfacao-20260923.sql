select current_setting('server_version_num') as postgres_version;
select to_regclass('public.pesquisa_satisfacao_configuracoes') as configuracoes,
       to_regclass('public.pesquisas_satisfacao') as pesquisas,
       to_regclass('public.fila_mensagens') as fila;
select enumlabel from pg_enum join pg_type on pg_type.oid = pg_enum.enumtypid
where typname = 'fila_mensagem_tipo' order by enumsortorder;
select typname, pg_get_userbyid(typowner) as owner
from pg_type where typnamespace = 'public'::regnamespace
  and typname in ('fila_mensagem_tipo', 'solicitacao_privacidade_tipo');
