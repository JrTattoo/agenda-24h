-- Agenda 24h V2 — migration 011: catálogo comercial inicial

insert into public.planos (codigo, nome, descricao, limite_profissionais, valor_mensal, ativo)
values
  ('start', 'Start', 'Até 1 profissional', 1, 99.00, true),
  ('crescimento', 'Crescimento', 'Até 5 profissionais', 5, 149.00, true),
  ('pro', 'Pro', 'Até 15 profissionais', 15, 199.00, true)
on conflict (codigo) do nothing;
