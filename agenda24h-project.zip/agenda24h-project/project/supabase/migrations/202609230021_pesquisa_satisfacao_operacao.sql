-- Pesquisa de satisfação operacional. Requer migrations 016 e 020.
-- Este arquivo prepara o banco; não publica workflows nem envia mensagens.
begin;

alter table public.pesquisa_satisfacao_configuracoes
  add column if not exists google_habilitado boolean not null default false,
  add column if not exists google_avaliacao_url text,
  add column if not exists google_atraso_envio_min integer,
  add column if not exists google_intervalo_por_cliente_dias integer;

alter table public.pesquisa_satisfacao_configuracoes
  drop constraint if exists pesquisa_config_google_habilitacao,
  add constraint pesquisa_config_google_habilitacao check (
    not google_habilitado or (
      google_avaliacao_url ~ '^https://(([a-z0-9-]+[.])?google[.]com/|maps[.]app[.]goo[.]gl/|g[.]page/)'
      and google_atraso_envio_min is not null and google_atraso_envio_min >= 0
      and google_intervalo_por_cliente_dias is not null and google_intervalo_por_cliente_dias > 0
    )
  );

alter table public.clientes
  add column if not exists aceita_pesquisa_satisfacao boolean not null default false,
  add column if not exists aceita_convite_google boolean not null default false,
  add column if not exists preferencias_pos_atendimento_atualizadas_em timestamptz;

alter table public.fila_mensagens
  add column if not exists pesquisa_id uuid,
  add column if not exists contexto jsonb not null default '{}'::jsonb;

alter table public.fila_mensagens
  drop constraint if exists fila_mensagens_pesquisa_empresa_fkey,
  add constraint fila_mensagens_pesquisa_empresa_fkey
    foreign key (pesquisa_id, empresa_id)
    references public.pesquisas_satisfacao(id, empresa_id) on delete restrict;

create table if not exists public.pesquisa_satisfacao_interacoes (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  pesquisa_id uuid,
  mensagem_id uuid not null,
  tipo text not null check (tipo in ('nota', 'comentario', 'pular', 'descadastro_pesquisa', 'descadastro_google', 'invalida')),
  resultado text not null check (resultado in ('registrada', 'ignorada', 'ambigua', 'fora_do_prazo')),
  criado_em timestamptz not null default now(),
  unique (empresa_id, mensagem_id),
  foreign key (pesquisa_id, empresa_id)
    references public.pesquisas_satisfacao(id, empresa_id) on delete restrict,
  foreign key (mensagem_id) references public.mensagens(id) on delete restrict
);

create index if not exists fila_pesquisa_reserva_idx
  on public.fila_mensagens (estado, programado_para)
  where tipo in ('pesquisa_satisfacao', 'convite_google');
create index if not exists pesquisa_interacoes_pesquisa_idx
  on public.pesquisa_satisfacao_interacoes (empresa_id, pesquisa_id, criado_em desc);

alter table public.pesquisa_satisfacao_interacoes enable row level security;
revoke all on public.pesquisa_satisfacao_interacoes from public, anon, authenticated;
grant select on public.pesquisa_satisfacao_interacoes to authenticated;
grant select, insert, update, delete on public.pesquisa_satisfacao_interacoes to service_role;
drop policy if exists pesquisa_interacoes_leitura on public.pesquisa_satisfacao_interacoes;
create policy pesquisa_interacoes_leitura on public.pesquisa_satisfacao_interacoes for select to authenticated
  using (public.pode_ler_pesquisa_satisfacao(empresa_id));

create or replace function public.gerar_pesquisas_satisfacao_pendentes(p_limite integer default 100)
returns integer language plpgsql security definer set search_path = pg_catalog, public as $$
declare
  r record;
  v_inseridas integer := 0;
  v_pesquisa_id uuid;
begin
  if p_limite < 1 or p_limite > 500 then raise exception 'Limite inválido'; end if;
  for r in
    select a.id agendamento_id, a.empresa_id, a.cliente_id, c.escala_min, c.escala_max,
      c.atraso_envio_min, c.intervalo_por_cliente_dias, c.validade_resposta_dias
    from public.agendamentos a
    join public.pesquisa_satisfacao_configuracoes c on c.empresa_id = a.empresa_id and c.habilitada
    join public.clientes cl on cl.id = a.cliente_id and cl.empresa_id = a.empresa_id
    join public.empresas e on e.id = a.empresa_id and e.status_operacional = 'ativo'
    where a.status = 'concluido' and a.concluido_em is not null
      and a.concluido_em + make_interval(mins => c.atraso_envio_min) <= now()
      and cl.aceita_pesquisa_satisfacao and cl.anonimizado_em is null
      and not exists (select 1 from public.pesquisas_satisfacao p where p.empresa_id=a.empresa_id and p.agendamento_id=a.id)
      and not exists (select 1 from public.pesquisas_satisfacao p where p.empresa_id=a.empresa_id and p.cliente_id=a.cliente_id
        and p.enviada_em >= now() - make_interval(days => c.intervalo_por_cliente_dias))
    order by a.concluido_em
    limit p_limite
  loop
    perform pg_advisory_xact_lock(hashtextextended(r.empresa_id::text || ':' || r.cliente_id::text, 0));
    if exists (select 1 from public.pesquisas_satisfacao p where p.empresa_id=r.empresa_id and p.cliente_id=r.cliente_id
      and p.enviada_em >= now() - make_interval(days => r.intervalo_por_cliente_dias)) then continue; end if;
    insert into public.pesquisas_satisfacao
      (empresa_id, cliente_id, agendamento_id, estado, escala_min, escala_max, programada_para)
    values (r.empresa_id, r.cliente_id, r.agendamento_id, 'programada', r.escala_min, r.escala_max, now())
    on conflict (empresa_id, agendamento_id) do nothing returning id into v_pesquisa_id;
    if v_pesquisa_id is not null then
      insert into public.fila_mensagens (empresa_id, cliente_id, agendamento_id, pesquisa_id, tipo, chave_idempotencia, programado_para)
      values (r.empresa_id, r.cliente_id, r.agendamento_id, v_pesquisa_id, 'pesquisa_satisfacao',
        format('empresa:%s:agendamento:%s:pesquisa_satisfacao', r.empresa_id, r.agendamento_id), now())
      on conflict (chave_idempotencia) do nothing;
      v_inseridas := v_inseridas + 1;
    end if;
  end loop;
  return v_inseridas;
end; $$;

create or replace function public.reservar_fila_pesquisas(p_limite integer default 50)
returns setof public.fila_mensagens language plpgsql security definer set search_path = pg_catalog, public as $$
begin
  if p_limite < 1 or p_limite > 200 then raise exception 'Limite inválido'; end if;
  return query with candidatas as (
    select f.id from public.fila_mensagens f join public.empresas e on e.id=f.empresa_id
    where f.tipo in ('pesquisa_satisfacao','convite_google') and f.estado='pendente'
      and f.programado_para <= now() and e.status_operacional='ativo'
    order by f.programado_para, f.criado_em limit p_limite for update skip locked
  ) update public.fila_mensagens f set estado='processando', processando_em=now(), tentativas=tentativas+1
    from candidatas c where f.id=c.id returning f.*;
end; $$;

create or replace function public.preparar_envio_pesquisa_fila(p_fila_id uuid)
returns table (fila_id uuid, telefone_e164 text, conteudo text, instancia_evolution text) language plpgsql security definer set search_path = pg_catalog, public as $$
declare f public.fila_mensagens%rowtype; p public.pesquisas_satisfacao%rowtype; c public.clientes%rowtype; cfg public.pesquisa_satisfacao_configuracoes%rowtype; nome_empresa text;
begin
  select * into f from public.fila_mensagens where id=p_fila_id for update;
  if not found or f.estado <> 'processando' or f.tipo not in ('pesquisa_satisfacao','convite_google') then raise exception 'Fila inválida para pesquisa'; end if;
  select * into p from public.pesquisas_satisfacao where id=f.pesquisa_id and empresa_id=f.empresa_id for update;
  select * into c from public.clientes where id=f.cliente_id and empresa_id=f.empresa_id;
  select * into cfg from public.pesquisa_satisfacao_configuracoes where empresa_id=f.empresa_id;
  select e.nome_fantasia, e.instancia_evolution into nome_empresa, instancia_evolution
    from public.empresas e where e.id=f.empresa_id and e.status_operacional='ativo';
  if nome_empresa is null or c.anonimizado_em is not null or (f.tipo='pesquisa_satisfacao' and (not cfg.habilitada or not c.aceita_pesquisa_satisfacao or p.estado <> 'programada'))
    or (f.tipo='convite_google' and (not cfg.google_habilitado or not c.aceita_convite_google or cfg.google_avaliacao_url is null)) then
    update public.fila_mensagens set estado='cancelado', cancelado_em=now(), ultimo_erro='inelegivel' where id=f.id;
    return;
  end if;
  if f.tipo='pesquisa_satisfacao' then
    conteudo := format('Olá%s! Como foi seu atendimento na %s? Responda com uma nota de %s a %s. A participação é opcional. Para não receber novas pesquisas, envie PARAR PESQUISA.',
      case when nullif(trim(c.nome),'') is null then '' else ', ' || split_part(trim(c.nome),' ',1) end, nome_empresa, p.escala_min, p.escala_max);
  else
    conteudo := format('Se quiser, você também pode compartilhar sua experiência com a %s no Google: %s. A avaliação é opcional. Para não receber esses convites, envie PARAR GOOGLE.', nome_empresa, cfg.google_avaliacao_url);
  end if;
  update public.fila_mensagens set conteudo_renderizado=conteudo where id=f.id;
  fila_id:=f.id; telefone_e164:=c.telefone_e164; return next;
end; $$;

create or replace function public.confirmar_envio_pesquisa_fila(p_fila_id uuid, p_evolution_message_id text default null)
returns void language plpgsql security definer set search_path = pg_catalog, public as $$
declare f public.fila_mensagens%rowtype; cfg public.pesquisa_satisfacao_configuracoes%rowtype;
begin
  select * into f from public.fila_mensagens where id=p_fila_id for update;
  if not found or f.estado <> 'processando' or f.tipo not in ('pesquisa_satisfacao','convite_google') then raise exception 'Fila inválida para confirmação'; end if;
  update public.fila_mensagens set estado='enviado', enviado_em=now(), evolution_message_id=p_evolution_message_id, ultimo_erro=null where id=f.id;
  if f.tipo='pesquisa_satisfacao' then
    select * into cfg from public.pesquisa_satisfacao_configuracoes where empresa_id=f.empresa_id;
    update public.pesquisas_satisfacao set estado='enviada', enviada_em=now(), expira_em=now()+make_interval(days => cfg.validade_resposta_dias) where id=f.pesquisa_id and estado='programada';
    if cfg.google_habilitado then
      insert into public.fila_mensagens (empresa_id,cliente_id,agendamento_id,pesquisa_id,tipo,chave_idempotencia,programado_para)
      values (f.empresa_id,f.cliente_id,f.agendamento_id,f.pesquisa_id,'convite_google',
        format('empresa:%s:agendamento:%s:convite_google',f.empresa_id,f.agendamento_id),now()+make_interval(mins=>cfg.google_atraso_envio_min))
      on conflict (chave_idempotencia) do nothing;
    end if;
  end if;
end; $$;

create or replace function public.processar_resposta_pesquisa(p_empresa_id uuid, p_cliente_id uuid, p_mensagem_id uuid, p_texto text)
returns jsonb language plpgsql security definer set search_path = pg_catalog, public as $$
declare v_texto text:=upper(trim(coalesce(p_texto,''))); p public.pesquisas_satisfacao%rowtype; v_nota smallint; v_comentario text; v_tipo text; v_resultado text;
begin
  if exists (select 1 from public.pesquisa_satisfacao_interacoes where empresa_id=p_empresa_id and mensagem_id=p_mensagem_id) then
    return jsonb_build_object('resultado','repetida');
  end if;
  if v_texto='PARAR PESQUISA' then
    update public.clientes set aceita_pesquisa_satisfacao=false, aceita_convite_google=false, preferencias_pos_atendimento_atualizadas_em=now() where id=p_cliente_id and empresa_id=p_empresa_id;
    update public.fila_mensagens set estado='cancelado',cancelado_em=now(),ultimo_erro='descadastro_pesquisa' where empresa_id=p_empresa_id and cliente_id=p_cliente_id and tipo in ('pesquisa_satisfacao','convite_google') and estado='pendente';
    v_tipo:='descadastro_pesquisa'; v_resultado:='registrada';
  elsif v_texto='PARAR GOOGLE' then
    update public.clientes set aceita_convite_google=false, preferencias_pos_atendimento_atualizadas_em=now() where id=p_cliente_id and empresa_id=p_empresa_id;
    update public.fila_mensagens set estado='cancelado',cancelado_em=now(),ultimo_erro='descadastro_google' where empresa_id=p_empresa_id and cliente_id=p_cliente_id and tipo='convite_google' and estado='pendente';
    v_tipo:='descadastro_google'; v_resultado:='registrada';
  else
    select * into p from public.pesquisas_satisfacao where empresa_id=p_empresa_id and cliente_id=p_cliente_id and estado='enviada' and expira_em >= now() order by enviada_em desc limit 1 for update;
    if not found then v_tipo:='invalida'; v_resultado:='fora_do_prazo';
    elsif v_texto='PULAR' then v_tipo:='pular'; v_resultado:='registrada';
    elsif v_texto ~ '^(NOTA[[:space:]]+)?[0-9]+([[:space:]]*-[[:space:]].+)?$' then
      v_nota := regexp_replace(v_texto,'^(NOTA[[:space:]]+)?([0-9]+).*$','\2')::smallint;
      if v_nota < p.escala_min or v_nota > p.escala_max then v_tipo:='invalida'; v_resultado:='ambigua';
      else
        v_comentario:=nullif(trim(regexp_replace(p_texto,'(?i)^(nota[[:space:]]+)?[0-9]+[[:space:]]*-[[:space:]]*','')),'');
        update public.pesquisas_satisfacao set estado='respondida',nota=v_nota,respondida_em=now(),comentario=v_comentario where id=p.id;
        v_tipo:='nota'; v_resultado:='registrada';
      end if;
    else v_tipo:='invalida'; v_resultado:='ambigua'; end if;
  end if;
  insert into public.pesquisa_satisfacao_interacoes(empresa_id,pesquisa_id,mensagem_id,tipo,resultado)
    values(p_empresa_id,p.id,p_mensagem_id,v_tipo,v_resultado);
  return jsonb_build_object('resultado',v_resultado,'tipo',v_tipo,'pesquisa_id',p.id);
end; $$;

create or replace function public.expirar_pesquisas_satisfacao(p_limite integer default 500)
returns integer language plpgsql security definer set search_path = pg_catalog, public as $$
declare v_total integer;
begin
  with candidatas as (select id from public.pesquisas_satisfacao where estado='enviada' and expira_em < now() order by expira_em limit p_limite for update skip locked)
  update public.pesquisas_satisfacao p set estado='expirada' from candidatas c where p.id=c.id;
  get diagnostics v_total=row_count; return v_total;
end; $$;

create or replace function public.consultar_indicadores_satisfacao_portal(p_empresa_id uuid, p_inicio date default current_date - 29, p_fim date default current_date)
returns jsonb language plpgsql security definer set search_path = pg_catalog, public as $$
declare v_fuso text; v_inicio timestamptz; v_fim timestamptz;
begin
  if p_empresa_id is null or p_inicio is null or p_fim is null or p_fim<p_inicio or p_fim-p_inicio>365 then raise exception 'Período inválido'; end if;
  if not (public.eh_administrador_empresa(p_empresa_id) or public.eh_operador_plataforma()) then raise exception 'Sem permissão'; end if;
  select fuso_horario into v_fuso from public.empresas where id=p_empresa_id; if not found then raise exception 'Empresa não encontrada'; end if;
  v_inicio:=p_inicio::timestamp at time zone v_fuso; v_fim:=(p_fim+1)::timestamp at time zone v_fuso;
  return jsonb_build_object(
    'pesquisas_enviadas',(select count(*) from public.pesquisas_satisfacao where empresa_id=p_empresa_id and enviada_em>=v_inicio and enviada_em<v_fim),
    'respostas_recebidas',(select count(*) from public.pesquisas_satisfacao where empresa_id=p_empresa_id and respondida_em>=v_inicio and respondida_em<v_fim and nota is not null),
    'nota_media',(select coalesce(round(avg(nota)::numeric,1),0) from public.pesquisas_satisfacao where empresa_id=p_empresa_id and respondida_em>=v_inicio and respondida_em<v_fim and nota is not null),
    'convites_google_enviados',(select count(*) from public.fila_mensagens where empresa_id=p_empresa_id and tipo='convite_google' and estado='enviado' and enviado_em>=v_inicio and enviado_em<v_fim)
  );
end; $$;

revoke all on function public.gerar_pesquisas_satisfacao_pendentes(integer), public.reservar_fila_pesquisas(integer), public.preparar_envio_pesquisa_fila(uuid), public.confirmar_envio_pesquisa_fila(uuid,text), public.processar_resposta_pesquisa(uuid,uuid,uuid,text), public.expirar_pesquisas_satisfacao(integer) from public, anon, authenticated;
grant execute on function public.gerar_pesquisas_satisfacao_pendentes(integer), public.reservar_fila_pesquisas(integer), public.preparar_envio_pesquisa_fila(uuid), public.confirmar_envio_pesquisa_fila(uuid,text), public.processar_resposta_pesquisa(uuid,uuid,uuid,text), public.expirar_pesquisas_satisfacao(integer) to service_role;
revoke all on function public.consultar_indicadores_satisfacao_portal(uuid,date,date) from public, anon;
grant execute on function public.consultar_indicadores_satisfacao_portal(uuid,date,date) to authenticated;
commit;
