-- Agenda 24h V2 — migration 002: integridade e desempenho da agenda

create extension if not exists btree_gist with schema extensions;

-- Nomes únicos por empresa, sem diferença de maiúsculas ou espaços externos.
create unique index profissionais_nome_normalizado_unico
  on public.profissionais (empresa_id, lower(btrim(nome)));

create unique index servicos_nome_normalizado_unico
  on public.servicos (empresa_id, lower(btrim(nome)));

-- Um profissional não pode ter dois atendimentos confirmados com intervalos
-- sobrepostos. O intervalo inclui somente o buffer posterior do atendimento.
alter table public.agendamentos
  add constraint agendamentos_sem_sobreposicao_profissional
  exclude using gist (
    empresa_id with =,
    profissional_id with =,
    tstzrange(inicio_em, fim_bloqueio_em, '[)') with &&
  )
  where (status = 'confirmado');

-- Coerência mínima dos estados históricos.
alter table public.agendamentos
  add constraint agendamentos_cancelamento_coerente
  check (status <> 'cancelado' or cancelado_em is not null);

alter table public.agendamentos
  add constraint agendamentos_conclusao_coerente
  check (status <> 'concluido' or concluido_em is not null);

alter table public.agendamentos
  add constraint agendamentos_falta_coerente
  check (status <> 'faltou' or faltou_em is not null);

-- Consultas frequentes das tools, do portal e das automações.
create index agendamentos_empresa_inicio_idx
  on public.agendamentos (empresa_id, inicio_em);

create index agendamentos_profissional_inicio_idx
  on public.agendamentos (empresa_id, profissional_id, inicio_em)
  where status = 'confirmado';

create index agendamentos_cliente_inicio_idx
  on public.agendamentos (empresa_id, cliente_id, inicio_em desc);

create index agendamento_eventos_agendamento_idx
  on public.agendamento_eventos (empresa_id, agendamento_id, criado_em desc);

create index profissionais_empresa_ativos_idx
  on public.profissionais (empresa_id, nome)
  where ativo;

create index servicos_empresa_ativos_idx
  on public.servicos (empresa_id, ordem_exibicao, nome)
  where ativo;

create index profissional_servicos_ativos_idx
  on public.profissional_servicos (empresa_id, servico_id, profissional_id)
  where ativo;

create index horarios_empresa_consulta_idx
  on public.horarios_empresa (empresa_id, dia_semana, inicio)
  where ativo;

create index horarios_profissionais_consulta_idx
  on public.horarios_profissionais (empresa_id, profissional_id, dia_semana, inicio)
  where ativo;

create index excecoes_agenda_consulta_idx
  on public.excecoes_agenda (empresa_id, profissional_id, inicio_em, fim_em);

create index clientes_ultimo_contato_idx
  on public.clientes (empresa_id, ultimo_contato_em)
  where anonimizado_em is null;

create index mensagens_conversa_recebida_idx
  on public.mensagens (empresa_id, conversa_id, recebida_em desc);

create index mensagens_processamento_pendente_idx
  on public.mensagens (empresa_id, recebida_em)
  where estado_processamento in ('recebida', 'pendente', 'processando');

create index fila_mensagens_pendente_idx
  on public.fila_mensagens (programado_para, empresa_id)
  where estado = 'pendente';

create index fila_mensagens_agendamento_idx
  on public.fila_mensagens (empresa_id, agendamento_id)
  where agendamento_id is not null;

create index conversas_pausa_idx
  on public.conversas (empresa_id, pausado_ate)
  where modo_atendimento = 'humano';

create index solicitacoes_privacidade_abertas_idx
  on public.solicitacoes_privacidade (empresa_id, solicitado_em)
  where estado in ('recebida', 'em_verificacao');

create index logs_auditoria_empresa_data_idx
  on public.logs_auditoria (empresa_id, ocorrido_em desc);
