select enumlabel from pg_enum join pg_type on pg_type.oid = pg_enum.enumtypid
where typname = 'fila_mensagem_tipo' order by enumsortorder;

select column_name from information_schema.columns
where table_schema = 'public' and table_name = 'fila_mensagens'
  and column_name in ('pesquisa_id', 'contexto') order by column_name;

select proname from pg_proc join pg_namespace n on n.oid = pg_proc.pronamespace
where n.nspname = 'public' and proname in (
  'gerar_pesquisas_satisfacao_pendentes', 'reservar_fila_pesquisas',
  'preparar_envio_pesquisa_fila', 'confirmar_envio_pesquisa_fila',
  'processar_resposta_pesquisa', 'expirar_pesquisas_satisfacao',
  'consultar_indicadores_satisfacao_portal'
) order by proname;

select has_table_privilege('authenticated', 'public.pesquisa_satisfacao_interacoes', 'select') as authenticated_select,
       has_table_privilege('anon', 'public.pesquisa_satisfacao_interacoes', 'select') as anon_select,
       relrowsecurity as rls_ativa
from pg_class where oid = 'public.pesquisa_satisfacao_interacoes'::regclass;
