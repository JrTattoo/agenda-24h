-- Agenda 24h V2 — migration 001: modelo-base
-- Esta migration cria somente estruturas. Regras transacionais, RLS e RPCs
-- entram em migrations posteriores, depois da revisão deste contrato.

create type public.empresa_status as enum (
  'em_validacao', 'ativo', 'suspenso', 'cancelado', 'falhou'
);

create type public.membro_papel as enum ('administrador', 'profissional');
create type public.cliente_status as enum ('aguardando_nome', 'ativo', 'bloqueado');
create type public.agendamento_status as enum ('confirmado', 'cancelado', 'concluido', 'faltou');
create type public.agendamento_origem as enum ('cliente_whatsapp', 'portal', 'administrador', 'sistema');
create type public.presenca_status as enum ('nao_aplicavel', 'pendente', 'confirmado', 'recusado');
create type public.excecao_agenda_tipo as enum (
  'bloqueio_manual', 'pausa', 'ferias', 'afastamento', 'feriado',
  'fechamento_excepcional', 'abertura_excepcional'
);
create type public.conversa_modo as enum ('ia', 'humano');
create type public.mensagem_direcao as enum ('entrada', 'saida');
create type public.mensagem_origem as enum ('cliente', 'ia', 'humano', 'automacao', 'sistema');
create type public.mensagem_tipo as enum ('texto', 'audio', 'imagem', 'video', 'documento', 'localizacao', 'contato', 'figurinha', 'outro');
create type public.processamento_status as enum ('recebida', 'pendente', 'processando', 'processada', 'ignorada', 'falhou');
create type public.fila_mensagem_tipo as enum ('lembrete_24h', 'lembrete_2h', 'reativacao', 'retomada_ia');
create type public.fila_mensagem_status as enum ('pendente', 'processando', 'enviado', 'falhou', 'cancelado');
create type public.solicitacao_privacidade_tipo as enum ('acesso', 'correcao', 'anonimizacao', 'exclusao', 'descadastro_reativacao');
create type public.solicitacao_privacidade_status as enum ('recebida', 'em_verificacao', 'concluida', 'recusada');

create table public.operadores_plataforma (
  usuario_id uuid primary key references auth.users(id) on delete cascade,
  nome text not null,
  ativo boolean not null default true,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create table public.planos (
  id uuid primary key default gen_random_uuid(),
  codigo text not null unique,
  nome text not null,
  descricao text,
  limite_profissionais smallint not null check (limite_profissionais > 0),
  valor_mensal numeric(12,2) not null check (valor_mensal >= 0),
  stripe_product_id text unique,
  stripe_price_id_atual text unique,
  ativo boolean not null default true,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  check (codigo = lower(trim(codigo)))
);

create table public.empresas (
  id uuid primary key default gen_random_uuid(),
  codigo text not null unique,
  nome_fantasia text not null,
  razao_social text,
  documento text,
  ramo text,
  email_contato text,
  telefone_contato text,
  whatsapp_numero text not null,
  instancia_evolution text not null unique,
  fuso_horario text not null default 'America/Sao_Paulo',
  status_operacional public.empresa_status not null default 'em_validacao',
  ativado_em timestamptz,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  check (codigo = lower(trim(codigo)))
);

create table public.empresa_configuracoes (
  empresa_id uuid primary key references public.empresas(id) on delete cascade,
  antecedencia_minima_min smallint not null default 60 check (antecedencia_minima_min >= 0),
  antecedencia_cancelamento_min smallint not null default 1440 check (antecedencia_cancelamento_min >= 0),
  buffer_posterior_min smallint not null default 0 check (buffer_posterior_min >= 0),
  limite_agendamentos_diarios smallint check (limite_agendamentos_diarios > 0),
  lembrete_24h_ativo boolean not null default true,
  lembrete_2h_ativo boolean not null default true,
  reativacao_automatica boolean not null default false,
  numero_atendimento_humano text,
  numero_reserva text,
  mensagem_transferencia text,
  janela_envio_inicio time,
  janela_envio_fim time,
  controle_atraso_ativo boolean not null default false,
  tolerancia_atraso_min smallint check (tolerancia_atraso_min >= 0),
  encaixe_ativo boolean not null default false,
  registro_falta_ativo boolean not null default false,
  confirmacao_presenca_ativa boolean not null default false,
  antecedencia_confirmacao_presenca_min smallint check (antecedencia_confirmacao_presenca_min >= 0),
  limite_ia_por_contato_5min smallint not null default 6 check (limite_ia_por_contato_5min > 0),
  limite_ia_por_empresa_min smallint not null default 60 check (limite_ia_por_empresa_min > 0),
  atualizado_em timestamptz not null default now()
);

create table public.assinaturas (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null unique references public.empresas(id) on delete cascade,
  plano_id uuid not null references public.planos(id),
  limite_profissionais_contratado smallint not null check (limite_profissionais_contratado > 0),
  status text not null,
  stripe_customer_id text unique,
  stripe_subscription_id text unique,
  stripe_price_id text,
  stripe_checkout_session_id text unique,
  implantacao_valor numeric(12,2) check (implantacao_valor >= 0),
  implantacao_status text,
  periodo_atual_inicio timestamptz,
  periodo_atual_fim timestamptz,
  cancelar_no_fim_do_periodo boolean not null default false,
  ultimo_pagamento_em timestamptz,
  cancelado_em timestamptz,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create table public.eventos_stripe (
  id uuid primary key default gen_random_uuid(),
  stripe_event_id text not null unique,
  tipo text not null,
  empresa_id uuid references public.empresas(id) on delete set null,
  assinatura_id uuid references public.assinaturas(id) on delete set null,
  estado_processamento public.processamento_status not null default 'recebida',
  payload_reduzido jsonb,
  erro_sanitizado text,
  recebido_em timestamptz not null default now(),
  processado_em timestamptz
);

create table public.profissionais (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  nome text not null,
  telefone text,
  email text,
  cor_agenda text,
  ativo boolean not null default true,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (id, empresa_id)
);

create table public.membros_empresa (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  usuario_id uuid not null references auth.users(id) on delete cascade,
  profissional_id uuid,
  nome_exibicao text not null,
  papel_acesso public.membro_papel not null,
  ativo boolean not null default true,
  ultimo_acesso_em timestamptz,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (empresa_id, usuario_id),
  unique (id, empresa_id),
  foreign key (profissional_id, empresa_id)
    references public.profissionais(id, empresa_id) on delete restrict,
  check (
    (papel_acesso = 'administrador' and profissional_id is null)
    or (papel_acesso = 'profissional' and profissional_id is not null)
  )
);

create table public.servicos (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  nome text not null,
  descricao text,
  duracao_min smallint not null check (duracao_min > 0),
  preco numeric(12,2) not null check (preco >= 0),
  prazo_reativacao_dias smallint check (prazo_reativacao_dias > 0),
  requer_avaliacao boolean not null default false,
  ativo boolean not null default true,
  ordem_exibicao smallint not null default 0,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (id, empresa_id),
  unique (empresa_id, nome)
);

create table public.profissional_servicos (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  profissional_id uuid not null,
  servico_id uuid not null,
  duracao_min_override smallint check (duracao_min_override > 0),
  preco_override numeric(12,2) check (preco_override >= 0),
  ativo boolean not null default true,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (empresa_id, profissional_id, servico_id),
  foreign key (profissional_id, empresa_id)
    references public.profissionais(id, empresa_id) on delete cascade,
  foreign key (servico_id, empresa_id)
    references public.servicos(id, empresa_id) on delete cascade
);

create table public.horarios_empresa (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  dia_semana smallint not null check (dia_semana between 0 and 6),
  inicio time not null,
  fim time not null,
  ativo boolean not null default true,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  check (fim > inicio)
);

create table public.horarios_profissionais (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  profissional_id uuid not null,
  dia_semana smallint not null check (dia_semana between 0 and 6),
  inicio time not null,
  fim time not null,
  ativo boolean not null default true,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  check (fim > inicio),
  foreign key (profissional_id, empresa_id)
    references public.profissionais(id, empresa_id) on delete cascade
);

create table public.excecoes_agenda (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  profissional_id uuid,
  tipo public.excecao_agenda_tipo not null,
  inicio_em timestamptz not null,
  fim_em timestamptz not null,
  bloqueia_agenda boolean not null default true,
  motivo text,
  criado_por_membro_id uuid,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  check (fim_em > inicio_em),
  foreign key (profissional_id, empresa_id)
    references public.profissionais(id, empresa_id) on delete cascade,
  foreign key (criado_por_membro_id, empresa_id)
    references public.membros_empresa(id, empresa_id) on delete set null (criado_por_membro_id)
);

create table public.clientes (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  nome text,
  telefone_e164 text not null,
  whatsapp_jid text,
  email text,
  status_cadastro public.cliente_status not null default 'aguardando_nome',
  aceita_reativacao boolean not null default false,
  consentimento_reativacao_em timestamptz,
  origem_consentimento text,
  descadastro_reativacao_em timestamptz,
  motivo_descadastro text,
  ultimo_contato_em timestamptz,
  revisar_anonimizacao_em timestamptz,
  anonimizado_em timestamptz,
  observacoes_internas text,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (empresa_id, telefone_e164),
  unique (id, empresa_id),
  check (telefone_e164 ~ '^\\+[1-9][0-9]{7,14}$')
);

create table public.agendamentos (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  cliente_id uuid not null,
  profissional_id uuid not null,
  servico_id uuid not null,
  inicio_em timestamptz not null,
  fim_atendimento_em timestamptz not null,
  fim_bloqueio_em timestamptz not null,
  duracao_min smallint not null check (duracao_min > 0),
  preco numeric(12,2) not null check (preco >= 0),
  status public.agendamento_status not null default 'confirmado',
  origem public.agendamento_origem not null,
  observacoes_cliente text,
  observacoes_internas text,
  encaixe boolean not null default false,
  chegada_em timestamptz,
  inicio_real_em timestamptz,
  fim_real_em timestamptz,
  atraso_min smallint check (atraso_min >= 0),
  status_presenca public.presenca_status not null default 'nao_aplicavel',
  presenca_solicitada_em timestamptz,
  presenca_respondida_em timestamptz,
  cancelado_em timestamptz,
  motivo_cancelamento text,
  concluido_em timestamptz,
  faltou_em timestamptz,
  anonimizar_em timestamptz,
  criado_por_membro_id uuid,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (id, empresa_id),
  check (fim_atendimento_em > inicio_em),
  check (fim_bloqueio_em >= fim_atendimento_em),
  foreign key (cliente_id, empresa_id)
    references public.clientes(id, empresa_id) on delete restrict,
  foreign key (profissional_id, empresa_id)
    references public.profissionais(id, empresa_id) on delete restrict,
  foreign key (servico_id, empresa_id)
    references public.servicos(id, empresa_id) on delete restrict,
  foreign key (criado_por_membro_id, empresa_id)
    references public.membros_empresa(id, empresa_id) on delete set null (criado_por_membro_id)
);

create table public.agendamento_eventos (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  agendamento_id uuid not null,
  tipo text not null,
  origem public.agendamento_origem not null,
  ator_tipo text not null,
  membro_empresa_id uuid,
  dados_anteriores jsonb,
  dados_novos jsonb,
  motivo text,
  criado_em timestamptz not null default now(),
  foreign key (agendamento_id, empresa_id)
    references public.agendamentos(id, empresa_id) on delete cascade,
  foreign key (membro_empresa_id, empresa_id)
    references public.membros_empresa(id, empresa_id) on delete set null (membro_empresa_id)
);

create table public.conversas (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  cliente_id uuid not null,
  telefone_e164 text not null,
  modo_atendimento public.conversa_modo not null default 'ia',
  pausado_ate timestamptz,
  assumido_por_membro_id uuid,
  ultima_mensagem_cliente_em timestamptz,
  ultima_mensagem_humana_em timestamptz,
  ultima_mensagem_ia_em timestamptz,
  versao_controle integer not null default 1,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (empresa_id, cliente_id),
  unique (id, empresa_id),
  foreign key (cliente_id, empresa_id)
    references public.clientes(id, empresa_id) on delete restrict,
  foreign key (assumido_por_membro_id, empresa_id)
    references public.membros_empresa(id, empresa_id) on delete set null (assumido_por_membro_id)
);

create table public.mensagens (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  conversa_id uuid not null,
  cliente_id uuid,
  evolution_message_id text,
  direcao public.mensagem_direcao not null,
  origem public.mensagem_origem not null,
  tipo_mensagem public.mensagem_tipo not null,
  conteudo_texto text,
  estado_processamento public.processamento_status not null default 'recebida',
  respondida_por_mensagem_id uuid references public.mensagens(id) on delete set null,
  recebida_em timestamptz not null default now(),
  processada_em timestamptz,
  excluir_em timestamptz,
  erro_sanitizado text,
  metadados jsonb,
  criado_em timestamptz not null default now(),
  foreign key (conversa_id, empresa_id)
    references public.conversas(id, empresa_id) on delete cascade,
  foreign key (cliente_id, empresa_id)
    references public.clientes(id, empresa_id) on delete set null (cliente_id),
  unique (empresa_id, evolution_message_id)
);

create table public.fila_mensagens (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  cliente_id uuid,
  conversa_id uuid,
  agendamento_id uuid,
  tipo public.fila_mensagem_tipo not null,
  chave_idempotencia text not null unique,
  programado_para timestamptz not null,
  estado public.fila_mensagem_status not null default 'pendente',
  tentativas smallint not null default 0 check (tentativas >= 0),
  processando_em timestamptz,
  enviado_em timestamptz,
  cancelado_em timestamptz,
  ultimo_erro text,
  evolution_message_id text,
  conteudo_renderizado text,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  foreign key (cliente_id, empresa_id)
    references public.clientes(id, empresa_id) on delete set null (cliente_id),
  foreign key (conversa_id, empresa_id)
    references public.conversas(id, empresa_id) on delete set null (conversa_id),
  foreign key (agendamento_id, empresa_id)
    references public.agendamentos(id, empresa_id) on delete set null (agendamento_id)
);

create table public.solicitacoes_privacidade (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  cliente_id uuid,
  tipo public.solicitacao_privacidade_tipo not null,
  estado public.solicitacao_privacidade_status not null default 'recebida',
  identificador_solicitante_hash text not null,
  solicitado_em timestamptz not null default now(),
  confirmado_em timestamptz,
  atendido_em timestamptz,
  motivo_recusa text,
  tratado_por_membro_id uuid,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  foreign key (cliente_id, empresa_id)
    references public.clientes(id, empresa_id) on delete set null (cliente_id),
  foreign key (tratado_por_membro_id, empresa_id)
    references public.membros_empresa(id, empresa_id) on delete set null (tratado_por_membro_id)
);

create table public.logs_auditoria (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid references public.empresas(id) on delete set null,
  entidade_tipo text not null,
  entidade_id uuid,
  acao text not null,
  ator_tipo text not null,
  ator_id uuid,
  resultado text not null,
  correlation_id uuid,
  metadados_sanitizados jsonb,
  ocorrido_em timestamptz not null default now()
);

create table public.empresa_conteudos (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  tipo text not null,
  chave text not null,
  titulo text,
  conteudo_texto text,
  conteudo_json jsonb,
  versao integer not null default 1 check (versao > 0),
  ativo boolean not null default true,
  publicado_em timestamptz,
  criado_por_membro_id uuid,
  criado_em timestamptz not null default now(),
  unique (empresa_id, tipo, chave, versao),
  check (conteudo_texto is not null or conteudo_json is not null),
  foreign key (criado_por_membro_id, empresa_id)
    references public.membros_empresa(id, empresa_id) on delete set null (criado_por_membro_id)
);

create or replace function public.definir_atualizado_em()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.atualizado_em = now();
  return new;
end;
$$;

create trigger trg_operadores_plataforma_atualizado before update on public.operadores_plataforma for each row execute function public.definir_atualizado_em();
create trigger trg_planos_atualizado before update on public.planos for each row execute function public.definir_atualizado_em();
create trigger trg_empresas_atualizado before update on public.empresas for each row execute function public.definir_atualizado_em();
create trigger trg_empresa_configuracoes_atualizado before update on public.empresa_configuracoes for each row execute function public.definir_atualizado_em();
create trigger trg_assinaturas_atualizado before update on public.assinaturas for each row execute function public.definir_atualizado_em();
create trigger trg_profissionais_atualizado before update on public.profissionais for each row execute function public.definir_atualizado_em();
create trigger trg_membros_empresa_atualizado before update on public.membros_empresa for each row execute function public.definir_atualizado_em();
create trigger trg_servicos_atualizado before update on public.servicos for each row execute function public.definir_atualizado_em();
create trigger trg_profissional_servicos_atualizado before update on public.profissional_servicos for each row execute function public.definir_atualizado_em();
create trigger trg_horarios_empresa_atualizado before update on public.horarios_empresa for each row execute function public.definir_atualizado_em();
create trigger trg_horarios_profissionais_atualizado before update on public.horarios_profissionais for each row execute function public.definir_atualizado_em();
create trigger trg_excecoes_agenda_atualizado before update on public.excecoes_agenda for each row execute function public.definir_atualizado_em();
create trigger trg_clientes_atualizado before update on public.clientes for each row execute function public.definir_atualizado_em();
create trigger trg_agendamentos_atualizado before update on public.agendamentos for each row execute function public.definir_atualizado_em();
create trigger trg_conversas_atualizado before update on public.conversas for each row execute function public.definir_atualizado_em();
create trigger trg_fila_mensagens_atualizado before update on public.fila_mensagens for each row execute function public.definir_atualizado_em();
create trigger trg_solicitacoes_privacidade_atualizado before update on public.solicitacoes_privacidade for each row execute function public.definir_atualizado_em();
create trigger trg_empresa_conteudos_atualizado before update on public.empresa_conteudos for each row execute function public.definir_atualizado_em();

-- RLS começa habilitado e sem policies: anon/authenticated não acessam nada
-- até a migration específica de permissões. O service role do backend continua
-- destinado apenas às operações controladas de provisionamento e automação.
alter table public.operadores_plataforma enable row level security;
alter table public.planos enable row level security;
alter table public.empresas enable row level security;
alter table public.empresa_configuracoes enable row level security;
alter table public.assinaturas enable row level security;
alter table public.eventos_stripe enable row level security;
alter table public.profissionais enable row level security;
alter table public.membros_empresa enable row level security;
alter table public.servicos enable row level security;
alter table public.profissional_servicos enable row level security;
alter table public.horarios_empresa enable row level security;
alter table public.horarios_profissionais enable row level security;
alter table public.excecoes_agenda enable row level security;
alter table public.clientes enable row level security;
alter table public.agendamentos enable row level security;
alter table public.agendamento_eventos enable row level security;
alter table public.conversas enable row level security;
alter table public.mensagens enable row level security;
alter table public.fila_mensagens enable row level security;
alter table public.solicitacoes_privacidade enable row level security;
alter table public.logs_auditoria enable row level security;
alter table public.empresa_conteudos enable row level security;
