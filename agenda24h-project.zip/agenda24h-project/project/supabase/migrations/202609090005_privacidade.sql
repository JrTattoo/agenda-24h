-- Agenda 24h V2 — migration 005: anonimização efetiva e solicitações LGPD

-- Um cliente anonimizado não mantém identificadores diretos no registro.
alter table public.clientes
  alter column telefone_e164 drop not null;

alter table public.clientes
  drop constraint clientes_telefone_e164_check;

alter table public.clientes
  add constraint clientes_telefone_ou_anonimo_check
  check (
    (anonimizado_em is null and telefone_e164 ~ '^\\+[1-9][0-9]{7,14}$')
    or (anonimizado_em is not null and telefone_e164 is null)
  );

alter table public.conversas
  alter column telefone_e164 drop not null;

create or replace function public.anonimizar_cliente(
  p_empresa_id uuid,
  p_cliente_id uuid,
  p_solicitacao_id uuid,
  p_tratado_por_membro_id uuid default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_solicitacao public.solicitacoes_privacidade%rowtype;
begin
  select * into v_solicitacao
  from public.solicitacoes_privacidade
  where id = p_solicitacao_id
    and empresa_id = p_empresa_id
    and cliente_id = p_cliente_id
  for update;

  if not found then
    raise exception 'Solicitação de privacidade não encontrada';
  end if;

  if v_solicitacao.tipo not in ('anonimizacao', 'exclusao') then
    raise exception 'Tipo de solicitação não permite anonimização';
  end if;

  if v_solicitacao.estado = 'concluida' then
    raise exception 'Solicitação já foi concluída';
  end if;

  update public.fila_mensagens
  set estado = 'cancelado', cancelado_em = now()
  where empresa_id = p_empresa_id
    and cliente_id = p_cliente_id
    and estado in ('pendente', 'processando');

  update public.mensagens
  set conteudo_texto = null,
      evolution_message_id = null,
      metadados = null,
      erro_sanitizado = null
  where empresa_id = p_empresa_id
    and cliente_id = p_cliente_id;

  update public.conversas
  set telefone_e164 = null,
      pausado_ate = null,
      assumido_por_membro_id = null
  where empresa_id = p_empresa_id
    and cliente_id = p_cliente_id;

  update public.agendamentos
  set observacoes_cliente = null,
      observacoes_internas = null
  where empresa_id = p_empresa_id
    and cliente_id = p_cliente_id;

  update public.clientes
  set nome = null,
      telefone_e164 = null,
      whatsapp_jid = null,
      email = null,
      aceita_reativacao = false,
      consentimento_reativacao_em = null,
      origem_consentimento = null,
      descadastro_reativacao_em = now(),
      motivo_descadastro = 'anonimizacao',
      observacoes_internas = null,
      anonimizado_em = now()
  where id = p_cliente_id
    and empresa_id = p_empresa_id
    and anonimizado_em is null;

  update public.solicitacoes_privacidade
  set estado = 'concluida',
      confirmado_em = coalesce(confirmado_em, now()),
      atendido_em = now(),
      tratado_por_membro_id = p_tratado_por_membro_id
  where id = p_solicitacao_id;
end;
$$;

revoke all on function public.anonimizar_cliente(uuid, uuid, uuid, uuid) from public, anon, authenticated;
grant execute on function public.anonimizar_cliente(uuid, uuid, uuid, uuid) to service_role;
