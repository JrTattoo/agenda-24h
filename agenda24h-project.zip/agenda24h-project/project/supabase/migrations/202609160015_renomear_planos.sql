-- Agenda 24h V2 — migration 015: padronização dos nomes e códigos dos planos.
-- Preserva IDs, preços e limites para manter os vínculos existentes.

begin;

update public.planos
set codigo = novos.codigo, nome = novos.nome
from (values
  ('start', 'solo', 'Solo'),
  ('crescimento', 'equipe', 'Equipe'),
  ('pro', 'empresa', 'Empresa')
) as novos(codigo_anterior, codigo, nome)
where planos.codigo in (novos.codigo_anterior, novos.codigo);

commit;
