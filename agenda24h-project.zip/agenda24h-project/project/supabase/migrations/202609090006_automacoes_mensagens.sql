-- Agenda 24h V2 — migration 006: mensagens, handoff e fila de automações

create or replace function public.registrar_mensagem_entrada(
  p_empresa_id uuid,
  p_telefone_e164 text,
  p_evolution_message_id text,
  p_tipo public.mensagem_tipo,
  p_conteudo_texto text default null,
  p_whatsapp_jid text default null,
  p_metadados jsonb default null
)
returns table (
  cliente_id uuid,
  conversa_id uuid,
  mensagem_id uuid,
  duplicada boolean
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_cliente_id uuid;
  v_conversa_id uuid;
  v_mensagem_id uuid;
begin
  if not exists (select 1 from public.empresas where id = p_empresa_id and status_operacional = 'ativo') then
    raise exception 'Empresa não está ativa';
  end if;

  insert into public.clientes (
    empresa_id, telefone_e164, whatsapp_jid, status_cadastro, ultimo_contato_em, revisar_anonimizacao_em
  ) values (
    p_empresa_id, p_telefone_e164, p_whatsapp_jid, 'aguardando_nome', now(), now() + interval '24 months'
  ) on conflict (empresa_id, telefone_e164) do update
    set whatsapp_jid = coalesce(excluded.whatsapp_jid, public.clientes.whatsapp_jid),
        ultimo_contato_em = now(),
        revisar_anonimizacao_em = now() + interval '24 months'
  returning id into v_cliente_id;

  insert into public.conversas (empresa_id, cliente_id, telefone_e164, ultima_mensagem_cliente_em)
  values (p_empresa_id, v_cliente_id, p_telefone_e164, now())
  on conflict (empresa_id, cliente_id) do update
    set telefone_e164 = excluded.telefone_e164,
        ultima_mensagem_cliente_em = now()
  returning id into v_conversa_id;

  insert into public.mensagens (
    empresa_id, conversa_id, cliente_id, evolution_message_id,
    direcao, origem, tipo_mensagem, conteudo_texto, metadados
  ) values (
    p_empresa_id, v_conversa_id, v_cliente_id, p_evolution_message_id,
    'entrada', 'cliente', p_tipo, p_conteudo_texto, p_metadados
  ) on conflict (empresa_id, evolution_message_id) do nothing
  returning id into v_mensagem_id;

  cliente_id := v_cliente_id;
  conversa_id := v_conversa_id;

  if v_mensagem_id is null then
    select id into mensagem_id
    from public.mensagens
    where empresa_id = p_empresa_id and evolution_message_id = p_evolution_message_id;
    duplicada := true;
  else
    mensagem_id := v_mensagem_id;
    duplicada := false;
  end if;

  return next;
end;
$$;

create or replace function public.pausar_conversa_humana(
  p_empresa_id uuid,
  p_cliente_id uuid,
  p_membro_empresa_id uuid,
  p_duracao_min smallint default 30
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_duracao_min <= 0 then
    raise exception 'Duração de pausa inválida';
  end if;

  if not exists (
    select 1 from public.membros_empresa
    where id = p_membro_empresa_id and empresa_id = p_empresa_id and ativo
  ) then
    raise exception 'Membro da empresa inválido';
  end if;

  update public.conversas
  set modo_atendimento = 'humano',
      pausado_ate = now() + make_interval(mins => p_duracao_min),
      assumido_por_membro_id = p_membro_empresa_id,
      ultima_mensagem_humana_em = now()
  where empresa_id = p_empresa_id and cliente_id = p_cliente_id;

  if not found then
    raise exception 'Conversa não encontrada';
  end if;
end;
$$;

create or replace function public.retomar_conversas_pausadas(p_limite integer default 50)
returns table (conversa_id uuid, empresa_id uuid, cliente_id uuid)
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_limite < 1 or p_limite > 200 then
    raise exception 'Limite inválido';
  end if;

  return query
  with candidatas as (
    select c.id
    from public.conversas c
    where c.modo_atendimento = 'humano'
      and c.pausado_ate <= now()
    order by c.pausado_ate
    limit p_limite
    for update skip locked
  )
  update public.conversas c
  set modo_atendimento = 'ia',
      pausado_ate = null,
      assumido_por_membro_id = null
  from candidatas x
  where c.id = x.id
  returning c.id, c.empresa_id, c.cliente_id;
end;
$$;

create or replace function public.reservar_fila_mensagens(p_limite integer default 50)
returns setof public.fila_mensagens
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_limite < 1 or p_limite > 200 then
    raise exception 'Limite inválido';
  end if;

  return query
  with candidatas as (
    select f.id
    from public.fila_mensagens f
    join public.empresas e on e.id = f.empresa_id
    where f.estado = 'pendente'
      and f.programado_para <= now()
      and e.status_operacional = 'ativo'
    order by f.programado_para, f.criado_em
    limit p_limite
    for update skip locked
  )
  update public.fila_mensagens f
  set estado = 'processando',
      processando_em = now(),
      tentativas = tentativas + 1
  from candidatas c
  where f.id = c.id
  returning f.*;
end;
$$;

create or replace function public.marcar_fila_mensagem_enviada(
  p_fila_id uuid,
  p_evolution_message_id text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.fila_mensagens
  set estado = 'enviado',
      enviado_em = now(),
      evolution_message_id = p_evolution_message_id,
      ultimo_erro = null
  where id = p_fila_id and estado = 'processando';

  if not found then
    raise exception 'Mensagem da fila não está em processamento';
  end if;
end;
$$;

create or replace function public.marcar_fila_mensagem_falhou(
  p_fila_id uuid,
  p_erro_sanitizado text,
  p_reagendar_para timestamptz default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.fila_mensagens
  set estado = case when p_reagendar_para is null then 'falhou' else 'pendente' end,
      programado_para = coalesce(p_reagendar_para, programado_para),
      processando_em = null,
      ultimo_erro = p_erro_sanitizado
  where id = p_fila_id and estado = 'processando';

  if not found then
    raise exception 'Mensagem da fila não está em processamento';
  end if;
end;
$$;

create or replace function public.gerar_reativacoes_pendentes(p_limite integer default 200)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_inseridas integer;
begin
  if p_limite < 1 or p_limite > 1000 then
    raise exception 'Limite inválido';
  end if;

  with elegiveis as (
    select a.id as agendamento_id, a.empresa_id, a.cliente_id
    from public.agendamentos a
    join public.servicos s on s.id = a.servico_id and s.empresa_id = a.empresa_id
    join public.clientes c on c.id = a.cliente_id and c.empresa_id = a.empresa_id
    join public.empresas e on e.id = a.empresa_id
    where a.status = 'concluido'
      and a.concluido_em <= now() - make_interval(days => s.prazo_reativacao_dias)
      and s.prazo_reativacao_dias is not null
      and c.aceita_reativacao
      and c.anonimizado_em is null
      and e.status_operacional = 'ativo'
      and not exists (
        select 1 from public.agendamentos futuro
        where futuro.empresa_id = a.empresa_id
          and futuro.cliente_id = a.cliente_id
          and futuro.status = 'confirmado'
          and futuro.inicio_em > now()
      )
      and not exists (
        select 1 from public.fila_mensagens f
        where f.agendamento_id = a.id and f.tipo = 'reativacao'
      )
    order by a.concluido_em
    limit p_limite
  )
  insert into public.fila_mensagens (
    empresa_id, cliente_id, agendamento_id, tipo, chave_idempotencia, programado_para
  )
  select empresa_id, cliente_id, agendamento_id, 'reativacao',
         format('agendamento:%s:reativacao', agendamento_id), now()
  from elegiveis
  on conflict (chave_idempotencia) do nothing;

  get diagnostics v_inseridas = row_count;
  return v_inseridas;
end;
$$;

revoke all on function public.registrar_mensagem_entrada(uuid, text, text, public.mensagem_tipo, text, text, jsonb) from public, anon, authenticated;
revoke all on function public.pausar_conversa_humana(uuid, uuid, uuid, smallint) from public, anon, authenticated;
revoke all on function public.retomar_conversas_pausadas(integer) from public, anon, authenticated;
revoke all on function public.reservar_fila_mensagens(integer) from public, anon, authenticated;
revoke all on function public.marcar_fila_mensagem_enviada(uuid, text) from public, anon, authenticated;
revoke all on function public.marcar_fila_mensagem_falhou(uuid, text, timestamptz) from public, anon, authenticated;
revoke all on function public.gerar_reativacoes_pendentes(integer) from public, anon, authenticated;

grant execute on function public.registrar_mensagem_entrada(uuid, text, text, public.mensagem_tipo, text, text, jsonb) to service_role;
grant execute on function public.pausar_conversa_humana(uuid, uuid, uuid, smallint) to service_role;
grant execute on function public.retomar_conversas_pausadas(integer) to service_role;
grant execute on function public.reservar_fila_mensagens(integer) to service_role;
grant execute on function public.marcar_fila_mensagem_enviada(uuid, text) to service_role;
grant execute on function public.marcar_fila_mensagem_falhou(uuid, text, timestamptz) to service_role;
grant execute on function public.gerar_reativacoes_pendentes(integer) to service_role;
