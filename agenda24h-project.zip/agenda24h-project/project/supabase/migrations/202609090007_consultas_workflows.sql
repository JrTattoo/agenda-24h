-- Agenda 24h V2 — migration 007: consultas controladas dos workflows

create or replace function public.resolver_empresa_por_instancia(p_instancia_evolution text)
returns table (
  empresa_id uuid,
  nome_fantasia text,
  fuso_horario text,
  status_operacional public.empresa_status
)
language sql
security definer
set search_path = public
as $$
  select e.id, e.nome_fantasia, e.fuso_horario, e.status_operacional
  from public.empresas e
  where e.instancia_evolution = p_instancia_evolution;
$$;

create or replace function public.obter_cliente_por_telefone(
  p_empresa_id uuid,
  p_telefone_e164 text
)
returns table (
  cliente_id uuid,
  nome text,
  status_cadastro public.cliente_status,
  aceita_reativacao boolean,
  conversa_id uuid,
  modo_atendimento public.conversa_modo,
  pausado_ate timestamptz
)
language sql
security definer
set search_path = public
as $$
  select c.id, c.nome, c.status_cadastro, c.aceita_reativacao,
         cv.id, cv.modo_atendimento, cv.pausado_ate
  from public.clientes c
  left join public.conversas cv on cv.empresa_id = c.empresa_id and cv.cliente_id = c.id
  where c.empresa_id = p_empresa_id
    and c.telefone_e164 = p_telefone_e164
    and c.anonimizado_em is null;
$$;

create or replace function public.definir_nome_cliente(
  p_empresa_id uuid,
  p_cliente_id uuid,
  p_nome text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if nullif(btrim(p_nome), '') is null then
    raise exception 'Nome inválido';
  end if;

  update public.clientes
  set nome = btrim(p_nome), status_cadastro = 'ativo', ultimo_contato_em = now()
  where id = p_cliente_id
    and empresa_id = p_empresa_id
    and anonimizado_em is null;

  if not found then
    raise exception 'Cliente não encontrado';
  end if;
end;
$$;

create or replace function public.listar_servicos_empresa(p_empresa_id uuid)
returns table (
  servico_id uuid,
  nome text,
  descricao text,
  duracao_min smallint,
  preco numeric(12,2),
  requer_avaliacao boolean
)
language sql
security definer
set search_path = public
as $$
  select s.id, s.nome, s.descricao, s.duracao_min, s.preco, s.requer_avaliacao
  from public.servicos s
  where s.empresa_id = p_empresa_id and s.ativo
  order by s.ordem_exibicao, s.nome;
$$;

create or replace function public.listar_profissionais_servico(
  p_empresa_id uuid,
  p_servico_id uuid
)
returns table (
  profissional_id uuid,
  nome text,
  duracao_min smallint,
  preco numeric(12,2)
)
language sql
security definer
set search_path = public
as $$
  select p.id, p.nome,
         coalesce(ps.duracao_min_override, s.duracao_min),
         coalesce(ps.preco_override, s.preco)
  from public.profissional_servicos ps
  join public.profissionais p on p.id = ps.profissional_id and p.empresa_id = ps.empresa_id
  join public.servicos s on s.id = ps.servico_id and s.empresa_id = ps.empresa_id
  where ps.empresa_id = p_empresa_id
    and ps.servico_id = p_servico_id
    and ps.ativo and p.ativo and s.ativo
  order by p.nome;
$$;

create or replace function public.carregar_contexto_ia(p_empresa_id uuid)
returns jsonb
language sql
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'empresa', jsonb_build_object('nome', e.nome_fantasia, 'ramo', e.ramo, 'fuso_horario', e.fuso_horario),
    'configuracoes', jsonb_build_object(
      'antecedencia_minima_min', c.antecedencia_minima_min,
      'antecedencia_cancelamento_min', c.antecedencia_cancelamento_min,
      'numero_atendimento_humano', c.numero_atendimento_humano,
      'numero_reserva', c.numero_reserva,
      'mensagem_transferencia', c.mensagem_transferencia
    ),
    'conteudos', coalesce((
      select jsonb_agg(jsonb_build_object('tipo', x.tipo, 'chave', x.chave, 'texto', x.conteudo_texto, 'json', x.conteudo_json))
      from public.empresa_conteudos x
      where x.empresa_id = e.id and x.ativo
    ), '[]'::jsonb)
  )
  from public.empresas e
  join public.empresa_configuracoes c on c.empresa_id = e.id
  where e.id = p_empresa_id and e.status_operacional = 'ativo';
$$;

revoke all on function public.resolver_empresa_por_instancia(text) from public, anon, authenticated;
revoke all on function public.obter_cliente_por_telefone(uuid, text) from public, anon, authenticated;
revoke all on function public.definir_nome_cliente(uuid, uuid, text) from public, anon, authenticated;
revoke all on function public.listar_servicos_empresa(uuid) from public, anon, authenticated;
revoke all on function public.listar_profissionais_servico(uuid, uuid) from public, anon, authenticated;
revoke all on function public.carregar_contexto_ia(uuid) from public, anon, authenticated;

grant execute on function public.resolver_empresa_por_instancia(text) to service_role;
grant execute on function public.obter_cliente_por_telefone(uuid, text) to service_role;
grant execute on function public.definir_nome_cliente(uuid, uuid, text) to service_role;
grant execute on function public.listar_servicos_empresa(uuid) to service_role;
grant execute on function public.listar_profissionais_servico(uuid, uuid) to service_role;
grant execute on function public.carregar_contexto_ia(uuid) to service_role;
