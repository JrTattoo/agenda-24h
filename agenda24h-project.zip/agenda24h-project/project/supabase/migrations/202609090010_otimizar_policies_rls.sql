-- Agenda 24h V2 — migration 010: evita reavaliar auth.uid() por linha

drop policy operadores_plataforma_select on public.operadores_plataforma;
create policy operadores_plataforma_select on public.operadores_plataforma
for select to authenticated
using (usuario_id = (select auth.uid()) or public.eh_operador_plataforma());

drop policy planos_select on public.planos;
create policy planos_select on public.planos
for select to authenticated
using (public.eh_operador_plataforma() or exists (
  select 1 from public.membros_empresa m where m.usuario_id = (select auth.uid()) and m.ativo
));

drop policy membros_empresa_select on public.membros_empresa;
create policy membros_empresa_select on public.membros_empresa
for select to authenticated
using (
  public.eh_operador_plataforma()
  or public.eh_administrador_empresa(empresa_id)
  or usuario_id = (select auth.uid())
);
