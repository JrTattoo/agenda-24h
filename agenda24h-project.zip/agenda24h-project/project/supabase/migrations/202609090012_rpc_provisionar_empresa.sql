-- Agenda 24h V2 — migration 012: provisionamento transacional por JSON

create or replace function public.provisionar_empresa_v2(p_payload jsonb)
returns uuid
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_empresa_id uuid;
  v_plano public.planos%rowtype;
  v_item jsonb;
  v_chave text;
  v_id uuid;
  v_profissionais jsonb := '{}'::jsonb;
  v_servicos jsonb := '{}'::jsonb;
  v_quantidade_profissionais integer;
  v_codigo text := lower(btrim(p_payload#>>'{empresa,codigo}'));
  v_plano_codigo text := lower(btrim(p_payload->>'plano_codigo'));
  v_admin_usuario_id uuid;
begin
  if p_payload is null or jsonb_typeof(p_payload) <> 'object' then
    raise exception 'Payload de provisionamento inválido';
  end if;

  if coalesce(v_codigo, '') = '' then
    raise exception 'empresa.codigo é obrigatório';
  end if;

  if coalesce(p_payload#>>'{empresa,nome_fantasia}', '') = ''
    or coalesce(p_payload#>>'{empresa,whatsapp_numero}', '') = ''
    or coalesce(p_payload#>>'{empresa,instancia_evolution}', '') = '' then
    raise exception 'Nome, WhatsApp e instância Evolution são obrigatórios';
  end if;

  select * into v_plano
  from public.planos
  where codigo = v_plano_codigo and ativo;

  if not found then
    raise exception 'Plano inválido ou inativo';
  end if;

  v_quantidade_profissionais := jsonb_array_length(coalesce(p_payload->'profissionais', '[]'::jsonb));
  if v_quantidade_profissionais < 1 or v_quantidade_profissionais > v_plano.limite_profissionais then
    raise exception 'Quantidade de profissionais não permitida pelo plano';
  end if;

  v_admin_usuario_id := nullif(p_payload#>>'{admin,usuario_id}', '')::uuid;
  if v_admin_usuario_id is null or coalesce(p_payload#>>'{admin,nome}', '') = '' then
    raise exception 'admin.usuario_id e admin.nome são obrigatórios';
  end if;

  insert into public.empresas (
    codigo, nome_fantasia, razao_social, documento, ramo, email_contato,
    telefone_contato, whatsapp_numero, instancia_evolution, fuso_horario, status_operacional
  ) values (
    v_codigo,
    btrim(p_payload#>>'{empresa,nome_fantasia}'),
    nullif(btrim(p_payload#>>'{empresa,razao_social}'), ''),
    nullif(btrim(p_payload#>>'{empresa,documento}'), ''),
    nullif(btrim(p_payload#>>'{empresa,ramo}'), ''),
    nullif(lower(btrim(p_payload#>>'{empresa,email_contato}')), ''),
    nullif(btrim(p_payload#>>'{empresa,telefone_contato}'), ''),
    btrim(p_payload#>>'{empresa,whatsapp_numero}'),
    lower(btrim(p_payload#>>'{empresa,instancia_evolution}')),
    coalesce(nullif(btrim(p_payload#>>'{empresa,fuso_horario}'), ''), 'America/Sao_Paulo'),
    'em_validacao'
  ) returning id into v_empresa_id;

  insert into public.empresa_configuracoes (
    empresa_id, antecedencia_minima_min, antecedencia_cancelamento_min,
    buffer_posterior_min, limite_agendamentos_diarios, lembrete_24h_ativo,
    lembrete_2h_ativo, reativacao_automatica, numero_atendimento_humano,
    numero_reserva, numero_notificacao, mensagem_transferencia,
    confirmacao_presenca_ativa, controle_atraso_ativo, encaixe_ativo, registro_falta_ativo
  ) values (
    v_empresa_id,
    coalesce(nullif(p_payload#>>'{configuracoes,antecedencia_minima_min}', '')::smallint, 60),
    coalesce(nullif(p_payload#>>'{configuracoes,antecedencia_cancelamento_min}', '')::smallint, 1440),
    coalesce(nullif(p_payload#>>'{configuracoes,buffer_posterior_min}', '')::smallint, 0),
    nullif(p_payload#>>'{configuracoes,limite_agendamentos_diarios}', '')::smallint,
    coalesce(nullif(p_payload#>>'{configuracoes,lembrete_24h_ativo}', '')::boolean, true),
    coalesce(nullif(p_payload#>>'{configuracoes,lembrete_2h_ativo}', '')::boolean, true),
    coalesce(nullif(p_payload#>>'{configuracoes,reativacao_automatica}', '')::boolean, false),
    nullif(btrim(p_payload#>>'{configuracoes,numero_atendimento_humano}'), ''),
    nullif(btrim(p_payload#>>'{configuracoes,numero_reserva}'), ''),
    nullif(btrim(p_payload#>>'{configuracoes,numero_notificacao}'), ''),
    nullif(btrim(p_payload#>>'{configuracoes,mensagem_transferencia}'), ''),
    false, false, false, false
  );

  insert into public.assinaturas (
    empresa_id, plano_id, limite_profissionais_contratado, status
  ) values (v_empresa_id, v_plano.id, v_plano.limite_profissionais, 'manual');

  insert into public.membros_empresa (empresa_id, usuario_id, nome_exibicao, papel_acesso)
  values (v_empresa_id, v_admin_usuario_id, btrim(p_payload#>>'{admin,nome}'), 'administrador');

  for v_item in select value from jsonb_array_elements(p_payload->'profissionais') loop
    v_chave := nullif(btrim(v_item->>'chave'), '');
    if v_chave is null or coalesce(nullif(btrim(v_item->>'nome'), ''), '') = '' then
      raise exception 'Cada profissional precisa de chave e nome';
    end if;
    if v_profissionais ? v_chave then
      raise exception 'Chave de profissional duplicada: %', v_chave;
    end if;

    v_id := gen_random_uuid();
    insert into public.profissionais (id, empresa_id, nome, telefone, email, cor_agenda, ativo)
    values (
      v_id, v_empresa_id, btrim(v_item->>'nome'),
      nullif(btrim(v_item->>'telefone'), ''), nullif(lower(btrim(v_item->>'email')), ''),
      nullif(btrim(v_item->>'cor_agenda'), ''), coalesce(nullif(v_item->>'ativo', '')::boolean, true)
    );
    v_profissionais := v_profissionais || jsonb_build_object(v_chave, v_id::text);

    if nullif(v_item->>'usuario_id', '') is not null then
      insert into public.membros_empresa (
        empresa_id, usuario_id, profissional_id, nome_exibicao, papel_acesso
      ) values (
        v_empresa_id, (v_item->>'usuario_id')::uuid, v_id, btrim(v_item->>'nome'), 'profissional'
      );
    end if;
  end loop;

  for v_item in select value from jsonb_array_elements(coalesce(p_payload->'servicos', '[]'::jsonb)) loop
    v_chave := nullif(btrim(v_item->>'chave'), '');
    if v_chave is null or coalesce(nullif(btrim(v_item->>'nome'), ''), '') = '' then
      raise exception 'Cada serviço precisa de chave e nome';
    end if;
    if v_servicos ? v_chave then
      raise exception 'Chave de serviço duplicada: %', v_chave;
    end if;

    v_id := gen_random_uuid();
    insert into public.servicos (
      id, empresa_id, nome, descricao, duracao_min, preco,
      prazo_reativacao_dias, requer_avaliacao, ativo, ordem_exibicao
    ) values (
      v_id, v_empresa_id, btrim(v_item->>'nome'), nullif(btrim(v_item->>'descricao'), ''),
      (v_item->>'duracao_min')::smallint, (v_item->>'preco')::numeric,
      nullif(v_item->>'prazo_reativacao_dias', '')::smallint,
      coalesce(nullif(v_item->>'requer_avaliacao', '')::boolean, false),
      coalesce(nullif(v_item->>'ativo', '')::boolean, true),
      coalesce(nullif(v_item->>'ordem_exibicao', '')::smallint, 0)
    );
    v_servicos := v_servicos || jsonb_build_object(v_chave, v_id::text);
  end loop;

  if jsonb_object_length(v_servicos) = 0 then
    raise exception 'É necessário cadastrar ao menos um serviço';
  end if;

  for v_item in select value from jsonb_array_elements(coalesce(p_payload->'profissional_servicos', '[]'::jsonb)) loop
    if not (v_profissionais ? (v_item->>'profissional_chave'))
      or not (v_servicos ? (v_item->>'servico_chave')) then
      raise exception 'Vínculo profissional-serviço contém chave inexistente';
    end if;
    insert into public.profissional_servicos (
      empresa_id, profissional_id, servico_id, duracao_min_override, preco_override, ativo
    ) values (
      v_empresa_id,
      (v_profissionais->>(v_item->>'profissional_chave'))::uuid,
      (v_servicos->>(v_item->>'servico_chave'))::uuid,
      nullif(v_item->>'duracao_min_override', '')::smallint,
      nullif(v_item->>'preco_override', '')::numeric,
      coalesce(nullif(v_item->>'ativo', '')::boolean, true)
    );
  end loop;

  for v_item in select value from jsonb_array_elements(coalesce(p_payload->'horarios_empresa', '[]'::jsonb)) loop
    insert into public.horarios_empresa (empresa_id, dia_semana, inicio, fim, ativo)
    values (
      v_empresa_id, (v_item->>'dia_semana')::smallint,
      (v_item->>'inicio')::time, (v_item->>'fim')::time,
      coalesce(nullif(v_item->>'ativo', '')::boolean, true)
    );
  end loop;

  for v_item in select value from jsonb_array_elements(coalesce(p_payload->'horarios_profissionais', '[]'::jsonb)) loop
    if not (v_profissionais ? (v_item->>'profissional_chave')) then
      raise exception 'Horário de profissional contém chave inexistente';
    end if;
    insert into public.horarios_profissionais (empresa_id, profissional_id, dia_semana, inicio, fim, ativo)
    values (
      v_empresa_id, (v_profissionais->>(v_item->>'profissional_chave'))::uuid,
      (v_item->>'dia_semana')::smallint, (v_item->>'inicio')::time, (v_item->>'fim')::time,
      coalesce(nullif(v_item->>'ativo', '')::boolean, true)
    );
  end loop;

  for v_item in select value from jsonb_array_elements(coalesce(p_payload->'conteudos', '[]'::jsonb)) loop
    insert into public.empresa_conteudos (
      empresa_id, tipo, chave, titulo, conteudo_texto, conteudo_json, ativo, publicado_em
    ) values (
      v_empresa_id, btrim(v_item->>'tipo'), btrim(v_item->>'chave'),
      nullif(btrim(v_item->>'titulo'), ''), nullif(v_item->>'conteudo_texto', ''),
      v_item->'conteudo_json', coalesce(nullif(v_item->>'ativo', '')::boolean, true), now()
    );
  end loop;

  return v_empresa_id;
end;
$$;

revoke all on function public.provisionar_empresa_v2(jsonb) from public, anon, authenticated;
grant execute on function public.provisionar_empresa_v2(jsonb) to service_role;
