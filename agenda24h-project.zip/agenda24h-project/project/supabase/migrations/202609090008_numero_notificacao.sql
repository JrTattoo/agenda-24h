-- Agenda 24h V2 — migration 008: contato de alertas operacionais
-- Não se confunde com o número de atendimento humano nem com o número reserva.

alter table public.empresa_configuracoes
  add column numero_notificacao text;
