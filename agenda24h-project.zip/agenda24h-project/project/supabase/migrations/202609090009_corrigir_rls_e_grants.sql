-- Agenda 24h V2 — migration 009: correção imediata de RLS e privilégios
-- Esta migration corrige a primeira execução, feita antes da versão que
-- habilitava RLS ao final da migration-base.

alter table public.operadores_plataforma enable row level security;
alter table public.planos enable row level security;
alter table public.empresas enable row level security;
alter table public.empresa_configuracoes enable row level security;
alter table public.assinaturas enable row level security;
alter table public.eventos_stripe enable row level security;
alter table public.profissionais enable row level security;
alter table public.membros_empresa enable row level security;
alter table public.servicos enable row level security;
alter table public.profissional_servicos enable row level security;
alter table public.horarios_empresa enable row level security;
alter table public.horarios_profissionais enable row level security;
alter table public.excecoes_agenda enable row level security;
alter table public.clientes enable row level security;
alter table public.agendamentos enable row level security;
alter table public.agendamento_eventos enable row level security;
alter table public.conversas enable row level security;
alter table public.mensagens enable row level security;
alter table public.fila_mensagens enable row level security;
alter table public.solicitacoes_privacidade enable row level security;
alter table public.logs_auditoria enable row level security;
alter table public.empresa_conteudos enable row level security;

-- Nenhuma tabela será consultada diretamente pela API pública nesta fase.
-- Portal e workflows receberão contratos específicos em views/RPCs posteriores.
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;

-- Remove EXECUTE público implícito, inclusive das funções auxiliares de RLS.
-- As RPCs operacionais já possuem GRANT explícito apenas para service_role.
revoke all on all functions in schema public from public, anon, authenticated;

-- Impede que objetos futuros herdem acesso público por acidente.
alter default privileges for role postgres in schema public revoke all on tables from anon, authenticated;
alter default privileges for role postgres in schema public revoke all on sequences from anon, authenticated;
alter default privileges for role postgres in schema public revoke execute on functions from public, anon, authenticated;
