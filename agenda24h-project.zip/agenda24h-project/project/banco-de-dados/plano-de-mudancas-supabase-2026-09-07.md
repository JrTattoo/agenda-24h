# Plano de mudanças do Supabase — 7 de setembro de 2026

## Fonte analisada

Este plano foi produzido a partir do dump `agenda24h-estrutura-supabase.sql`, com 1.108 linhas, extraído do schema `public` em 7 de setembro de 2026.

O arquivo contém somente estrutura. Nenhum registro de cliente foi analisado e nenhuma mudança foi aplicada no servidor.

## Retrato confirmado do banco atual

| Elemento | Quantidade |
|---|---:|
| Tabelas | 11 |
| Views | 4 |
| Funções | 3 |
| Chaves estrangeiras | 17 |
| Índices | 31 |
| Tabelas com RLS habilitado | 11 |
| Policies encontradas | 0 |

Tabelas existentes:

- `contratantes`;
- `profissionais`;
- `servicos`;
- `leads`;
- `agendamentos`;
- `lembretes`;
- `historico_conversas`;
- `perfis`;
- `usuarios_portal`;
- `tabela_sessoes`;
- `tabela_logs`.

O banco já possui chaves estrangeiras entre várias dessas tabelas. Isso substitui a conclusão do inventário anterior que dizia não haver foreign keys.

## Decisão técnica principal

O modelo por IDs existente deve ser preservado e completado. Não se deve recriar `agendamentos.profissional`, `agendamentos.servico`, `profissionais.servicos`, `servicos.preco_min` ou `servicos.preco_max` apenas para acomodar workflows antigos.

As tools devem passar a usar:

- `agendamentos.profissional_id`;
- `agendamentos.servico_id`;
- `servicos.preco`;
- joins com `profissionais` e `servicos` para apresentar nomes.

## Correções críticas antes do salão fictício

### 1. Corrigir as constraints de plano

Existem simultaneamente:

- `contratantes_plano_check`: `Start`, `Crescimento`, `Pro`;
- `contratantes_plano_valido`: `Basico`, `Pro`, `Premium`.

A segunda está marcada `NOT VALID`, mas ainda é aplicada a novas gravações. Na prática, apenas `Pro` pertence às duas listas.

Mudança necessária:

- remover `contratantes_plano_valido` por migração;
- manter a lista oficial `Start`, `Crescimento`, `Pro`;
- validar limite de profissionais: 1, 5 e 15.

### 2. Tornar a instância Evolution única

`contratantes.instancia_evolution` possui índice, mas não constraint única.

Mudança necessária:

- normalizar para minúsculas;
- adicionar unicidade por `instancia_evolution`;
- impedir duas empresas vinculadas à mesma instância.

### 3. Corrigir o vínculo do lead no agendamento

`agendamentos.lead_id` referencia apenas `leads.id`. O banco não garante que o lead tenha a mesma `tag` do agendamento.

Mudança necessária:

- criar unicidade `(id, tag)` em `leads`;
- substituir a FK simples por FK composta `(lead_id, tag)`;
- manter `lead_id` opcional somente se houver um caso real que justifique agendamento sem lead.

### 4. Corrigir o vínculo de lembrete com empresa

`lembretes.agendamento_id` referencia apenas o ID. A `tag` do lembrete pode divergir da `tag` do agendamento.

Mudança necessária:

- criar FK composta `(agendamento_id, tag)`;
- definir comportamento ao cancelar ou excluir um agendamento;
- impedir lembrete pertencente a outra empresa.

### 5. Criar proteção atômica contra sobreposição

O banco possui índices, mas nenhuma constraint ou função que impeça dois compromissos ativos do mesmo profissional no mesmo intervalo.

Mudança necessária:

- armazenar no agendamento o término efetivo e o término do bloqueio;
- `fim_atendimento = data_hora + duração`;
- `fim_bloqueio = fim_atendimento + buffer posterior`;
- criar exclusão de intervalos por profissional para status que ocupam agenda;
- executar criação e remarcação por função transacional/RPC;
- retornar erro de horário ocupado para a tool, sem depender de `SELECT` seguido de `INSERT`.

O buffer deve fazer parte do intervalo apenas depois do atendimento.

### 6. Criar contrato transacional das tools

Funções recomendadas no banco:

- `buscar_horarios_disponiveis(...)`;
- `verificar_disponibilidade(...)`;
- `criar_agendamento(...)`;
- `listar_agendamentos_cliente(...)`;
- `reagendar_agendamento(...)`;
- `cancelar_agendamento(...)`.

Todas devem receber a empresa resolvida a partir de uma fonte confiável, trabalhar com UUIDs e validar novamente os vínculos. A IA não deve montar SQL nem decidir sozinha se o horário é válido.

### 7. Aplicar as regras confirmadas no banco

Na criação:

- antecedência mínima lida de `contratantes.antecedencia_minima_h`;
- empresa, serviço e profissional ativos;
- profissional habilitado para o serviço;
- expediente e dia válidos;
- duração real do serviço;
- limite diário, quando aplicável;
- ausência de bloqueio ou conflito;
- buffer somente posterior.

No cancelamento e reagendamento:

- agendamento pertencente à empresa e ao telefone;
- status que permita alteração;
- pelo menos 24 horas antes do horário original;
- dentro das últimas 24 horas, recusar automaticamente;
- informar à tool o número reserva configurado, quando existir;
- reagendamento altera o mesmo registro e permanece confirmado;
- mensagens programadas antigas são canceladas e recriadas.

### 8. Adicionar o número correto para transferência

`numero_notificacao` parece destinado a alertas operacionais. Ele não deve ser presumido como número de atendimento humano.

Adicionar em `contratantes`:

- `numero_atendimento_humano` ou `numero_reserva`;
- indicador de disponibilidade desse encaminhamento;
- mensagem opcional de transferência.

### 9. Definir estados válidos

Campos sem domínio controlado:

- `agendamentos.status`;
- `leads.etapa`;
- `lembretes.tipo`;
- `historico_conversas.direcao`;
- `historico_conversas.tipo_mensagem`.

Estados mínimos propostos para agendamento:

- `confirmado`;
- `cancelado`;
- `concluido`;
- `faltou`.

Se `agendado` e `confirmado` forem estados diferentes, deve ser definido exatamente quem e como realiza a confirmação. Caso contrário, manter apenas `confirmado` reduz ambiguidade.

### 10. Validar constraints antigas

Há constraints `NOT VALID` para duração, horários, dias e outras regras. Elas protegem novas alterações, mas não garantem que registros antigos sejam válidos.

Mudança necessária:

- auditar linhas incompatíveis sem expor dados pessoais;
- corrigir registros inválidos;
- executar `VALIDATE CONSTRAINT` por migração.

## Relação entre serviços e profissionais

### Problema atual

Cada linha de `servicos` possui um único `profissional_id`. Para dois profissionais executarem “Corte”, é necessário duplicar o serviço. Isso dificulta manter preço, duração, reativação e descrição consistentes.

### Modelo recomendado

Manter `servicos` como catálogo da empresa:

- `id`;
- empresa;
- nome;
- descrição;
- duração;
- preço fixo;
- prazo de reativação;
- ativo.

Criar `profissional_servicos`:

- empresa;
- `profissional_id`;
- `servico_id`;
- ativo;
- duração ou preço específico opcionais apenas se isso for necessário futuramente.

Depois da migração:

- retirar `servicos.profissional_id`;
- tornar o nome do serviço único por empresa, ignorando maiúsculas e espaços laterais;
- validar na reserva que o vínculo profissional–serviço está ativo.

## Agenda, horários e bloqueios

### Tipos de horário

Os horários são armazenados como `text`. Isso permite valores formatados, mas dificulta comparações e validações.

Mudança recomendada:

- migrar horários regulares para o tipo `time`;
- manter `data_hora` dos agendamentos como `timestamptz`;
- sempre usar `contratantes.fuso_horario` nas funções.

### Horário por profissional

O array `dias_trabalho` e um único intervalo diário não representam horários diferentes por dia ou mais de um período no mesmo dia.

Criar `horarios_profissionais`:

- empresa;
- profissional;
- dia da semana;
- início;
- fim;
- ativo.

Essa tabela permite dois intervalos no mesmo dia e resolve pausas de almoço sem regras especiais no prompt.

### Exceções e bloqueios

Criar uma estrutura de exceções, após fechar as regras funcionais, capaz de representar:

- férias;
- afastamento;
- feriado;
- bloqueio manual;
- abertura excepcional;
- fechamento excepcional;
- pausa por data e profissional.

Uma opção é `bloqueios_agenda`, com início, fim, empresa, profissional opcional, tipo, motivo e autor.

## Lembretes e reativação

### Uma única fonte de verdade

Hoje existem flags em `agendamentos` e uma tabela `lembretes`. Isso cria estados duplicados.

Recomendação:

- transformar `lembretes` na fila oficial de mensagens programadas;
- incluir tipos `lembrete_24h`, `lembrete_2h` e `reativacao`;
- controlar estado em `pendente`, `processando`, `enviado`, `falhou` e `cancelado`;
- registrar quantidade de tentativas, último erro, identificador retornado pela Evolution e horário de envio;
- criar chave idempotente única;
- cancelar itens pendentes quando o agendamento for cancelado ou reagendado;
- remover gradualmente as flags duplicadas de `agendamentos` depois da migração.

### Reativação

A elegibilidade deve partir de um atendimento `concluido`, não apenas do último contato do lead.

Adicionar ou registrar:

- agendamento que originou a reativação;
- serviço e prazo aplicados;
- data em que se tornou elegível;
- tentativas;
- resultado;
- descadastro ou bloqueio de contato;
- chave idempotente.

O prazo deve vir de `servicos.prazo_reativacao_semanas` e respeitar `contratantes.reativacao_automatica`.

## Atendimento humano, mensagens e deduplicação

`historico_conversas` guarda conteúdo básico, mas não sustenta a pausa e a retomada exigidas.

### Criar estado de conversa

Criar `conversas` ou ampliar um modelo equivalente com:

- empresa;
- telefone/JID;
- modo `ia` ou `humano`;
- `pausado_ate`;
- última mensagem humana;
- última mensagem do cliente;
- responsável que assumiu;
- versão de controle para evitar duas retomadas.

### Completar o histórico de mensagens

Adicionar a `historico_conversas`:

- ID da mensagem Evolution;
- origem `cliente`, `ia`, `humano` ou `automacao`;
- estado `recebida`, `pendente`, `processando`, `processada`, `ignorada` ou `falhou`;
- `processado_em`;
- erro sanitizado;
- referência à conversa.

Criar unicidade por empresa e ID da mensagem Evolution. Isso impede processar duas vezes o mesmo webhook.

O Redis pode continuar acelerando buffer e memória, mas mensagens pendentes que precisam sobreviver a reinícios não devem existir apenas no Redis.

## Auditoria de agendamentos

Para preservar o mesmo registro ao reagendar e ainda manter histórico, criar `agendamento_eventos`:

- agendamento;
- empresa;
- tipo `criado`, `reagendado`, `cancelado`, `concluido`, `faltou`;
- valores anteriores e novos em JSON controlado;
- origem `cliente_whatsapp`, `portal`, `sistema`;
- usuário responsável;
- data/hora;
- motivo.

Também adicionar ao agendamento, conforme a regra final:

- `cancelado_em`;
- `motivo_cancelamento`;
- `concluido_em`;
- `faltou_em`;
- `origem`.

## Portal e autenticação

### Falhas estruturais confirmadas

- RLS está habilitado nas 11 tabelas, mas não existe nenhuma policy no dump.
- `v_usuarios_portal_login` contém `senha_hash`.
- Existem dois modelos sobrepostos: Supabase Auth com `perfis` e autenticação própria com `usuarios_portal`/`tabela_sessoes`.
- `perfis` possui `id` e `user_id` apontando para `auth.users`.
- O trigger insere `id = NEW.id`, mas `get_meu_perfil()` consulta `user_id = auth.uid()`.
- `criar_perfil_novo_usuario()` tenta atualizar `contratantes.user_id` e `profissionais.user_id`, colunas que não existem no dump.

### Mudança recomendada

Escolher um único sistema. A opção mais segura e simples de manter é Supabase Auth:

- usar `auth.users` para senha, recuperação e sessão;
- manter perfil/empresa/permissão em tabela pública sem senha;
- remover `senha_hash` da view pública;
- retirar gradualmente autenticação própria e sessões próprias;
- criar policies por empresa e profissional;
- administrador vê toda a empresa;
- profissional consulta apenas agendamentos vinculados ao próprio UUID;
- profissional não recebe permissão de alterar agenda.

Até essa migração, o portal deve acessar o banco somente por backend controlado, sempre repetindo empresa e usuário nos filtros finais.

## Cobrança e provisionamento

O banco possui `plano` e `status`, mas não possui estrutura suficiente para acompanhar o Stripe.

Adicionar a `contratantes` ou tabela separada de assinatura:

- `stripe_customer_id`;
- `stripe_subscription_id`;
- `stripe_price_id`;
- estado da assinatura;
- início e fim do período atual;
- cancelamento agendado;
- último pagamento confirmado;
- versão do onboarding;
- versão do workflow aplicado;
- estado do provisionamento.

Criar tabela de eventos Stripe processados com `stripe_event_id` único. Isso evita provisionar ou cobrar duas vezes quando o webhook for reenviado.

O limite de profissionais deve ser verificado por operação controlada, não apenas pelo formulário do n8n.

## Ajustes de qualidade e consistência

- Padronizar telefone em E.164 e armazenar JID separadamente quando necessário.
- Tornar nomes de profissionais únicos por empresa sem diferença de maiúsculas/minúsculas.
- Tornar usuários do portal insensíveis a maiúsculas/minúsculas.
- Remover um dos dois índices únicos redundantes de `leads(tag, telefone)` e `(telefone, tag)` após confirmar os padrões de consulta.
- Remover índices duplicados de `tabela_sessoes.token_hash` após análise de uso.
- Tornar campos booleanos e estados importantes `NOT NULL`.
- Adicionar `atualizado_em` onde houver estado mutável relevante.
- Vincular `tabela_logs` formalmente a empresa e usuário.
- Não armazenar áudio bruto sem prazo e necessidade definidos.

## Mudanças que não devem ser executadas ainda

Dependem de definição do responsável:

- comportamento exato de encaixe;
- estados e processo de confirmação;
- regras de atraso e falta;
- quem registra conclusão e falta;
- desenho final de férias, feriados e bloqueios;
- limite de áudio;
- consentimento e descadastro de reativação;
- retenção e exclusão de dados;
- suspensão por inadimplência.

As tabelas podem ser preparadas de forma flexível, mas as regras finais não devem ser codificadas por suposição.

## Sequência segura de migrações

1. Fazer backup e testar restauração.
2. Levantar contagens e registros que violam constraints, sem extrair dados pessoais.
3. Corrigir a constraint de planos e unicidade da instância.
4. Criar as novas tabelas sem remover colunas antigas.
5. Migrar e validar serviços/profissionais.
6. Criar funções transacionais de agenda e proteção contra conflitos.
7. Migrar lembretes e reativação para a fila oficial.
8. Criar conversa, deduplicação e atendimento humano persistente.
9. Migrar autenticação e policies.
10. Corrigir as tools para o novo contrato.
11. Executar testes ponta a ponta e de concorrência.
12. Somente depois remover estruturas antigas.

## Resultado esperado

Depois dessas mudanças, o Supabase poderá ser a fonte oficial de:

- configuração e personalidade de cada empresa;
- catálogo de serviços e profissionais habilitados;
- disponibilidade e agenda sem sobreposição;
- cancelamento e remarcação com regras verificáveis;
- bloqueios e exceções;
- lembretes e reativação idempotentes;
- estado de atendimento humano;
- permissões do portal;
- cobrança e provisionamento auditáveis.

