# Banco de dados e regras de agendamento

> **Atualização de 7 de setembro de 2026:** o dump completo do schema `public` confirmou 17 chaves estrangeiras e as definições das quatro views. As afirmações abaixo baseadas na coleta anterior que indicam ausência de foreign keys ou views ainda não inspecionadas foram substituídas pelo [plano de mudanças do Supabase](plano-de-mudancas-supabase-2026-09-07.md).

## Finalidade

Este documento registra o estado observado do banco utilizado pelo Agenda 24h e avalia sua capacidade de sustentar múltiplas empresas, profissionais, serviços, agendamentos, lembretes e reativação.

Fonte: inventário coletado localmente em 5 de setembro de 2026, às 20:20 (America/Sao_Paulo), sem consulta ao conteúdo de clientes e sem coleta de credenciais.

Nenhuma alteração descrita aqui deve ser aplicada diretamente em produção. Correções de estrutura precisam de backup verificado, migração versionada, teste com dados de exemplo e plano de reversão.

## Decisão oficial sobre a agenda

**Confirmada em 6 de setembro de 2026:** o Supabase será a fonte única e oficial da agenda do Agenda 24h.

- WhatsApp, IA, workflows do n8n e portal administrativo devem ler e alterar a mesma agenda no Supabase.
- Não haverá integração nem sincronização com Google Calendar, Calendly ou outro sistema externo no MVP.
- Serviços externos não poderão ser tratados como fonte alternativa de disponibilidade.
- Toda criação, alteração, cancelamento, bloqueio e consulta de horário deverá passar pelas regras oficiais do banco.
- A proteção contra conflito de horários deve existir de forma atômica no PostgreSQL, e não depender somente da ordem dos nodes no n8n.
- O portal e a IA não manterão cópias independentes da agenda.

Essa decisão reduz a complexidade do MVP e torna prioritário corrigir a integridade, o isolamento multicliente e a prevenção de sobreposição no banco atual.

## Resumo executivo

O sistema utiliza PostgreSQL 15.8 no Supabase self-hosted. Existem 11 tabelas no schema `public`, quatro views, três funções públicas e dois triggers de atualização.

A estrutura já contempla contratantes, profissionais, serviços, leads, agendamentos, lembretes, conversas e usuários do portal. Entretanto, o banco ainda não garante várias regras fundamentais:

- Não existe nenhuma chave estrangeira.
- Não existe restrição que impeça choque ou duplicidade de horários.
- O isolamento entre empresas é baseado no campo textual `tag`, sem vínculo formal com `contratantes`.
- RLS está ativado em todas as tabelas, mas não foi encontrada nenhuma policy.
- Duas constraints de plano são incompatíveis entre si para novos registros.
- Uma view de login contém `senha_hash`.
- Não foram encontradas tabelas para bloqueios, férias, feriados ou exceções de agenda.
- O estado de lembretes aparece tanto em `agendamentos` quanto em `lembretes`, criando duas possíveis fontes de verdade.

Esses pontos não significam que os workflows atuais necessariamente falham em todos os casos. Significam que a integridade depende fortemente das consultas e da ordem de execução no n8n, em vez de ser protegida pelo banco.

## Plataforma

| Item | Estado confirmado |
|---|---|
| Banco | PostgreSQL 15.8, 64 bits |
| Hospedagem | Supabase self-hosted |
| Timezone da sessão/banco | `America/Sao_Paulo` |
| Schema funcional analisado | `public` |
| RLS | Ativado nas 11 tabelas públicas |
| Policies RLS encontradas | Nenhuma |

Extensões encontradas: `pg_graphql`, `pg_net`, `pg_stat_statements`, `pgcrypto`, `pgjwt`, `plpgsql`, `supabase_vault` e `uuid-ossp`.

## Tabelas existentes

| Tabela | Papel aparente |
|---|---|
| `contratantes` | Empresas atendidas, configurações comerciais, agenda e comportamento da IA |
| `profissionais` | Profissionais vinculados logicamente a uma empresa por `tag` |
| `servicos` | Serviços, duração, preço, reativação e profissional responsável |
| `leads` | Clientes ou potenciais clientes identificados por telefone |
| `agendamentos` | Reservas de horários |
| `lembretes` | Fila ou histórico de mensagens programadas |
| `historico_conversas` | Mensagens trocadas pelo atendimento |
| `usuarios_portal` | Usuários administrativos e profissionais do portal |
| `perfis` | Perfis associados ao sistema de autenticação |
| `tabela_sessoes` | Sessões e tokens do portal |
| `tabela_logs` | Auditoria de ações |

## Relações lógicas esperadas

As relações abaixo são inferidas pelos nomes e índices. Elas não estão implementadas como foreign keys.

| Origem | Campo | Destino esperado | Situação atual |
|---|---|---|---|
| `profissionais` | `tag` | `contratantes.tag` | Somente convenção textual |
| `servicos` | `profissional_id` | `profissionais.id` | Sem foreign key |
| `servicos` | `tag` | `contratantes.tag` | Sem foreign key |
| `leads` | `tag` | `contratantes.tag` | Sem foreign key |
| `agendamentos` | `lead_id` | `leads.id` | Sem foreign key; campo opcional |
| `agendamentos` | `profissional_id` | `profissionais.id` | Sem foreign key |
| `agendamentos` | `servico_id` | `servicos.id` | Sem foreign key |
| `agendamentos` | `tag` | `contratantes.tag` | Sem foreign key |
| `lembretes` | `agendamento_id` | `agendamentos.id` | Sem foreign key; campo opcional |
| `usuarios_portal` | `profissional_id` | `profissionais.id` | Sem foreign key |
| `tabela_sessoes` | `usuario_portal_id` | `usuarios_portal.id` | Sem foreign key |
| `perfis` | `user_id` | `auth.users.id` | Não confirmado |
| `tabela_logs` | `empresa_id` | `contratantes.id` | Sem foreign key e usa chave diferente de `tag` |

Sem essas relações, podem existir agendamentos apontando para profissionais ou serviços apagados, registros de uma empresa ligados logicamente a outra e sessões órfãs.

## Modelo atual de múltiplas empresas

O campo `contratantes.tag` é único e funciona aparentemente como identificador legível da empresa. A mesma `tag` é repetida em praticamente todas as tabelas funcionais.

Esse modelo permite filtros simples no n8n, mas possui fragilidades:

- Uma alteração na `tag` do contratante não se propaga automaticamente.
- Não há garantia de que uma `tag` exista em `contratantes`.
- Não há garantia de que serviço, profissional e agendamento pertençam à mesma `tag`.
- Consultas que esquecerem o filtro por `tag` podem misturar empresas.
- Campos `tag` textuais ocupam índices maiores do que UUIDs.

Recomendação de arquitetura: usar `contratante_id UUID` como relação principal e manter `tag` somente como identificador amigável e único. A migração precisa ser gradual porque os workflows atuais provavelmente dependem de `tag`.

## RLS e controle de acesso

RLS está ativo em todas as tabelas públicas, mas a coleta não encontrou policies em `pg_policies`.

Consequências possíveis:

- Usuários `anon` e `authenticated` normalmente não conseguem acessar as tabelas diretamente enquanto não houver policies aplicáveis.
- Conexões que usam proprietário, acesso direto privilegiado ou `service_role` podem ignorar RLS.
- Se n8n ou o portal usam credencial privilegiada, o isolamento entre empresas pode depender apenas dos filtros escritos pela aplicação.

É necessário confirmar antes de qualquer correção:

- Qual chave ou usuário cada componente usa.
- Grants concedidos às tabelas, views e funções.
- Se as views respeitam o RLS das tabelas subjacentes.
- Se as funções usam `SECURITY DEFINER` ou `SECURITY INVOKER`.
- Como `auth.uid()` é relacionado a `perfis`, `usuarios_portal` e ao contratante.

### Risco específico da view de login

A view `v_usuarios_portal_login` inclui a coluna `senha_hash`. Mesmo um hash não deve ser retornado ao navegador ou a usuários que não precisem realizar a verificação de senha no servidor.

É prioritário inspecionar:

- Definição completa da view.
- Proprietário e grants da view.
- Quem a consulta.
- Se ela é exposta pela API REST do Supabase.
- Se o hash pode ser removido da view e validado somente por função segura no servidor.

Também é necessário entender por que existem `auth.users`, `perfis`, `usuarios_portal`, `senha_hash` próprio e `tabela_sessoes`. Pode haver dois sistemas de autenticação sobrepostos.

## Regras atuais de agenda

### Regras funcionais confirmadas para o modelo oficial

- Antecedência mínima de agendamento: 60 minutos.
- Cancelamento e remarcação: permitidos quando faltarem pelo menos 24 horas.
- Dentro das últimas 24 horas, recusar a operação automática e encaminhar para o número reserva configurado.
- Buffer: configurável por empresa, aplicado somente após o atendimento pelas tools compartilhadas.
- Um serviço poderá ser executado por vários profissionais.
- O cliente deverá escolher um profissional habilitado para o serviço.

Antecedência, prazo de alteração e buffer deverão ser lidos da configuração do contratante e validados na camada transacional. O system prompt poderá explicar as regras, mas não poderá ser a única proteção.

### Empresa/contratante

Foram encontrados campos para:

- Horário de abertura e encerramento.
- Dias de funcionamento.
- Pausa global e horários da pausa.
- Antecedência mínima.
- Limite diário.
- Permissão de encaixe.
- Buffer entre atendimentos.
- Fuso horário.
- Tolerância a atraso.
- Cancelamento e antecedência mínima.
- Confirmação de presença.
- Reagendamento automático.
- Lembretes de 24 horas e 2 horas.
- Reativação automática.

### Profissional

Foram encontrados:

- Dias de trabalho.
- Horário inicial e final.
- Estado ativo.

### Serviço

Foram encontrados:

- Duração em minutos.
- Profissional responsável.
- Preço.
- Necessidade de avaliação.
- Prazo de reativação em semanas.
- Estado ativo.

### Agendamento

Foram encontrados:

- `data_hora` com timezone.
- Duração em minutos.
- Profissional e serviço.
- Lead opcional e telefone obrigatório.
- Status, confirmação e observações.
- Marcadores de envio de lembretes e reativação.

## Lacunas funcionais da agenda

Não foram encontrados elementos estruturais para:

- Bloqueios manuais de horários.
- Férias e afastamentos de profissionais.
- Feriados.
- Horários diferentes por dia da semana.
- Pausas diferentes por profissional ou por dia.
- Exceções de funcionamento em datas específicas.
- Relação muitos-para-muitos entre serviços e profissionais, agora confirmada como necessária.
- Recursos compartilhados, como sala, equipamento ou cadeira.
- Capacidade maior que um atendimento por faixa de horário.
- Registro claro do motivo de cancelamento.
- Histórico de reagendamentos.
- Origem do agendamento e responsável pela alteração.
- Expiração de reservas temporárias durante uma conversa.

Os horários de abertura, encerramento e pausa são armazenados como texto. As constraints verificam apenas o formato `HH:MM`; não garantem, por exemplo, que abertura seja anterior ao encerramento ou que a pausa esteja dentro do expediente.

## Prevenção de conflitos

Não existe constraint `UNIQUE` ou `EXCLUDE` que impeça dois agendamentos ativos e sobrepostos para o mesmo profissional.

O índice atual em `data_hora` melhora buscas, mas não evita concorrência. Uma sequência no n8n do tipo “consultar disponibilidade” e depois “inserir agendamento” pode sofrer condição de corrida: duas conversas podem enxergar o mesmo horário livre e gravá-lo quase simultaneamente.

A solução futura deve ser atômica no banco, considerando:

- `contratante_id` ou `tag`.
- `profissional_id`.
- Início e término do atendimento.
- Status que realmente ocupam agenda.
- Duração do serviço.
- Buffer configurado.
- Política de encaixe.

Antes de escolher a constraint definitiva, é necessário decidir se sobreposição parcial é sempre proibida e como o campo `encaixe` deve funcionar.

## Constraints e inconsistências encontradas

### Planos incompatíveis

Existem duas regras em `contratantes.plano`:

- `contratantes_plano_check`: `Start`, `Crescimento` ou `Pro`.
- `contratantes_plano_valido`: `Basico`, `Pro` ou `Premium`, marcada como `NOT VALID`.

Uma constraint `NOT VALID` deixa de verificar linhas antigas, mas continua sendo aplicada a novas inserções e atualizações. Portanto, a interseção das duas listas é somente `Pro`. Isso pode impedir novos contratantes nos demais planos.

É necessário escolher uma taxonomia oficial e remover a regra obsoleta por migração controlada.

O modelo comercial prevê taxa única de implantação de R$ 300 e mensalidade conforme o plano. A taxonomia comercial oficial agora é `Solo`, `Equipe` e `Empresa`, correspondendo a 1, até 5 e até 15 profissionais. As mensalidades são R$ 99, R$ 149 e R$ 199. A constraint que usa `Basico`, `Pro` e `Premium` é obsoleta e deverá ser removida por migração controlada.

### Constraints não validadas

Várias constraints estão marcadas como `NOT VALID`, inclusive regras de duração, horários, dias, linguagem, objetivos e reativação. Elas protegem registros novos, mas não comprovam que os dados antigos obedecem às regras.

Antes de validá-las, deve-se executar consultas de diagnóstico e corrigir os registros incompatíveis.

### Campos de estado sem domínio controlado

Não apareceu constraint para valores de campos como:

- `agendamentos.status`
- `leads.etapa`
- `lembretes.tipo`
- `historico_conversas.direcao`
- `historico_conversas.tipo_mensagem`

Erros de digitação podem criar estados que os workflows não reconhecem. Os valores oficiais precisam ser levantados nos workflows antes de criar constraints ou tipos enumerados.

### Índices redundantes

Em `leads`, existem duas constraints/índices únicos equivalentes:

- `(tag, telefone)`
- `(telefone, tag)`

Ambos garantem a mesma unicidade. A ordem diferente pode ajudar padrões distintos de busca, mas manter dois índices únicos aumenta custo de escrita. É necessário conferir as consultas antes de remover qualquer um.

## Lembretes e reativação

Existem três mecanismos de estado relacionados a lembrete:

- `agendamentos.lembrete_enviado`
- `agendamentos.lembrete_24h_enviado`
- `agendamentos.lembrete_2h_enviado`
- Registros na tabela `lembretes`, com `enviado` e `enviado_em`

Isso pode provocar divergência, por exemplo, tabela `lembretes` indicando envio enquanto o agendamento continua marcado como não enviado. É necessário definir uma única fonte de verdade e um mecanismo idempotente de envio.

A reativação combina `servicos.prazo_reativacao_semanas`, `contratantes.reativacao_automatica`, `contratantes.mensagem_reativacao`, `agendamentos.reativacao_enviada` e a view `v_reativacao`.

Ainda não aparecem campos ou tabelas para:

- Consentimento e descadastro.
- Motivo de bloqueio de contato.
- Número de tentativas.
- Última tentativa de reativação.
- Resultado da campanha.
- Janela permitida de envio.
- Identificador idempotente da mensagem.

## Views existentes

| View | Finalidade aparente |
|---|---|
| `v_fila_lembretes` | Combina lembretes pendentes e dados do contratante |
| `v_lembretes_amanha` | Lista agendamentos do dia seguinte com profissional e serviço |
| `v_reativacao` | Lista leads elegíveis para reativação |
| `v_usuarios_portal_login` | Reúne dados de autenticação e personalização do portal |

As definições SQL das views não foram coletadas. Sem elas, ainda não é possível validar filtros por empresa, timezone, status, cancelamentos ou duplicidade.

## Funções e triggers

Funções públicas encontradas:

- `criar_perfil_novo_usuario()` — retorna trigger.
- `get_meu_perfil()` — retorna tag, perfil e nome.
- `set_atualizado_em()` — retorna trigger.

Triggers encontrados:

- `trg_agendamentos_atualizado` antes de atualizar `agendamentos`.
- `trg_contratantes_atualizado` antes de atualizar `contratantes`.

Ainda faltam as definições das funções, seus proprietários, permissões, `search_path` e modo de segurança.

Outras tabelas possuem informação que pode mudar, mas não apareceu trigger equivalente de `atualizado_em`. Deve-se decidir onde auditoria e histórico são necessários.

## Índices úteis já existentes

A estrutura possui índices adequados para várias consultas frequentes:

- Agendamentos por data, profissional, serviço, empresa e telefone.
- Lembretes pendentes por data de envio.
- Histórico de conversa por empresa, telefone e data decrescente.
- Leads por empresa e telefone.
- Leads por último contato.
- Profissionais e serviços por empresa.
- Sessões por hash, empresa e usuário.
- Logs por empresa e data.

Para busca de disponibilidade, provavelmente será necessário um índice composto que acompanhe a regra final de conflito, como empresa, profissional, intervalo e status. A decisão depende das consultas reais e de medição com `EXPLAIN`.

## Limitação da coleta de contagens

A seção de contagem não retornou resultados. O script gerou comandos SQL dinamicamente, mas a entrada via heredoc não chegou ao `docker exec`, pois ele foi chamado sem modo interativo de entrada.

Isso não compromete a estrutura coletada, mas deixa desconhecidos:

- Quantidade de registros por tabela.
- Existência de dados órfãos.
- Existência de conflitos de agenda já gravados.
- Linhas antigas que violam constraints `NOT VALID`.

Uma próxima coleta deve executar contagens e diagnósticos sem expor nomes, telefones, mensagens ou outros dados pessoais.

## Prioridades

### Prioridade crítica

1. Verificar grants e exposição de `v_usuarios_portal_login`, especialmente `senha_hash`.
2. Corrigir a incompatibilidade entre as duas constraints de plano.
3. Confirmar como o n8n e o portal acessam o banco diante de RLS ativo sem policies.
4. Impedir de forma atômica agendamentos conflitantes.
5. Auditar registros cruzados ou órfãos antes de adicionar foreign keys.

### Prioridade alta

1. Definir `contratante_id` como vínculo formal de cada registro, preservando `tag` durante a migração.
2. Adicionar foreign keys após limpeza dos dados existentes.
3. Definir a fonte de verdade dos lembretes.
4. Inspecionar definições, privilégios e segurança das views e funções.
5. Criar regras explícitas para status e etapas.
6. Criar modelo de bloqueios, férias, feriados e exceções de agenda.

### Prioridade média

1. Normalizar horários e regras que hoje são textos ou arrays.
2. Resolver campos conceitualmente duplicados, como `linguagem` e `idioma`.
3. Avaliar relação muitos-para-muitos entre serviços e profissionais.
4. Eliminar índices redundantes após medir as consultas.
5. Padronizar atualização e auditoria das tabelas.

## Informações necessárias para concluir o diagnóstico

- Definição SQL completa das quatro views.
- Definição SQL das três funções públicas.
- Grants de tabelas, views, sequences e funções.
- Proprietários e opções de segurança das views/funções.
- Usuário/chave utilizada por n8n e portal, sem revelar o segredo.
- Valores distintos de status, etapas, tipos e planos, somente agregados.
- Contagem de registros por tabela.
- Contagem de órfãos e inconsistências entre `tag`, profissional e serviço.
- Consulta usada pelo workflow para verificar disponibilidade.
- Consulta usada para gravar, reagendar e cancelar.
- Definição completa das views de lembrete e reativação.
- Política funcional para encaixe, buffer e sobreposição.
- Regras de feriados, férias, pausas e horários excepcionais.
- Política de consentimento, retenção e exclusão de dados pessoais.

## Situação do item 6

O inventário estrutural inicial está concluído. A segurança de acesso, a integridade dos vínculos e a prevenção de choque de agenda ainda não podem ser consideradas concluídas. Elas dependem das verificações listadas acima e da análise dos workflows n8n que consultam e alteram essas tabelas.

A comparação com as consultas dos workflows foi registrada em `workflows-n8n/auditoria-agendamentos.md`. Ela confirmou divergência entre as colunas usadas pelos fluxos ativos e o schema atual.
