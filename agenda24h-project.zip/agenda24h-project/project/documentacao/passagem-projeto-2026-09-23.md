# Agenda 24h — passagem de contexto para continuidade

Atualizado em 23/09/2026. Este documento é autocontido para ser levado a outra instância. Ele resume as decisões e as evidências registradas neste workspace; **não é uma auditoria remota realizada hoje**. Onde há somente código, export ou relato anterior, não presumir funcionamento em produção. Não colar senhas, tokens ou chaves nesta passagem.

## O que o produto se propõe a fazer

O Agenda 24h atende pequenos negócios com hora marcada pelo WhatsApp. A IA recebe **texto e áudio** (responde em texto), identifica o cliente, consulta serviços/profissionais/preços/horários reais, agenda após confirmação explícita, consulta reservas, cancela e remarca dentro das regras, e transfere para atendimento humano. **Imagem, vídeo e outras mídias não são suportados; no WF1 linear escolhido pelo proprietário, devem ser ignorados sem resposta.**

A agenda oficial fica no Supabase. O produto inclui lembretes 24 h e 2 h antes, duas reativações distintas (retorno após atendimento concluído e recuperação de quem faltou), pesquisa de satisfação após conclusão e convite neutro para avaliação espontânea no Google. O portal mobile-first atende administrador, profissional e recepcionista, com agenda, gestão, indicadores, relatórios de desempenho, comparecimento/falta e acompanhamento das automações.

A arquitetura decidida é **um workflow principal por empresa** (instância e número Evolution próprios), com tools e automações compartilhadas, dados isolados por empresa no banco V2. O primeiro ambiente de validação é a empresa fictícia `salaoexemplar`; ela não deve ser codificada como regra geral. O provisionamento de novos clientes é manual assistido pelo n8n nesta fase.

## Estado conhecido, sem confundir preparação com implantação

| Frente | O que já existe | O que ainda não está comprovado |
|---|---|---|
| Supabase V2 | Base de empresas, clientes, agenda, fila e contratos de leitura do portal. Migrations 013, 014 e 018 foram registradas como aplicadas em 21/09. A empresa `salaoexemplar` foi encontrada no banco com estado `em_validacao`. | Jornada completa do cliente-teste; estado atual de cada migration deve ser reconferido antes de escrever no banco. |
| Provisionamento | Onboarding, planos Solo/Equipe/Empresa e papel de recepcionista foram incorporados ao processo. | Teste completo falhou na criação dos usuários Auth (retorno nulo); a limpeza posterior deu 401. Convite, e-mail e definição de senha ainda precisam de prova real. |
| WF1 de atendimento | O workflow antigo linear serviu de referência. O arquivo local escolhido é `workflows-n8n/reconstrucao-v3/evento5s/wf1-linear-v3-5s.json`: webhook por mensagem, registro, espera de 5 s, processamento e envio; **sem Schedule Trigger de 10 s**. Só texto/áudio do cliente entram, e imagem/vídeo não recebem resposta. | Arquivo ainda não importado/homologado. O WF1 anteriormente testado pelo proprietário foi despublicado após timeout no nó **Reservar conversa**; o teste era como **cliente tentando agendar**, não como administrador. |
| Tools de agenda | Seis subworkflows V3 locais sobre IDs UUID e contratos do banco V2, mais Guard para nome/transferência. Testes locais com PostgreSQL isolado passaram; uma bateria do pacote V3 registrou 49 testes. | Importação/vínculos no n8n, concorrência com duas conexões reais, comportamento do modelo, áudio e WhatsApp reais. A bateria de 49 testes refere-se ao pacote V3 e não homologa automaticamente o novo WF1 linear. |
| Portal e relatório | Portal React/Vite publicado no GitHub Pages, conectado ao Supabase real para login/leitura; interfaces de agenda, indicadores, relatório e gestão existem. O **papel de recepcionista já aparece no código do portal** (autenticação, navegação e gestão), corrigindo o controle antigo que dizia faltar incluí-lo. | Permissões e ações de escrita ponta a ponta, links Auth, comparecimento, bloqueios e gestão com usuário real. Gestão e comparecimento têm flags desabilitadas por padrão. A migration de gestão 019 ainda é indicada como pré-requisito no README do portal. |
| Comparecimento/falta | Workflow, migration dedicada e integração local do portal preparados; testes locais registrados. | Workflow ativo, migration dedicada aplicada e confirmação com login real **não estão comprovados**. Não confundir a migration de leitura do portal 018 com a migration operacional de comparecimento. |
| Satisfação/Google | Controle registra migrations 020/021 aplicadas após backup, funções/RLS conferidas e dois workflows importados no n8n, ainda inativos. | Trocar no dispatcher a credencial HTTP indevida `Supabase ANON - Portal Comparecimento` por credencial Evolution própria; validar Postgres; integrar resposta da pesquisa ao WF1 e testar geração, envio, resposta, expiração, descadastro, convite e indicadores. A nota não pode condicionar o convite Google. |
| Lembretes e reativação | Regras e estruturas de fila estão documentadas. Em 23/09 foram preparados dois **novos exports locais inativos** em `workflows-n8n/automacoes-v2/json/`, adaptando os exports antigos à fila V2; testes isolados de SQL/estrutura passaram. A revisão preservou as referências `Postgres account` e `Header Auth account` dos exports fornecidos, sem criar credenciais. | Inventário dos consumidores ativos, importação e verificação **das credenciais existentes** e testes reais no n8n/Evolution. O mesmo `Header Auth account` aparecia nos nós Evolution e Groq antigos: verificar a qual API pertence antes de ativar. A recuperação de faltosos é uma segunda reativação, ainda não implementada/homologada. |

## Bloqueio técnico imediato do WF1

Em 22/09, consultas **somente de leitura** no Supabase mostraram que `a24_v3_reservar`, o esquema `atendimento_v3` e o papel `agenda24h_atendimento` ainda não existiam. As migrations locais `workflows-n8n/reconstrucao-v3/migration-atendimento-v3.sql` e `evento5s/migration-webhook-evento5s.sql` **não foram aplicadas por esta conversa**. Elas precisam de backup, preflight, revisão de compatibilidade com funções remotas e homologação antes de aplicação; a primeira também altera proteção compartilhada da agenda. Não aplicá-las às cegas.

A conexão PostgreSQL antiga usada no WF1 apontava para endereço inacessível e era compartilhada com outros 15 workflows. Foi iniciada uma credencial **exclusiva** `Postgres - Agenda24h Atendimento V3`, mas não foi salva/concluída porque o papel não existia e o proprietário não tinha a senha. Nenhuma senha deve ser pedida ou registrada no chat; definir diretamente por canal seguro e testar no n8n. O JSON linear novo deixou credenciais Postgres e Header Auth sem associação para impedir reuso acidental. Selecionar autenticação própria da Evolution para os nós HTTP e um segredo separado para o webhook de entrada. Não usar a chave `anon` do portal nem a `service_role` de provisionamento nesses nós. O webhook da Evolution **não foi alterado** nesta etapa.

## Próxima sequência recomendada

1. Fazer inventário de **quais versões dos workflows estão realmente ativas** no n8n e salvar exports/backup antes de trocar qualquer rota.
2. Revisar o banco remoto em modo leitura; confirmar backup e compatibilidade das migrations V3. Aplicar e verificar em homologação, criar o papel/credencial exclusiva e testar conectividade — somente após autorização do proprietário.
3. Importar o WF1 linear **inativo**, ligar as tools corretas, credenciais e instância `salaoexemplar`; testar webhook de homologação antes de apontar a Evolution. Não manter dois WF1 respondendo pelo mesmo número.
4. Testar WF1 como cliente: texto único, mensagens separadas por menos/mais de 5 s, áudio real, mídia ignorada, nome, catálogo, disponibilidade, agendar, confirmar, cancelar, remarcar, intervenção humana, retomada, falhas de banco/IA/envio e ausência de respostas duplicadas. Testar também isolamento entre empresas e duas reservas concorrentes.
5. Adaptar e testar os **workflows de lembrete** 24 h/2 h: fila V2, alteração/cancelamento de horário, idempotência, falhas e envio único.
6. Adaptar e testar as **duas reativações** separadamente: prazo de retorno após atendimento concluído e convite ao reagendamento após falta. Não disparar se já existir novo agendamento aplicável; registrar resultado e descadastro.
7. Conectar e homologar comparecimento, pesquisa/Google, portal/relatório e provisionamento real, inclusive permissões de recepcionista e envio dos links Auth. Executar a bateria ponta a ponta antes de considerar o produto pronto.

**Resumo da prioridade:** a percepção de que “faltam só WF1, lembretes e reativação” é razoável para iniciar o **teste da jornada de atendimento**, mas não prova que o **produto completo** esteja pronto. Comparecimento, pesquisa, portal e provisionamento ainda têm pendências de integração/homologação. Não marcar uma frente como concluída apenas porque há arquivos ou testes locais.

## Decisões que a próxima instância não deve inverter

- Não substituir o WF1 linear por consumidor periódico de 10 s. Cada mensagem recebida deve disparar sua própria execução; a consolidação normal é de 5 s.
- Somente texto e áudio entram no atendimento; imagem/vídeo não são analisados nem respondidos no WF1 escolhido, embora documentos antigos ainda descrevam uma mensagem orientativa.
- Não misturar credenciais: `anon` do portal, `service_role` de provisionamento, Postgres de comparecimento, Postgres de gestão, Postgres de atendimento e Evolution têm finalidades diferentes.
- Não assumir que migration local foi aplicada ou que workflow importado foi ativado. Confirmar no ambiente real, com leitura antes de qualquer escrita.
- O convite Google é neutro e independente da nota; o sistema mede convites enviados, não avaliações publicadas.

## Arquivos de referência

- Produto: `documentacao/visao-do-produto.md` e `documentacao/funcionalidades-do-sistema.md`.
- Controle detalhado anterior: `documentacao/controle-progresso-v2.md` (parte dele está desatualizada, especialmente recepcionista no portal).
- WF1 linear: `workflows-n8n/reconstrucao-v3/evento5s/README.md` e `COMPARACAO-LEGADO-V3.md` na mesma pasta.
- Pacote V3/tools e testes: `workflows-n8n/reconstrucao-v3/README.md` e `VALIDACAO-WF1-20260922.md`.
- Portal: `portal-web/README.md`; satisfação: `workflows-n8n/satisfacao/README.md`; comparecimento: `workflows-n8n/comparecimento/README.md`.

## Como continuar com segurança

Na outra instância, começar por ler este arquivo e os arquivos de referência, conferir o ambiente real em modo leitura e atualizar a tabela de estados com evidências. Esta passagem não autoriza aplicar SQL, alterar credenciais, ativar workflows ou mudar o webhook de produção automaticamente.
