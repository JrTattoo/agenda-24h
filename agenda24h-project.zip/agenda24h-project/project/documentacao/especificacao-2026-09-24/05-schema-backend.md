# Schema do backend — mapa lógico e contratos

Versão de trabalho: 24/09/2026. Este documento **descreve** o modelo V2 e as extensões registradas; não é uma migration executável nem atesta que cada objeto está presente no servidor neste momento. A fonte exata de DDL está em `supabase/migrations/`; o inventário de tabelas enviado pelo proprietário em 23/09 foi usado como referência adicional. Antes de qualquer escrita, executar preflight de leitura no banco real.

## 1. Núcleo relacional

| Domínio | Tabelas | Chaves e relações principais |
|---|---|---|
| Tenant/comercial | `empresas`, `empresa_configuracoes`, `planos`, `assinaturas`, `eventos_stripe` | `empresas.id` é a chave de isolamento; `instancia_evolution` é única. Configuração e assinatura vinculam-se à empresa. Plano define limites; assinatura guarda snapshot contratado. |
| Equipe/catálogo | `membros_empresa`, `profissionais`, `servicos`, `profissional_servicos`, `horarios_empresa`, `horarios_profissionais`, `excecoes_agenda`, `empresa_conteudos` | `membros_empresa.usuario_id` → `auth.users`; papel e vínculo profissional. Relação N:N entre profissionais e serviços, com duração/preço override. Horários e exceções são escopados por empresa. |
| Cliente/agenda | `clientes`, `agendamentos`, `agendamento_eventos` | Agendamento vincula empresa, cliente, profissional e serviço por UUID; guarda início, fins, duração, preço, status e origem. Evento registra transição/auditoria. |
| Conversa/mensagens | `conversas`, `mensagens`, `fila_mensagens` | Conversa e mensagem vinculam empresa/cliente; `evolution_message_id` deduplica por empresa. Fila pode apontar para cliente, conversa e agendamento; `chave_idempotencia` é única. |
| Pós-atendimento | `pesquisa_satisfacao_configuracoes`, `pesquisas_satisfacao`, `pesquisa_satisfacao_interacoes` | Configuração por empresa; pesquisa por atendimento; interações relacionam mensagem e pesquisa. Preferências ficam em `clientes`. |
| Portal/privacidade | `relatorios_semanais_empresa`, `solicitacoes_privacidade`, `logs_auditoria`, `operadores_plataforma` | Relatórios semanais por empresa/período; trilhas de alteração e solicitações de titular. |

As FKs compostas `(id, empresa_id)` nas entidades operacionais evitam associação entre empresas. RLS, grants e RPCs devem reforçar, não substituir, essas relações.

## 2. Campos-chave para os workflows

### Empresas e configuração

`empresas(id uuid, codigo text unique, nome_fantasia text, whatsapp_numero text, instancia_evolution text unique, fuso_horario text, status_operacional empresa_status, ...)`.

`empresa_configuracoes(empresa_id uuid PK, antecedencia_minima_min, antecedencia_cancelamento_min, antecedencia_reagendamento_min, buffer_posterior_min, limite_agendamentos_diarios, lembrete_24h_ativo, lembrete_2h_ativo, reativacao_automatica, janela_envio_inicio/fim, numero_reserva, numero_notificacao, limites de IA, regras de falta/atraso, ...)`. A existência das colunas mais recentes deve ser conferida contra migrations instaladas.

### Agenda e cliente

`clientes(id, empresa_id, nome, telefone_e164, whatsapp_jid, status_cadastro, aceita_reativacao, aceita_pesquisa_satisfacao, aceita_convite_google, anonimizado_em, ...)`.

`servicos(id, empresa_id, nome, duracao_min, preco, prazo_reativacao_dias, ativo, ...)`; `profissional_servicos` pode sobrescrever duração/preço por profissional.

`agendamentos(id, empresa_id, cliente_id, profissional_id, servico_id, inicio_em, fim_atendimento_em, fim_bloqueio_em, duracao_min, preco, status, origem, status_presenca, concluido_em, faltou_em, cancelado_em, ...)`. A constraint `agendamentos_sem_sobreposicao_profissional` protege reservas confirmadas do mesmo profissional no intervalo. Conclusão/falta não devem ser inferidas do simples término do horário.

### Fila e pesquisa

`fila_mensagens(id, empresa_id, cliente_id?, conversa_id?, agendamento_id?, tipo, chave_idempotencia unique, programado_para, estado, tentativas, processando_em, enviado_em, cancelado_em, ultimo_erro, evolution_message_id, conteudo_renderizado, pesquisa_id?, contexto jsonb, ...)`.

`pesquisas_satisfacao(id, empresa_id, cliente_id, agendamento_id, estado, programada_para, enviada_em, expira_em, nota?, respondida_em?, comentario?, ...)`. `pesquisa_satisfacao_configuracoes` guarda habilitação, escala, atraso/frequência e parâmetros/link Google por empresa.

## 3. Estados e funções existentes no código do projeto

- Enums-base: `empresa_status` (`em_validacao`, `ativo`, `suspenso`, `cancelado`, `falhou`); `agendamento_status` (`confirmado`, `cancelado`, `concluido`, `faltou`); `fila_mensagem_status` (`pendente`, `processando`, `enviado`, `falhou`, `cancelado`). A enumeração de tipos de fila começou com `lembrete_24h`, `lembrete_2h`, `reativacao`, `retomada_ia`; migrations posteriores ampliam-na para satisfação. `membro_papel` começou com administrador/profissional e foi estendido para recepcionista; conferir enum remoto.
- Agenda: `verificar_disponibilidade`, `buscar_horarios_disponiveis`, `criar_agendamento`, `cancelar_agendamento`, `reagendar_agendamento`, `programar_lembretes_agendamento`, `listar_agendamentos_cliente`.
- Atendimento: `registrar_mensagem_entrada`, funções de consulta de empresa/cliente/catálogo/contexto, pausa/retomada humana; pacote V3 local adiciona `a24_v3_*` e schema `atendimento_v3`, **não aplicado na última checagem**.
- Fila: `reservar_fila_mensagens`, `marcar_fila_mensagem_enviada`, `marcar_fila_mensagem_falhou`, `gerar_reativacoes_pendentes`. O consumidor genérico reserva tipos indiscriminadamente: não executá-lo em paralelo com consumidores dedicados dos mesmos tipos.
- Portal: contratos de leitura/autorização das migrations 013/014/018; comparecimento e gestão têm operações/migrations próprias cuja implantação precisa de verificação.
- Pesquisa: migrations 016 e 020/021 adicionam tabelas, enum, funções e fila; 020/021 constam como aplicadas em controle anterior, mas a operação ponta a ponta permanece não homologada.

## 4. Lacunas de schema/contrato antes do produto completo

1. **Reativação por falta:** falta uma representação inequívoca da modalidade na fila e regra de elegibilidade/configuração. Pode ser novo tipo ou `contexto` versionado, após decisão; não reutilizar indistintamente o indicador `reativacao` atual.
2. **Atribuição de conversão:** falta vínculo persistido e verificável entre envio de reativação e agendamento gerado. O relatório antigo baseado em proximidade temporal não satisfaz a decisão de produto.
3. **Gestão administrativa:** há conflito de processo (aprovação manual × execução por webhook); escolher contrato antes de criar/alterar tabelas ou permissões.
4. **Comparecimento:** verificar instalação da migration operacional e grants reais; a migration de leitura do portal não é suficiente.
5. **Papel de recepcionista:** conferir enum, vínculos, RLS/RPCs e permissões de UI com usuário real.

## 5. Segurança e evolução

Migrations devem ser versionadas, pré-verificadas e aplicadas com backup testável. Credenciais internas ficam no n8n/servidor, não no frontend ou JSON exportado. Toda função `SECURITY DEFINER` precisa de `search_path` controlado, grants mínimos e teste de isolamento. Não alterar tabelas existentes para “acomodar” um workflow legado sem antes adaptar o workflow ao contrato V2.

Referências: `supabase/migrations/202609090001_base_v2.sql`, `202609090002_integridade_agenda.sql`, `202609090003_funcoes_agenda.sql`, `202609090006_automacoes_mensagens.sql`, `202609090007_consultas_workflows.sql`, `202609230021_pesquisa_satisfacao_operacao.sql` e [passagem de contexto](../passagem-projeto-2026-09-23.md).
