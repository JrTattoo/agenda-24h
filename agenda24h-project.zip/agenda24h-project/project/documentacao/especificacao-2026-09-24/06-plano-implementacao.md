# Plano de implementação — Agenda 24h

Versão de trabalho: 24/09/2026. O plano ordena dependências; não pressupõe acesso/autorização para aplicar SQL, alterar credenciais, importar ou ativar workflows. Cada etapa termina com evidência observável, não apenas arquivo criado.

## 1. Regra de execução

Antes de qualquer alteração no ambiente real: inventário de workflows ativos, export de segurança, leitura do schema/funções atuais, backup com restauração ensaiada e plano de retorno do webhook. Nenhuma credencial deve ser inventada nos JSONs; usar a credencial real da API correspondente, conferida no n8n. Nunca colocar chave global Evolution, `service_role` ou senha de banco em documentação/chat.

## 2. Sequência crítica para testar a jornada real

| Ordem | Entrega | Dependência e trabalho | Evidência para avançar |
|---:|---|---|---|
| 0 | Congelar ponto de partida | Inventariar exports/ativação dos WF1, Guard, tools, consumidores de fila e credenciais; confirmar status da empresa `salaoexemplar` e backup. | Lista datada do ambiente; nenhum duplo consumidor/webhook. |
| 1 | Destravar banco do WF1 | Executar preflight **somente leitura**; comparar funções V2 remotas com migrations locais; revisar efeitos compartilhados da migration V3; aplicar em homologação com backup; verificar `a24_v3_*` e papel necessário. | Funções/papel presentes e teste de conexão PostgreSQL pelo n8n, sem timeout. |
| 2 | WF1 linear de homologação | Importar `wf1-linear-v3-5s.json` inativo; ligar instância, Postgres, OpenAI, Evolution e tools certas; testar webhook de homologação; trocar URL da Evolution apenas após aprovação. | Mensagem de texto de cliente chega e recebe **uma** resposta; duas mensagens em <5 s consolidam; áudio funciona; imagem/vídeo não recebem resposta. |
| 3 | Jornada de agenda | Testar nome, catálogo, disponibilidade, confirmação, agendamento real do cliente-teste, consulta, remarcação, cancelamento e concorrência. | Reserva correta no Supabase; nenhuma duplicata/conflito; isolamento entre duas empresas de teste. |
| 4 | Lembretes V2 | Conferir/criar itens de fila da reserva real, consumidores existentes e credencial `apikey` Evolution do serviço; importar novo fluxo inativo; homologar 24 h/2 h e alteração/cancelamento. | Um envio por item elegível e ID aceito; timeout/reconciliação sem reenvio cego. |
| 5 | Resultado e reativação 1 | Homologar registro protegido de concluído/faltou; depois testar reativação pós-atendimento por prazo de serviço e descadastro. | Conclusão real cria elegibilidade apenas quando devida; novo agendamento bloqueia contato indevido. |
| 6 | Reativação 2 | Definir prazo e modelo de fila de faltosos; implementar workflow separado e atribuição de reagendamento. | Falta gera no máximo um convite elegível; métricas separadas. |
| 7 | Satisfação e Google | Corrigir credencial HTTP do dispatcher, conectar captura de resposta ao WF1, habilitar configuração/consentimento de teste e testar expiração/descadastro. | Pesquisa e convite neutro enviados apenas quando elegíveis; painel reflete eventos verdadeiros. |
| 8 | Portal/gestão/relatório | Testar login/convites, comparecimento, recepcionista, bloqueios e gestão segundo decisão aprovada; ajustar vínculo explícito de reativação e relatório. | Cada perfil vê/executa só o permitido; semanal e indicadores conciliam com dados de origem. |
| 9 | Provisionamento e lançamento | Corrigir criação Auth nula e limpeza 401; provisionar segunda empresa fictícia; ensaiar falhas/backup/restauração, capacidade inicial e operação diária. | Jornada completa repetível sem configuração especial para salão-teste; aprovação do proprietário. |

**Prioridade imediata:** etapas 0–3. Lembretes e reativação têm exports V2 locais, mas não podem ser validados de ponta a ponta sem o WF1 criar um agendamento pela jornada do cliente. Não fabricar reservas em produção como substituto desse teste.

## 3. Bateria mínima de homologação

1. Entradas: texto, áudio real, duas mensagens em 5 s, evento duplicado, outro número/empresa, imagem/vídeo ignorados, mensagem manual da equipe.
2. Agenda: agendar após confirmação, negar sem confirmação, horário ocupado, concorrência, buffer, antecedência, serviço/profissional inválido, cancelamento/remarcação no limite de 24 h.
3. Falhas: banco indisponível, OpenAI indisponível, Evolution timeout/2xx sem ID, execução n8n interrompida, reinício durante espera, item de fila preso em `processando`.
4. Portal: admin, profissional, recepcionista, sem vínculo e outra empresa; convite/recuperação Auth; operação antes do horário; bloqueio com reserva conflitante; relatório sem dados.
5. Pós-atendimento: concluído, faltou, ausência de registro, consentimentos, descadastros, nova reserva, pesquisa ambígua, convite Google independente da nota.

Registrar para cada caso: pré-condição, ID de execução sanitizado, resultado esperado/obtido, estado de banco antes/depois e decisão. Não registrar conteúdo pessoal ou segredo em evidências.

## 4. Critérios de bloqueio e retorno

- Migration remota divergente, backup ausente, permissão incerta, credencial com função errada ou empresa ainda em validação: **não publicar**.
- Dois WF1 apontados ao mesmo número ou consumidor genérico disputando a fila: **não publicar**.
- HTTP de envio ambíguo: manter estado para conciliação; não fazer retry automático.
- Para voltar atrás em homologação, desativar workflow novo e restaurar rota anterior do webhook após conferência; não apagar dados/schema automaticamente.
- Marcar “concluído” somente após prova integrada correspondente. A meta de 50 empresas requer testes progressivos de capacidade, não é certificada pelo primeiro cliente-teste.

## 5. Pendências de decisão antes das etapas posteriores

Fluxo de gestão de equipe (aprovação manual ou escrita direta protegida), permissões exatas da recepcionista, regra da reativação de faltosos, vínculo de conversão, hospedagem comercial do portal e política de retenção/conciliação da fila. Resolver cada uma no PRD/TRD antes de implementar sua etapa.
