# Briefing de design UI/UX — portal Agenda 24h

Versão de trabalho: 24/09/2026. Este briefing orienta o **portal já existente**, não propõe refazê-lo nem muda a identidade visual sem aprovação. O sistema de design atual usa azul, Inter, Tailwind e componentes React; preservar essa base. A consulta ao guia UI/UX favoreceu profundidade sutil, contraste, feedback claro, navegação por teclado e gráficos simples. A paleta rosa sugerida pelo guia para negócios de beleza **não foi adotada**, pois o produto é multissetorial e o portal atual já tem tokens azuis.

## 1. Objetivo da experiência

O usuário deve saber, em poucos segundos: “O que está agendado?”, “O que exige minha ação?” e “O que o sistema entregou?”. O portal é operacional, mobile-first e confiável; não deve parecer um painel de demonstração com números inventados. O tom é claro e direto, sem jargão de n8n/Supabase na interface do cliente.

## 2. Públicos e tarefas principais

| Perfil | Primeira tela útil | Tarefa prioritária |
|---|---|---|
| Administrador | Visão geral ou agenda do dia | Conferir agenda da equipe, pendências/falhas, concluídos/faltas, resultados semanais. |
| Profissional | Própria agenda do dia | Ver atendimento e registrar concluído/faltou, quando autorizado. |
| Recepcionista | Agenda autorizada | Localizar atendimento e apoiar operação nos limites definidos para o papel. |
| Operador da plataforma | Fora do portal do cliente, conforme fluxo interno | Revisar onboarding, alterações e incidentes sem expor controles internos ao cliente. |

## 3. Arquitetura de informação

- Acesso: login, recuperar senha, definir senha no primeiro acesso, redefinir senha.
- Operação diária: agenda → dia/filtro → cartão → detalhe → ação permitida → confirmação → resultado.
- Administração: visão geral, automações, relatórios, gestão de equipe/serviços. Ausências e fechamentos precisam de tela/fluxo antes do lançamento comercial, mesmo que ainda não existam nas rotas atuais.
- Navegação por papel: ocultar atalhos não autorizados **e** negar acesso à rota/contrato no servidor; esconder não é autorização.
- No celular, priorizar agenda e ação corrente; evitar tabelas largas. Filtros devem caber em 375 px ou abrir painel acessível. O botão voltar do navegador deve preservar contexto de data/filtro.

## 4. Linguagem visual existente a consolidar

| Elemento | Direção |
|---|---|
| Cor principal | Azul do portal (`primary-600` `#2563eb`), neutros claros; verde/sucesso, âmbar/atenção e vermelho/erro conforme tokens atuais. Não depender só de cor. |
| Tipografia | Inter, hierarquia nítida: título da página, subtítulo de contexto, valores com unidade e período, rótulos legíveis. |
| Superfícies | Cartões com borda visível e sombra discreta; evitar efeito que prejudique contraste. Espaçamento consistente e leitura rápida. |
| Ícones | Lucide já usado no projeto; tamanho consistente, sempre com texto/aria-label quando ação não for óbvia. Sem emojis como ícones de UI. |
| Movimento | Transições curtas de cor/estado; sem deslocamento de layout. Respeitar `prefers-reduced-motion`. |

## 5. Componentes e estados obrigatórios

- Agenda: seletor de data, filtro de profissional (admin), cartões com hora, serviço, profissional e estado; detalhe com dados permitidos ao perfil. Mostrar fuso quando relevante.
- Resultado do atendimento: “Atendimento concluído” e “Cliente faltou” com confirmação explícita, usuário, horário e retorno real do servidor. Antes de `inicio_em`, ação indisponível com motivo compreensível.
- Bloqueios: prévia de conflitos mostrando reserva, cliente/telefone autorizado, profissional e serviço; escolha “manter” ou “cancelar” por reserva, com confirmação. Não cancelar em massa por abrir o diálogo.
- Automações: distinguir programada, processando, enviada/aceita, falha e pendente de revisão. Timeout não pode aparecer como “não enviado” confirmado.
- Dados: estados de carregamento (>300 ms), vazio, erro, acesso negado, sessão expirada e operação incerta. Não preencher ausência de dados com exemplos.
- Formulários: rótulo persistente, validação junto ao campo, progresso durante envio e confirmação após sucesso. Prevenir segundo clique enquanto a operação está em curso.

## 6. Relatórios e visualização

- Mostrar período e origem dos números acima dos indicadores. Se não houver dados ou atribuição comprovada, explicar isso — não inventar zero ou retorno financeiro.
- Tendência semanal: gráfico de linha simples; comparação de categorias/reativações: barras com valor explícito. Sempre oferecer tabela ou resumo textual equivalente para acessibilidade.
- Separar “reativação pós-atendimento” de “recuperação após falta”; métricas de envio, agendamento vinculado e atendimento concluído não são sinônimos.
- Pesquisa: mostrar pesquisas enviadas, respostas e nota média; Google: **convites enviados**, nunca “reviews publicados” sem fonte verificável.
- “Valor dos atendimentos concluídos” não é receita recebida; comparação com mensalidade não deve ser rotulada como lucro.

## 7. Acessibilidade e responsividade — critérios de aceite

- Verificar em 375, 768, 1024 e 1440 px: sem rolagem horizontal não intencional, toque confortável e controles fixos sem cobrir conteúdo.
- Contraste de texto normal pelo menos 4,5:1; foco visível; ordem Tab lógica; ações acessíveis por teclado; link para pular a navegação.
- Campos com `label` real; gráficos com alternativa textual; mensagens de status anunciáveis por leitores de tela; ícones não são o único marcador de estado.
- Confirmar que modal/painel de conflito gerencia foco, Escape e retorno ao acionador. Respeitar redução de movimento.
- Testar estados em dispositivos móveis com sessão expirada, rede lenta e falha de webhook; não apenas tela feliz no desktop.

## 8. Microcopy e guardrails

- Preferir “Não conseguimos confirmar o envio; estamos verificando” a “Mensagem não enviada” quando o estado for incerto.
- Preferir “Resultado pendente” a “Cliente faltou” sem registro humano.
- Em conflito de agenda, informar o que será mantido/cancelado **antes** do botão final.
- Não expor SQL, nomes de credenciais, IDs técnicos, tokens ou dados de outra empresa nas mensagens.

## 9. Entrega de design

Produzir inventário de componentes atuais, fluxos em mobile/desktop, matriz de estados, protótipos de agenda/detalhe/relatório/bloqueios/gestão e checklist de acessibilidade. Comparar cada tela ao código existente antes de pedir novos componentes. A matriz exata do papel recepcionista e o processo de aprovação da gestão continuam decisões pendentes, não devem ser “resolvidos” apenas pela UI.
