# TRD — requisitos técnicos do Agenda 24h

Versão de trabalho: 24/09/2026. Implementa os resultados do [PRD](01-prd.md), sem autorizar implantação. “V3” nomeia workflows; o modelo de dados oficial permanece V2. Estados remotos citados são a última evidência registrada, não uma inspeção feita hoje.

## 1. Componentes e responsabilidades

| Componente | Responsabilidade | Limite de confiança |
|---|---|---|
| Evolution API | Receber/enviar WhatsApp; instância própria por empresa | `apikey` global fica apenas em credencial n8n do serviço. Não confundir autenticação de saída com segredo do webhook de entrada. |
| n8n | WF1 por empresa; tools e automações compartilhadas; integração administrativa | Nós usam credenciais apropriadas a cada serviço. Exports não carregam valores secretos. |
| Supabase/PostgreSQL | Agenda oficial, identidade, configurações, fila, auditoria, funções transacionais | Resolver `empresa_id` no servidor; aplicar constraints, RLS, privilégios mínimos e FKs compostas. |
| OpenAI | Interpretação de texto/áudio e chamadas de tools do atendimento | IA não escolhe empresa/cliente por parâmetro livre nem grava agenda fora de tool autorizada. |
| Portal React/Vite | UI compartilhada, autenticação com Supabase Auth, leitura protegida e operações via contratos | Nunca conter senha PostgreSQL, `service_role` ou chave Evolution em variáveis públicas. |

## 2. Contratos obrigatórios

### Entrada do WF1

`Evolution messages.upsert → webhook próprio da empresa → validar instância, JID, ID e fromMe → registrar/deduplicar → (áudio: transcrever) → consolidar 5 s → reservar somente a conversa da mensagem → agente/tools → autorizar envio → Evolution → confirmar resultado`.

- Um disparo por mensagem. **Sem Schedule Trigger de 10 s no WF1.** Espera pontual por execução é permitida, inclusive quando a conversa está ocupada.
- Aceitar só texto e áudio do cliente. Imagem/vídeo/outros: HTTP 200 ao emissor, sem resposta WhatsApp. Mensagens próprias necessárias ao controle da pausa humana podem ser registradas.
- Deduplicar por `empresa_id + evolution_message_id`; não escolher outra conversa ao reservar. Usar estado no banco para evitar loops e duplicidade.
- Áudio falho e resposta/entrega ambígua devem ter estado explícito; não transformar falha em confirmação de envio.

### Agenda/tools

- Usar UUIDs V2, IDs de serviço/profissional oriundos do catálogo e token de turno do workflow; não aceitar telefone, empresa ou cliente selecionados pela IA como autoridade.
- Verificar disponibilidade na oferta **e novamente na gravação**. Constraint de não sobreposição deve ser última defesa.
- Confirmar intenção antes de criar/cancelar/remarcar; aplicar antecedência, expediente, exceções, duração, limite diário e buffer no banco.
- Cancelamento/remarcação preservam auditoria e recalculam fila; status final `concluido`/`faltou` não pode ser alterado por tools do cliente.

### Fila e automações

- `fila_mensagens` tem chave idempotente e estados `pendente`, `processando`, `enviado`, `falhou`, `cancelado`.
- Consumidores precisam reservar **tipos específicos** com lock/`SKIP LOCKED`, revalidar elegibilidade e registrar ID retornado pela Evolution. Um consumidor genérico não deve competir pelos mesmos itens.
- Falha HTTP/timeout de resultado incerto fica para conciliação; não reenviar automaticamente. Métricas “enviado” devem representar aceitação do provedor, não entrega final.
- Lembretes: 24 h e 2 h, apenas reserva confirmada e futura; remarcação/cancelamento invalidam itens anteriores.
- Reativação pós-atendimento: último atendimento concluído, prazo por serviço, empresa ativa, consentimento, sem próxima reserva; faltosos em fluxo separado ainda a especificar.
- Pesquisa: funções e fila próprias, resposta capturada antes de entregar mensagem à IA; convite Google não depende da nota.

## 3. Autorização, isolamento e segredos

- Supabase Auth autentica usuário do portal. Contexto de empresa/papel/profissional vem de `membros_empresa` e `auth.uid()` em RPCs, não de `empresa_id` fornecido pelo navegador.
- Administrador lê empresa; profissional lê própria agenda e registra apenas próprios resultados; recepcionista segue permissões específicas. Testar negações tanto na UI quanto no banco.
- Preferir credenciais n8n com escopo próprio quando o contrato existir; **não criar credenciais ou papéis imaginários nos exports**. Antes da ativação, inventariar o que existe e testar conexão/acesso. Header Auth da Evolution: cabeçalho `apikey`, valor da chave global do serviço; mesma credencial pode atender todas as instâncias da instalação.
- Proteger webhook de entrada com segredo diferente da chave de API Evolution. Não registrar payload completo, tokens, senhas ou respostas sensíveis em logs de execução persistentes.
- HTTPS no navegador e endpoints públicos; validar CORS, redirects de Auth, limites e retenção. Backup com restauração ensaiada antes de migration que altera funções compartilhadas.

## 4. Portal e relatórios

- Stack atual verificada: React, TypeScript, Vite, Tailwind, Supabase JS, React Router, Recharts e Lucide; rotas `/login`, recuperação/definição de senha, `/agenda`, `/agenda/:id`, `/visao-geral`, `/relatorios`, `/automacoes`, `/gestao`.
- Portal não apresenta fallback simulado; deve diferenciar carregando, vazio, erro de conexão, falta de vínculo e acesso negado.
- Escritas operacionais usam contrato autenticado, revalidação server-side, idempotência e auditoria. Fluxo de gestão de equipe ainda depende de decisão entre aprovação manual e execução direta.
- Relatório semanal deve separar métricas de agendamento, conclusão, faltas, lembretes, reativações 1/2, satisfação e convites Google. “Conversão de reativação” exige vínculo persistido ao agendamento. Comparar valor de atendimentos concluídos com mensalidade sem chamar de lucro.

## 5. Requisitos de qualidade e teste

| Categoria | Prova mínima |
|---|---|
| Integridade | Duas reservas concorrentes não ocupam o mesmo profissional/intervalo; remarcação reprograma lembretes. |
| Isolamento | Duas empresas e dois clientes não cruzam agenda, conversa, fila, relatórios nem permissões. |
| Idempotência | Repetir webhook/execução, gerar automação e tentar registrar conclusão não duplica efeitos. |
| Resiliência | Timeout de banco, OpenAI e Evolution gera estado observável; envio incerto não é repetido cegamente. |
| Acessibilidade | Portal utilizável por teclado e toque; estados e erros anunciados sem depender só de cor. |
| Operação | Backup/restauração, rollback do webhook e reconciliação de fila documentados; capacidade medida progressivamente. |

Não foram aprovados números de SLO, latência, disponibilidade ou retenção adicionais neste documento; defini-los com medição antes da escala comercial.

## 6. Bloqueios técnicos conhecidos

O WF1 real parou em timeout no nó “Reservar conversa” e foi despublicado. O arquivo linear local depende das migrations V3 ainda não aplicadas na última checagem, de uma conexão PostgreSQL funcional e do status ativo da empresa-teste. Exports locais de automações passaram em PostgreSQL isolado, não em n8n/Evolution real. Não ativar produção apenas por validação de JSON.
