# App flow — cliente, operador e automações

Versão de trabalho: 24/09/2026. Fluxo desejado, com pontos de controle e estados de erro. A operação real ainda exige homologação.

## 1. Entrada e agendamento pelo WhatsApp

```mermaid
flowchart TD
  A[Cliente envia texto ou áudio] --> B[Webhook WF1 da empresa]
  B --> C{Evento válido e da instância?}
  C -- não --> Z[Responder HTTP 200; sem mensagem WhatsApp]
  C -- sim --> D[Registrar e deduplicar no Supabase]
  D --> E{Tipo da mensagem}
  E -- imagem, vídeo ou outro --> Z
  E -- áudio --> F[Transcrever]
  E -- texto --> G[Esperar 5 s e consolidar]
  F --> G
  G --> H[Reservar apenas esta conversa]
  H --> I[IA consulta catálogo e tools compartilhadas]
  I --> J{Cliente confirmou operação?}
  J -- não --> K[Responder/continuar conversa]
  J -- sim --> L[Revalidar e gravar no banco]
  L --> M{Sucesso?}
  M -- não --> K
  M -- sim --> N[Autorizar envio e responder via Evolution]
  K --> N
  N --> O[Confirmar ID de envio ou registrar resultado incerto]
```

Variações: cliente já cadastrado recupera contexto; novo cliente informa nome; cancelamento/remarcação localizam reserva própria e exigem confirmação; mensagem de profissional pausa IA por 30 minutos. Falha de áudio, consulta ou envio deve produzir estado seguro e auditável, sem inventar horário nem repetir envio incerto.

## 2. Ciclo da reserva e do pós-atendimento

```mermaid
flowchart LR
  A[Reserva confirmada] --> B[Fila: 24 h e 2 h]
  A --> C{Mudança de horário ou cancelamento?}
  C -- sim --> D[Invalidar fila antiga e recalcular]
  B --> E[Consumidor revalida e envia]
  A --> F[Horário de início alcançado]
  F --> G{Admin ou profissional registra resultado}
  G -- concluído --> H[Pesquisa opcional + reativação por prazo do serviço]
  G -- faltou --> I[Recuperação de falta: convite a reagendar]
  G -- sem registro --> J[Resultado pendente, sem inferência]
  H --> K[Convite Google neutro se elegível]
```

Lembretes e reativações são **automações agendadas**; isso não altera a regra de entrada por webhook do WF1. A pesquisa e o convite respeitam preferência, frequência e descadastro. Reativação pós-falta precisa de especificação operacional antes da implementação.

## 3. Portal por perfil

| Etapa | Administrador | Profissional | Recepcionista |
|---|---|---|---|
| Login | Supabase Auth → vínculo ativo → empresa | Igual, com `profissional_id` | Igual, papel próprio |
| Agenda | Dia/período, equipe, detalhe | Própria agenda e detalhe permitido | Agenda conforme matriz de permissão a confirmar |
| Resultado | Concluir/falta em atendimento da empresa | Concluir/falta apenas próprio atendimento | Não assumir permissão sem confirmação |
| Análise | Visão geral, automações, relatório | Sem métricas administrativas | Sem métricas administrativas salvo decisão explícita |
| Gestão | Equipe, serviços, bloqueios e solicitações conforme fluxo aprovado | Sem edição | Sem poderes de administrador por herança |

Rotas existentes no código: `/login`, `/recuperar-senha`, `/definir-senha`, `/redefinir-senha`, `/agenda`, `/agenda/:id`, `/visao-geral`, `/relatorios`, `/automacoes`, `/gestao`. Rotas futuras não devem ser apresentadas como entregues.

## 4. Provisionamento e ativação

`Onboarding → revisão humana → provisionamento n8n → empresa/configurações/usuários no Supabase → convite Auth e definição de senha → instância Evolution manual → clonagem/configuração do WF1 → testes com número de controle → ativação da empresa`.

Se criação de usuário, convite, credencial, migration ou teste falhar, a empresa permanece em validação. Não ativar parcialmente nem presumir que um export importado esteja operacional.

## 5. Estados e desvios que a UI deve comunicar

- Autenticação: carregando, sessão expirada, link inválido/expirado, usuário sem vínculo, acesso negado.
- Agenda: vazia, carregando, erro de leitura, conflito de horário, reserva alterada por outro usuário.
- Escrita: confirmação antes de ação sensível, enviando, sucesso auditado, falha, timeout com resultado incerto e possibilidade de consultar antes de repetir.
- Automação: programada, processando, enviada/aceita pela Evolution, falhou, cancelada, pendente de conciliação.
- Métrica: sem dados ou atribuição não comprovada não vira zero fictício nem “avaliação Google publicada”.
