# PRD — Agenda 24h

Versão de trabalho: 24/09/2026. Fonte: decisões registradas no projeto e [passagem de contexto](../passagem-projeto-2026-09-23.md). Este PRD define **o produto pretendido**, não declara que tudo foi implantado. Divergências e lacunas aparecem em “Decisões pendentes”.

## 1. Problema, público e proposta

Pequenos negócios com serviços de duração e preço definidos perdem tempo respondendo WhatsApp, oferecem horários sem consultar a agenda, esquecem lembretes e deixam de recuperar clientes. O Agenda 24h reúne atendimento com IA, agenda própria, automações e portal de operação, mantendo opção de atendimento humano.

Público inicial: autônomos, salões, barbearias e negócios semelhantes que trabalham com hora marcada. A validação será com um salão fictício operado pelo proprietário do produto (`salaoexemplar`); ele não é uma exceção da arquitetura. Não há primeiro cliente pagante homologado.

Resultado esperado: o cliente consegue resolver a jornada de agendamento por texto ou áudio no WhatsApp; a empresa acompanha agenda, comparecimento, automações e desempenho no portal; o sistema evita conflito de horários e mensagens duplicadas.

## 2. Escopo funcional do MVP

| ID | Capacidade | Comportamento aceito |
|---|---|---|
| P-01 | Atendimento WhatsApp | Cada mensagem de cliente dispara o workflow próprio da empresa. Texto e áudio são aceitos; resposta inicial é texto. Imagem, vídeo e demais mídias são ignorados **sem resposta** no WF1 linear escolhido. |
| P-02 | Identificação e contexto | Identificar empresa pela instância Evolution, cliente pelo telefone, recuperar contexto e perguntar o nome quando necessário, sem misturar empresas. |
| P-03 | Catálogo e disponibilidade | Informar apenas serviços, preços, duração, profissionais habilitados e horários cadastrados; consultar agenda real antes de ofertar. |
| P-04 | Agendamento | Exigir confirmação explícita do cliente, revalidar disponibilidade e gravar reserva sem sobreposição. |
| P-05 | Gestão da reserva pelo cliente | Consultar os próprios agendamentos, cancelar ou remarcar após confirmação e conforme prazos da empresa. Remarcação preserva o mesmo registro e recalcula lembretes. |
| P-06 | Intervenção humana | Pausar IA quando um responsável responde; renovar pausa por mensagem manual e retomar após 30 minutos, sem resposta duplicada. |
| P-07 | Lembretes | Programar envios 24 h e 2 h antes para reservas confirmadas; cancelar/recalcular em alteração de estado/horário. |
| P-08 | Reativação 1 | Após atendimento **concluído**, respeitar prazo de retorno do serviço, consentimento e ausência de nova reserva aplicável; convidar a agendar novamente. |
| P-09 | Reativação 2 | Após registro de **falta**, convidar o cliente a reagendar, com regra, fila, idempotência e métricas separadas da reativação 1. |
| P-10 | Comparecimento | Administrador ou profissional responsável registra “Atendimento concluído” ou “Cliente faltou” a partir do início previsto; ausência de resposta não altera status. |
| P-11 | Satisfação/Google | Após conclusão, pesquisa conforme preferências e frequência; convite neutro para avaliação espontânea no Google, independente da nota. Medir convite enviado, não avaliação publicada. |
| P-12 | Portal | Login real; agenda e detalhe; visão geral, automações e relatório semanal para admin; agenda restrita para profissional; papel de recepcionista com permissões próprias. Sem dados simulados como fallback. |
| P-13 | Provisionamento | Onboarding revisado pelo operador, empresa e usuários criados no Supabase; instância e WF1 configurados por empresa; ativação somente após teste. |

## 3. Regras de negócio confirmadas

- Agenda única no Supabase; nunca criar disponibilidade paralela no prompt da IA.
- Antecedência mínima padrão: 1 hora. Cancelamento/remarcação automática: pelo menos 24 horas antes; dentro desse prazo, orientar o número reserva se cadastrado.
- Buffer configurável aplicado **depois** de cada atendimento. Serviço pode pertencer a múltiplos profissionais; cliente escolhe profissional habilitado.
- Uma empresa por instância Evolution e por workflow principal. Tools, lembretes, reativação, banco e portal são compartilhados com isolamento lógico.
- Consolidação normal de mensagens do WF1: 5 segundos após entrada, sem Schedule Trigger a cada 10 segundos. Automações programadas (lembretes/reativação) podem usar gatilho temporal porque dependem da passagem do tempo.
- Reativação e pesquisa exigem preferências próprias; descadastro não deve ser revertido por silêncio ou resposta casual.
- Conclusão/falta são fatos operacionais registrados por usuário autorizado, não inferidos apenas pelo relógio.
- “Valor dos atendimentos concluídos” soma preços cadastrados; não representa pagamento recebido ou lucro. Valor atribuído à reativação é subconjunto do total, não parcela adicional.

## 4. Perfis e resultados

| Perfil | Necessidade central | Limite |
|---|---|---|
| Cliente final | Conversar, consultar, agendar, cancelar/remarcar, receber acompanhamento | Acessa somente reservas do próprio telefone/empresa; operações sensíveis exigem confirmação. |
| Administrador da empresa | Ver agenda da equipe, resultados, automações, ausências e gestão | Somente empresa vinculada; ações protegidas e auditadas. |
| Profissional | Ver própria agenda, registrar conclusão/falta dos próprios atendimentos | Não cria, edita, remarca ou cancela pelo portal. |
| Recepcionista | Operar conforme papel cadastrado e permissões aprovadas | Não herda automaticamente poderes do administrador; matriz exata deve ser testada. |
| Operador da plataforma | Revisar onboarding, ativar empresa, assistir mudanças de equipe e incidentes | Credenciais internas nunca chegam ao navegador ou ao cliente. |

## 5. Critérios para declarar o MVP pronto

1. Pelo WhatsApp do cliente-teste, texto e áudio completam agendamento real, consulta, cancelamento, remarcação e handoff humano; imagem/vídeo não provocam resposta; não há loop nem resposta duplicada.
2. Reserva concorrente não duplica horário; empresa e cliente não conseguem acessar dados de terceiros.
3. Uma reserva de teste gera lembretes corretos; conclusão e falta são registradas no portal e acionam, respectivamente, os fluxos pós-atendimento previstos; falhas/timeout não causam reenvio cego.
4. Administrador, profissional e recepcionista passam por autenticação e autorização reais; relatório apresenta definições e períodos explícitos.
5. Provisionamento de uma segunda empresa fictícia funciona sem regra fixa para `salaoexemplar`; backup/restauração e procedimento de incidente foram testados.
6. Resultados da bateria ponta a ponta e pendências remanescentes são registrados e aprovados pelo proprietário antes de cliente pagante.

## 6. Fora do MVP

Pagamentos pelo WhatsApp, Google Calendar, aplicativo móvel nativo, marketing em massa, prontuário, estoque, aulas coletivas/capacidade, cálculo de deslocamento e escala automática para 50 empresas. A meta de 50 empresas requer teste de capacidade próprio.

## 7. Decisões pendentes ou conflitantes

- **Gestão de equipe/serviços:** documentos anteriores exigem solicitação e aprovação manual assistida; o portal atual prepara um webhook de execução transacional. Definir o fluxo aprovado antes de habilitar escrita.
- **Reativação de faltosos:** definir prazo, consentimento e atribuição de conversão; o export V2 atual cobre somente retorno pós-atendimento.
- **Recepcionista:** confirmar a matriz exata de visualização e ações no banco, n8n e portal.
- **Relatório:** persistir vínculo explícito entre envio de reativação e reserva resultante; não usar mera proximidade temporal como prova.
- **Operação comercial:** regras de suspensão/cancelamento por inadimplência e implantação final do portal ainda precisam de decisão/validação.

## 8. Evidência disponível em 24/09

WF1 linear, tools, lembretes e reativação pós-atendimento têm artefatos locais; não há jornada externa homologada. O WF1 testado anteriormente foi despublicado após timeout em “Reservar conversa”. No último diagnóstico de leitura, a empresa-teste estava `em_validacao` e funções/papel da migration V3 não existiam. Não inferir estado remoto atual sem nova checagem.
