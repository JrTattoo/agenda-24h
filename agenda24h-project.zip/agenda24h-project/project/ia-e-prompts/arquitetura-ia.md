# IA e prompts do Agenda 24h

## Estado do documento

Este documento combina informações declaradas pelo responsável do projeto com evidências do inventário dos workflows n8n. Pontos ainda não confirmados estão explicitamente marcados.

## Definições confirmadas pelo responsável

1. As ferramentas da IA são workflows do n8n, criados ou adaptados conforme a necessidade de cada operação.
2. Na ponta do cliente, a resposta deve ser uma conversa natural.
3. A memória da conversa utiliza Redis.
4. As informações do estabelecimento destinadas à IA são obtidas durante o provisionamento.
5. A transferência para humano ocorre quando o cliente pede ou quando um profissional entra na conversa.
6. A principal proteção contra respostas inventadas está no prompt, mas ainda não apresenta confiabilidade suficiente.
7. O custo operacional ainda não foi medido e permanece indefinido.
8. Não existe contingência ativa; a intenção é avaliar um modelo Qwen local como alternativa.
9. O atendimento deve compreender mensagens de texto e áudio recebidas pelo WhatsApp.
10. Imagens e vídeos não serão suportados no MVP.
11. O processamento de áudio deve fazer parte do modelo oficial do workflow principal que será criado para cada empresa.

## Modelo principal

Modelo declarado pelo responsável: `gpt-5-mini`, utilizado por meio do nó OpenAI Chat Model no n8n.

Ainda precisa ser confirmado diretamente na configuração do nó:

- ID exato do modelo.
- Endpoint/API usado pelo nó.
- Nível de raciocínio.
- Limite máximo de saída.
- Timeout e número de tentativas.
- Temperatura ou outros parâmetros, quando aplicáveis.

O plano ChatGPT e o consumo da API são contextos diferentes. Para o cálculo deste projeto, deve-se usar o consumo registrado na conta da API conectada ao n8n.

Segundo a documentação oficial consultada em 5 de setembro de 2026, GPT-5 Mini é voltado a tarefas bem definidas, alto volume e baixa latência, suporta function calling e structured outputs e possui contexto de até 400 mil tokens.

Fonte oficial: https://developers.openai.com/api/docs/models/gpt-5-mini

## Outros usos de IA encontrados

O workflow principal ativo também contém:

- `OpenAI - Transcrever Audio`
- `OpenAI - Analisar Imagem`

O modelo utilizado para transcrição não apareceu no relatório sanitizado. Seu custo e comportamento não devem ser incluídos como GPT-5 Mini até que o ID seja confirmado.

O nó `OpenAI - Analisar Imagem` pertence à ideia anterior. Como imagens não fazem parte do escopo confirmado, ele deverá ser removido ou permanecer desativado no modelo oficial, sem receber credenciais nem executar chamadas.

## Entradas de texto e áudio

### Requisito funcional

O texto é a entrada básica da conversa. O áudio também é obrigatório na primeira versão.

### Áudio

O workflow principal de cada empresa deverá:

1. reconhecer que a mensagem contém áudio;
2. baixar o arquivo recebido de forma controlada;
3. validar formato e tamanho;
4. transcrever o conteúdo;
5. enviar a transcrição para o mesmo agente que processa mensagens de texto;
6. usar a transcrição no contexto da conversa sem expor detalhes técnicos ao cliente;
7. informar de forma natural quando não for possível compreender o áudio.

### Formatos não suportados

Imagens e vídeos não serão baixados nem enviados para análise de IA. Ao receber um desses formatos, o workflow deverá responder de forma determinística que o atendimento aceita texto ou áudio e pedir que o cliente descreva sua necessidade em um desses formatos.

Documentos, localização, contatos e outros formatos também ficam fora do escopo até que sejam explicitamente aprovados.

### Resposta ao cliente

Compreender áudio não significa obrigatoriamente responder em áudio. Até nova definição, a saída do atendimento continua sendo uma conversa natural em texto pelo WhatsApp.

### Estado técnico

O inventário encontrou um nó de transcrição de áudio no workflow ativo, mas isso não comprova que o caminho esteja pronto. Ainda precisam ser verificados modelo, credencial, limites, tratamento de falhas, privacidade, custo e inclusão correta no modelo oficial do workflow individual. O caminho antigo de análise de imagem deve ser retirado ou desativado.

## Estratégia de prompts

Informação declarada: os prompts são personalizados de acordo com o negócio e o ramo de cada contratante. As informações são coletadas durante o provisionamento.

O banco possui campos capazes de sustentar essa personalização:

- `nome_negocio`
- `nicho`
- `nome_assistente`
- `persona`
- `estilo_comunicacao`
- `conhecimentos_especificos`
- `objetivos_principais`
- `escalar_urgencias`
- `restricoes_ia`
- `comportamento_ia`
- `faq`
- `system_prompt`
- `linguagem`
- `idioma`
- Horários, dias, pausa, políticas de atraso, cancelamento e automações.

### Pendência crítica

No workflow principal ativo, a consulta `Postgres - Validar Instancia` retorna apenas `id` e `tag`. Não foi observada, antes do agente, uma consulta que carregue `system_prompt`, persona, FAQ, restrições ou demais configurações do contratante.

Há três possibilidades que precisam ser verificadas:

1. O prompt está escrito diretamente no nó `AI Agent - Maria` a partir de uma versão produzida no provisionamento.
2. O prompt referencia dados do provisionamento por uma expressão não capturada no inventário.
3. A personalização é produzida no provisionamento, mas sua versão armazenada no banco ainda não está efetivamente conectada ao agente.

Não considerar a personalização dinâmica confirmada até inspecionar os parâmetros do nó do agente.

## Ferramentas que a IA pode chamar

O agente principal ativo possui cinco ferramentas conectadas. Como regra do projeto, essas ferramentas são workflows n8n criados ou adaptados conforme a necessidade, e novas ferramentas poderão ser adicionadas quando surgirem novas operações controladas.

| Ferramenta exposta à IA | Workflow chamado | Finalidade |
|---|---|---|
| `confirmar_agendamento` | `_tool_agendarhorario` | Criar um agendamento após confirmação explícita |
| Verificação de disponibilidade | `_tool_verificardisponibilidade` | Conferir data e horário específicos |
| Busca de horários | `_tool_buscarhorarios` | Consultar profissionais, serviços, preços e agenda |
| Meus agendamentos | `_tool_meusagendamentos` | Listar agendamentos futuros do telefone |
| Gerenciar agendamento | `_tool_gerenciar_agendamento` | Reagendar ou cancelar |

As descrições das ferramentas possuem duas proteções positivas:

- A IA é instruída a nunca afirmar disponibilidade sem consultar a ferramenta.
- A IA é instruída a nunca confirmar agendamento sem retorno de sucesso da ferramenta de gravação.

Contudo, a auditoria separada confirmou que as consultas de várias ferramentas estão incompatíveis com o schema atual. Uma instrução correta não compensa uma ferramenta que falha; o prompt precisa prever uma resposta segura quando a ferramenta retorna erro.

## Formato das entradas das ferramentas

### Confirmar agendamento

- Telefone.
- Data e hora em ISO 8601.
- Nome do cliente.
- Instância Evolution.
- Serviço.
- Profissional.

### Verificar disponibilidade

- Data e hora em ISO 8601.
- Telefone.
- Instância Evolution.

Essa ferramenta não recebe explicitamente serviço e profissional, embora esses dados sejam necessários para calcular duração, agenda e conflito corretamente.

### Buscar horários

- Texto da solicitação do cliente.
- Telefone.
- Instância Evolution.

### Meus agendamentos

- Telefone.
- Instância Evolution.

### Gerenciar agendamento

- Ação: `reagendar` ou `cancelar`.
- ID do agendamento.
- Nova data e hora, quando aplicável.
- Telefone.
- Instância Evolution.

A descrição atual diz “ID numérico”, mas o banco usa UUID. Isso precisa ser corrigido.

## Formato esperado das respostas ao cliente

Definição funcional: a experiência na ponta deve ser uma conversa natural, adequada ao negócio e ao momento do atendimento. O cliente não deve receber JSON, nomes internos de ferramentas, consultas, códigos de erro ou termos técnicos do n8n.

O workflow mostra o seguinte processo:

1. O agente produz uma resposta textual.
2. Um nó de código divide a resposta em blocos.
3. Os blocos são enviados individualmente pelo WhatsApp.
4. Há espera de um segundo entre blocos.

O formato textual exato ainda não foi coletado. Precisamos confirmar no prompt:

- Se Markdown é proibido ou convertido.
- Tamanho máximo de cada bloco.
- Quantidade máxima de mensagens por resposta.
- Uso de emojis.
- Como datas, horários e preços são formatados.
- Como sucesso, indisponibilidade e erro de ferramenta são comunicados.
- Se a IA deve produzir somente texto ou alguma estrutura intermediária.

Para reduzir ambiguidades, recomenda-se que ferramentas retornem objetos estruturados internamente e que somente a última camada converta o resultado em mensagem natural.

## Memória da conversa

Definição confirmada: a memória utiliza Redis. O workflow ativo utiliza especificamente Redis Chat Memory.

| Item | Estado observado |
|---|---|
| Chave lógica | Instância Evolution + identificador remoto do contato |
| TTL | 86.400 segundos, equivalente a 24 horas |
| Separação por empresa | Feita pela instância na chave |
| Separação por contato | Feita pelo identificador remoto na chave |

Também existe um buffer de mensagens no Redis com TTL de 300 segundos e espera de 15 segundos. Ele consolida mensagens consecutivas antes de chamar a IA.

Ainda é necessário definir:

- Quantas mensagens da conversa entram em cada chamada.
- Se existe resumo quando o histórico cresce.
- Como o histórico é removido mediante solicitação do cliente.
- Se dados sensíveis devem ser omitidos da memória.
- O que acontece quando o Redis fica indisponível.
- Se a chave usa separador inequívoco entre instância e contato.

## Informações do estabelecimento fornecidas à IA

Definição funcional: as informações destinadas à IA são obtidas durante o provisionamento do estabelecimento.

Arquitetura recomendada: o Supabase será a fonte oficial das informações estruturadas. O workflow principal carregará persona, FAQ, políticas e restrições para compor o system prompt. Preço, duração, profissionais, horários, antecedência, buffer e prazos continuarão sendo consultados e validados pelas tools, mesmo quando forem mencionados no prompt.

O mapeamento detalhado está em `provisionamento/mapeamento-onboarding.md`.

Dados disponíveis no banco não são necessariamente dados fornecidos ao modelo.

### Disponíveis no banco

- Identidade e ramo do negócio.
- Persona, estilo, conhecimentos, objetivos e restrições.
- FAQ.
- Regras gerais de agenda.
- Mensagens personalizadas de automação.
- Serviços e profissionais.

### Confirmados no fluxo transacional

As ferramentas consultam partes de:

- Identificador da empresa.
- Nome do negócio.
- Horários e dias de funcionamento.
- Profissionais.
- Serviços, duração e preço.
- Agendamentos existentes.

### Ainda não confirmado no prompt principal

- `system_prompt` do contratante.
- Persona.
- FAQ.
- Restrições da IA.
- Conhecimentos específicos.
- Políticas de cancelamento, atraso e urgência.
- Idioma e estilo de comunicação.

## Transferência para atendimento humano

Regras declaradas:

- Transferir quando o cliente pedir atendimento humano.
- Suspender a IA quando um profissional entrar na conversa.
- Retomar automaticamente a IA depois de 30 minutos sem uma nova mensagem enviada pelo profissional.

O workflow `_guard_antiloop` possui uma forma de handoff:

- Ao detectar mensagem enviada pelo próprio número, grava `human_active` no Redis.
- A chave é separada por instância e contato.
- O bloqueio do robô dura 1.800 segundos, ou 30 minutos.
- Durante esse período, o atendimento automatizado não deve prosseguir.

### Regra oficial de pausa e retomada

1. Quando o profissional envia uma mensagem manual ao cliente, a IA é pausada para aquela conversa.
2. A pausa dura 30 minutos a partir da última mensagem manual do profissional.
3. Cada nova mensagem do profissional reinicia a contagem de 30 minutos.
4. Durante a pausa, a IA não responde automaticamente às mensagens daquele contato.
5. Mensagens enviadas pelo cliente durante a pausa são guardadas como pendentes.
6. Se o profissional responder manualmente depois dessas mensagens, elas deixam de estar pendentes para a IA.
7. Depois de 30 minutos completos sem nova mensagem humana, a conversa volta a aceitar atendimento automático.
8. Se ainda existirem mensagens do cliente sem resposta humana, a IA deve processá-las e respondê-las automaticamente, sem esperar uma nova mensagem do cliente.
9. Várias mensagens pendentes consecutivas devem ser agrupadas em uma única entrada contextual antes de chamar a IA.
10. A pausa é individual por empresa/instância e contato; ela não pode interromper outras conversas.

O TTL de 1.800 segundos observado no Redis coincide com a regra desejada, mas a expiração de uma chave não executa sozinha uma resposta no n8n. Será necessário um mecanismo de fila ou retomada agendada para acordar o fluxo, conferir novamente o estado humano e processar somente mensagens realmente pendentes.

Antes de enviar a resposta atrasada, o sistema deverá confirmar novamente que:

- os 30 minutos terminaram;
- não houve nova mensagem humana;
- a mensagem pendente ainda não foi respondida;
- outra execução não está processando a mesma conversa;
- a empresa e o contato continuam ativos.

Também existe proteção contra loops:

- Contador de loop com TTL de 300 segundos.
- Marcação de loop suspeito com TTL de 7.200 segundos.
- Notificação ao contratante quando um loop suspeito é detectado.

O segundo caso já possui suporte técnico observado: ao detectar uma mensagem enviada pelo próprio número, o sistema ativa `human_active`. O primeiro caso — pedido explícito do cliente — ainda precisa ser comprovado no prompt e no fluxo.

Ainda faltam regras claras para:

- Detecção confiável das diferentes formas de pedir uma pessoa.
- Reclamação, ameaça, emergência ou risco.
- Falha repetida das ferramentas.
- Número máximo de tentativas da IA.
- Horário em que existe atendente disponível.

A decisão sobre quantidade de tentativas ficará pendente até a análise do workflow `_guard_antiloop` completo que será enviado pelo responsável. O inventário confirma sua existência, mas não substitui a revisão da lógica real.

## Proteção contra respostas inventadas

Estado declarado: a proteção depende principalmente do prompt e ainda não funciona bem o suficiente. Portanto, o sistema não deve ser considerado protegido apenas porque o prompt contém proibições.

Proteções já observadas:

- Disponibilidade deve vir de ferramenta.
- Confirmação deve depender de gravação bem-sucedida.
- Ferramentas possuem funções separadas.
- Instância e telefone acompanham as chamadas.

Proteções ainda necessárias:

- Em qualquer erro de ferramenta, dizer que não foi possível confirmar e nunca improvisar resultado.
- Exigir identificadores retornados pelo banco, não nomes inventados.
- Usar listas fechadas para ações como reagendar/cancelar.
- Validar a saída estruturada das ferramentas.
- Limitar tentativas repetidas.
- Registrar chamada, resultado e erro sem guardar conteúdo além do necessário.
- Criar testes contra prompt injection enviada pelo WhatsApp.
- Impedir que conteúdo do cliente altere regras do sistema ou revele o prompt.
- Nunca expor dados de outro telefone ou outra empresa.

## Custos aproximados do GPT-5 Mini

Estado do projeto: custo por atendimento ainda indefinido e sem medição real.

Preços oficiais consultados em 5 de setembro de 2026, por 1 milhão de tokens:

| Tipo | Preço em USD |
|---|---:|
| Entrada | US$ 0,25 |
| Entrada em cache | US$ 0,025 |
| Saída | US$ 2,00 |

Fórmula por chamada:

`custo = (tokens_entrada / 1.000.000 × 0,25) + (tokens_saida / 1.000.000 × 2,00)`

Exemplos meramente ilustrativos:

| Consumo acumulado | Custo aproximado |
|---|---:|
| 10 mil tokens de entrada + 1 mil de saída | US$ 0,0045 |
| 50 mil tokens de entrada + 5 mil de saída | US$ 0,0225 |
| 1 milhão de entrada + 100 mil de saída | US$ 0,45 |

Esses valores não incluem:

- Transcrição de áudio.
- Outros modelos ou ferramentas cobradas separadamente.
- Impostos e conversão para reais.

O custo por atendimento ainda não pode ser calculado porque faltam métricas reais de tokens por chamada, quantidade de chamadas por conversa e proporção de mensagens em áudio.

## Modelos alternativos e contingência

Não há contingência implementada no workflow atual. O nome informado, `Qwen 3.7 Mini`, não foi localizado como identificador oficial na família Qwen consultada. A intenção confirmada é avaliar um modelo Qwen local; tamanho e versão ainda precisam ser escolhidos.

Opções a avaliar por testes, sem troca automática neste momento:

- Outro modelo de API compatível com function calling, condicionado a testes de qualidade, custo e latência.
- Qwen3 local via Ollama, escolhendo posteriormente um tamanho oficial, como 4B ou 8B, condicionado à capacidade do servidor e aos testes.
- Um modelo local via Ollama, já disponível no servidor, inicialmente para tarefas simples como classificação e FAQ.
- Resposta determinística de indisponibilidade quando a OpenAI estiver fora do ar.
- Transferência para humano após falhas consecutivas.

Um modelo local não deve assumir operações transacionais de agenda sem demonstrar, por testes, uso confiável das ferramentas e respeito ao isolamento entre empresas.

Fontes oficiais consultadas em 7 de setembro de 2026:

- https://github.com/QwenLM/Qwen3
- https://huggingface.co/collections/Qwen/qwen3

## Prioridades do item 5

### Críticas

1. Confirmar o prompt completo do nó `AI Agent - Maria`.
2. Confirmar se os dados personalizados do contratante chegam ao agente.
3. Corrigir as ferramentas incompatíveis com o banco antes de confiar nas respostas da IA.
4. Definir comportamento seguro quando uma ferramenta falhar.
5. Incorporar e testar áudio no modelo oficial do workflow principal por empresa e retirar ou desativar a análise de imagem.

### Altas

1. Confirmar os modelos de chat e transcrição de áudio.
2. Padronizar formato interno das respostas das ferramentas.
3. Formalizar regras de transferência para humano.
4. Medir tokens e custo por conversa.
5. Criar testes de alucinação, isolamento entre empresas e prompt injection.

### Médias

1. Avaliar alternativa de nuvem e alternativa local.
2. Revisar TTL e privacidade da memória.
3. Versionar prompts por contratante, com histórico e data de publicação.

## Informações ainda necessárias

- Parâmetros sanitizados do `AI Agent - Maria`.
- Parâmetros sanitizados do `OpenAI Chat Model`.
- Modelo do nó de transcrição de áudio.
- Confirmação de que o nó antigo de análise de imagem foi removido ou desativado.
- Código do nó que divide respostas em blocos.
- Exemplo anonimizado de entrada e saída bem-sucedida.
- Exemplo anonimizado de falha de ferramenta.
- Estatísticas de tokens e chamadas, sem conteúdo das conversas.
- Política desejada de handoff e retomada.
- Modelo local instalado no Ollama que poderia servir de contingência.
