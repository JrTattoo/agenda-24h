# Capacidade e escala

## Meta confirmada

**Confirmada em 6 de setembro de 2026:** a meta inicial é atender até 50 empresas no servidor local atual do Agenda 24h.

Neste documento, “cliente” significa uma empresa contratante do Agenda 24h, e não o consumidor final que conversa pelo WhatsApp.

Cada empresa terá:

- seu próprio número de WhatsApp;
- sua própria instância na Evolution API;
- seu próprio workflow principal de atendimento;
- vínculo individual entre contratante, instância e workflow.

Portanto, a meta final desta etapa representa até 50 empresas, 50 números, 50 instâncias da Evolution API e 50 workflows principais individuais no mesmo servidor.

## Limite ainda não comprovado

A meta de 50 empresas é um objetivo de projeto. O inventário do servidor, por si só, não comprova que a máquina consiga manter esse volume com estabilidade.

A capacidade dependerá principalmente de:

- quantidade de instâncias de WhatsApp conectadas;
- quantidade de workflows principais individuais ativos;
- quantidade média de profissionais e serviços por empresa;
- número de conversas e mensagens nos horários de pico;
- quantidade de execuções simultâneas do n8n;
- chamadas simultâneas ao modelo de IA;
- volume de histórico armazenado;
- frequência de lembretes e reativações;
- conexões e consultas simultâneas ao PostgreSQL;
- consumo de memória do Evolution API, n8n, Redis e Supabase;
- desempenho do disco e crescimento dos logs e backups;
- disponibilidade da internet e energia do local.

## Estratégia de crescimento

O crescimento deve ocorrer em etapas, com medição antes de avançar:

1. um cliente-teste;
2. primeiros clientes pagantes;
3. dez empresas;
4. vinte e cinco empresas;
5. cinquenta empresas.

Cada etapa deve confirmar que o sistema continua estável antes de cadastrar o próximo grupo.

## Indicadores necessários

- uso médio e máximo de CPU;
- uso de memória e swap;
- espaço livre e crescimento diário do banco;
- tempo entre a mensagem recebida e a resposta enviada;
- quantidade de execuções simultâneas e em fila no n8n;
- taxa de falhas dos workflows;
- conexões e desconexões das instâncias de WhatsApp;
- tempo das consultas de disponibilidade;
- erros e espera por limite da API de IA;
- quantidade de lembretes e reativações processados por período;
- disponibilidade do servidor e dos túneis públicos.

## Testes antes de considerar a meta validada

- simular várias conversas simultâneas sem usar dados pessoais;
- testar dois clientes tentando reservar o mesmo horário;
- concentrar lembretes no mesmo minuto;
- reiniciar serviços e confirmar a recuperação automática;
- simular indisponibilidade temporária da IA, WhatsApp e banco;
- testar filas, novas tentativas e prevenção de mensagens duplicadas;
- restaurar um backup em ambiente separado;
- acompanhar o sistema por um período contínuo com o cliente-teste.

## Informações ainda pendentes

- média e máximo de profissionais por empresa;
- média de conversas por empresa por dia;
- pico esperado de conversas simultâneas;
- consumo médio e máximo de recursos por instância de WhatsApp;
- custo de manutenção e atualização dos 50 workflows principais individuais;
- quantidade real de profissionais nos clientes do plano Empresa, limitado a 15 por empresa;
- quantidade e tamanho médio das mensagens de áudio;
- período de retenção de conversas e logs;
- nível aceitável de indisponibilidade;
- plano para queda de energia ou internet;
- ponto de migração para outro servidor ou infraestrutura.

## Critério de capacidade

O servidor somente será declarado apto para 50 empresas depois de testes progressivos demonstrarem estabilidade, tempo de resposta aceitável, ausência de perda ou duplicidade de mensagens e recuperação segura após falhas.
