# Estrutura lógica do servidor — 17/09/2026

Fonte: saída de comandos executados pelo usuário no Ubuntu via SSH e enviada nesta data. Sem acesso direto do assistente, instalação, mudança de configuração ou reinício. Este registro complementa e atualiza o inventário de 05/09 em servidor-ubuntu.md. Não contém variáveis de ambiente, credenciais ou conteúdo dos arquivos Compose.

## Instalação e organização

- Docker Engine 29.7.2 e Compose v5.5.0; forma original de instalação não consultada.
- DockerRootDir: /var/lib/docker; driver reportado overlayfs; logs padrão json-file; cgroups 2. Rotação e overrides de logs por container não consultados. Diretório do containerd não consultado.
- 19 containers, todos Up 6 days; nenhum parado na listagem. 12 exibem healthy; sete não exibem indicação de healthcheck (isso não significa falha).
- Seis projetos Compose: supabase (13 containers), n8n, evolution, baserow, redis e postgres (um cada). Portainer sem labels Compose; não presumir criação manual ou arquivo inexistente.
- Todos os 19 conectados à multiverso-network, bridge de escopo local. Outras redes listadas: bridge, host e none. IPAM, regras de isolamento e conexões reais entre aplicações não consultados.
- Supabase: restart unless-stopped em seus 13 containers. Demais seis: always. Não houve teste de reinício nem comprovação de ordem de prontidão.
- Todos reportaram HostConfig.Memory=0 e HostConfig.NanoCpus=0. Não há limites nesses campos; CpuQuota/CpuPeriod/Cpuset e restrições externas não foram coletados.

## Containers e portas publicadas

Portas abaixo são do host. Traço indica ausência de publicação no host, não ausência de portas internas. Supabase usa o Compose /mnt/storage/supabase/supabase/docker/docker-compose.yml.

| Container | Imagem | Porta do host → container | Healthy exibido |
|---|---|---|---|
| supabase-edge-functions | supabase/edge-runtime:v1.71.2 | — | Não |
| supabase-kong | kong/kong:3.9.1 | Todas interfaces: 8100→8000, 8444→8443 | Sim |
| supabase-studio | supabase/studio:2026.04.27-sha-5f60601 | — | Sim |
| supabase-vector | timberio/vector:0.53.0-alpine | — | Sim |
| supabase-storage | supabase/storage-api:v1.48.26 | — | Sim |
| supabase-pooler | supabase/supavisor:2.7.4 | Todas interfaces: 5433→5432, 6543→6543 | Sim |
| supabase-meta | supabase/postgres-meta:v0.96.3 | — | Sim |
| supabase-analytics | supabase/logflare:1.36.1 | — | Sim |
| supabase-auth | supabase/gotrue:v2.186.0 | — | Sim |
| realtime-dev.supabase-realtime | supabase/realtime:v2.76.5 | — | Sim |
| supabase-rest | postgrest/postgrest:v14.8 | — | Não |
| supabase-db | supabase/postgres:15.8.1.085 | — | Sim |
| supabase-imgproxy | darthsim/imgproxy:v3.30.1 | — | Sim |
| n8n | n8nio/n8n:2.36.8 | 127.0.0.1:5678→5678 | Não |
| portainer | portainer/portainer-ce:latest | 127.0.0.1:9000→9000 | Não |
| evolution-api | evoapicloud/evolution-api:latest | 127.0.0.1:8081→8080 | Não |
| baserow | baserow/baserow:latest | 127.0.0.1:8000→80 | Sim |
| redis | redis:7 | 127.0.0.1:6379→6379 | Não |
| postgres | postgres:16 | 127.0.0.1:5432→5432 | Não |

Cada projeto não Supabase usa /home/multiverso/docker/<projeto>/docker-compose.yml: n8n, evolution, baserow, redis e postgres. Não foi lido o conteúdo desses arquivos. Não presumir que postgres:16 atende n8n ou Evolution apenas pela presença na mesma rede.

## Persistência e discos

Mapeamento baseado nos mounts e no inventário de discos desta sessão. Prefixo dos volumes locais: /var/lib/docker/volumes/<nome>/_data (SSD). Prefixo dos binds Supabase abaixo: /mnt/storage/supabase/supabase/docker/volumes (HD).

| Container | Origem no host | Destino no container |
|---|---|---|
| n8n | Volume n8n_n8n_data | /home/node/.n8n |
| evolution-api | Volume evolution_data | /evolution/dist/store |
| baserow | Volume baserow_baserow_data | /baserow/data |
| postgres | Volume postgres_postgres_data | /var/lib/postgresql/data |
| redis | Volume 34506c01321371493b395c19d237596fdbc0665df6db9676bed6d6912dd52abb | /data |
| portainer | Volume portainer_data | /data |
| supabase-db | Volume supabase_db-config | /etc/postgresql-custom |
| supabase-edge-functions | Volume supabase_deno-cache | /root/.cache/deno |
| supabase-db | Bind db/data | /var/lib/postgresql/data |
| supabase-storage e supabase-imgproxy | Bind storage | /var/lib/storage |
| supabase-edge-functions | Bind functions | /home/deno/functions |
| supabase-studio | Bind functions; snippets | /app/edge-functions; /app/snippets |

Todos os mounts acima reportam escrita=true. A presença de um volume não comprova que ele contém todos os dados necessários à recuperação da aplicação.

Outros mounts confirmados:

- Kong: api/kong-entrypoint.sh → /home/kong/kong-entrypoint.sh e api/kong.yml → /home/kong/temp.yml, somente leitura.
- Vector: logs/vector.yml → /etc/vector/vector.yml, somente leitura; /var/run/docker.sock → mesmo caminho, escrita=false.
- Pooler: pooler/pooler.exs → /etc/pooler/pooler.exs, somente leitura.
- Portainer: /var/run/docker.sock → mesmo caminho, escrita=true. Acesso ao socket merece revisão específica; a flag de mount sozinha não documenta autorizações da API Docker.
- Banco Supabase: db/logs.sql, pooler.sql, roles.sql, realtime.sql, webhooks.sql, jwt.sql e _supabase.sql montados em /docker-entrypoint-initdb.d, conforme inspect, com escrita=true. Montagem não comprova execução recente desses scripts.
- Meta, Analytics, Auth, Realtime e REST sem mounts na saída. Isso não implica ausência de dados persistidos em serviços externos.

## Consumo observado

Fotografia única, não média, pico ou teste de capacidade. Destaques de RAM: Baserow 2,158 GiB; Kong 1,377 GiB; n8n 700 MiB; Analytics 683,3 MiB; banco Supabase 260,4 MiB. Maior CPU na amostra: Kong 19,11% na métrica do Docker; não interpretar como 19,11% de toda a capacidade dos 12 processadores lógicos. Block I/O é contador acumulado, não taxa instantânea.

docker system df: 25 imagens (19 ativas), 29,35 GB, com 10,36 GB reportados como recuperáveis; 19 containers ativos, 554,6 MB; oito volumes locais ativos, 585,2 MB; cache de build zero. Os binds do HD não estão representados como volumes locais nessa soma. Não foi executada limpeza e o valor recuperável não é autorização para remover imagens.

## Serviços do Ubuntu e rede

38 unidades de serviço em execução e zero unidades no estado failed na consulta. Isso não certifica funcionamento de ponta a ponta.

- Infraestrutura: docker, containerd, cloudflared, ollama, ssh, fail2ban, cron, chrony e rsyslog ativos.
- Ambiente gráfico e periféricos presentes: gdm, Bluetooth, CUPS/cups-browsed, Avahi, ModemManager, colord e switcheroo-control. Nenhum removido ou desativado.
- Rede e sistema: NetworkManager, wpa_supplicant, systemd-resolved, networkd-dispatcher, journald, udevd, logind, oomd, dbus, polkit, accounts-daemon e serviços de usuário ativos.
- Energia/manutenção: thermald, power-profiles-daemon, upower, udisks2, fwupd, snapd, unattended-upgrades e rtkit-daemon ativos. Isso não confirma atualizações instaladas ou política de energia adequada a servidor.

ss reconfirma publicações Docker e SSH na porta 22 em IPv4/IPv6. Serviços locais adicionais: Ollama 11434, cloudflared 20241, CUPS 631, resolved 53 e chrony UDP 323. Avahi usa UDP 5353 nas interfaces; cloudflared apresenta sockets UDP dinâmicos. Não inferir portas públicas de entrada a partir desses sockets UDP.

O usuário informa administração pela rede local com token; não foram verificados mecanismo de autenticação, firewall, roteador, regras Cloudflare Access ou rotas publicadas no túnel. Estar em 127.0.0.1 restringe a publicação direta no host, mas não exclui acesso via proxy/túnel ou pela rede Docker. Escutar em todas as interfaces não comprova exposição à internet.

## Pendências para completar o mapa funcional

1. Identificar, sem senhas, banco/host/porta utilizados por n8n, Evolution e Baserow e quais aplicações usam Redis.
2. Obter configurações sanitizadas dos Compose e forma de recriação do Portainer; não solicitar dumps integrais de ambiente ou configuração com segredos.
3. Confirmar rotas e controles do Cloudflare, firewall e autenticação SSH/Fail2Ban.
4. Conferir dependências de inicialização, healthchecks, rotação de logs e controles de recursos não coletados.
5. Mapear backup de ambos os discos e testar restauração em ambiente separado.

Nenhuma pendência autoriza automaticamente mudança em produção. Este inventário não muda a fase de implantação das funcionalidades do produto.
