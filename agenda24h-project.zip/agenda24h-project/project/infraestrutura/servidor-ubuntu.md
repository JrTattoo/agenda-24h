# Inventário do servidor Ubuntu

## Finalidade

Este documento registra o estado conhecido do servidor local que hospeda o Agenda 24h. Inventário inicial: 5 de setembro de 2026, às 20:18 (America/Sao_Paulo). Hardware e inventário lógico atualizados em 17/09/2026 a partir de coletas executadas pelo usuário via SSH. Detalhes da coleta lógica em [Instalação e containers](estrutura-logica-20260917.md). Configurações internas das aplicações, versão/configuração do Cloudflare e rotinas de backup permanecem históricas, salvo indicação explícita.

Não registrar neste arquivo senhas, tokens, chaves privadas, conteúdo de arquivos `.env` ou credenciais de serviços.

## Resumo executivo

O Agenda 24h roda localmente em um notebook MSI GP63 Leopard 8RE com Ubuntu, Docker e Docker Compose. O hardware confirmado possui 6 núcleos/12 threads e 32 GB de RAM instalada (30 GiB reportados pelo sistema, 22 GiB disponíveis na coleta de 17/09), além de SSD para o sistema e HD para os dados do Supabase. A folga de memória e espaço nesta amostra não determina capacidade de atendimento nem substitui testes de carga e de saúde dos discos.

Os principais componentes encontrados foram n8n, Supabase self-hosted, Evolution API, Baserow, Redis, PostgreSQL, Portainer, Ollama e Cloudflare Tunnel. O n8n está publicado por meio do Cloudflare Tunnel e escuta apenas no endereço local do servidor.

Os pontos de maior atenção são:

- Portas do gateway e do pool de conexões do Supabase escutando em todas as interfaces do host.
- Imagens Docker com a etiqueta `latest`, que dificultam reproduzir e controlar atualizações.
- Existência de rotinas de backup, mas sem evidência ainda de teste de restauração.
- Versão do `cloudflared` marcada como desatualizada nos próprios registros do serviço.
- Necessidade de confirmar qual PostgreSQL é utilizado pelo n8n e por cada aplicação.

## Sistema operacional e hardware

| Item | Estado confirmado |
|---|---|
| Equipamento | MSI GP63 Leopard 8RE |
| Nome do host | `multiverso-GP63-Leopard-8RE` |
| Sistema | Ubuntu 26.04.1 LTS (Resolute Raccoon) |
| Kernel | Linux 7.0.0-31-generic, x86_64 (17/09/2026; substitui -30 da coleta anterior) |
| Placa-mãe | MSI MS-16P5, REV:1.0 |
| Firmware | E16P5IMS.110, data reportada 20/05/2019 |
| Processador | Intel Core i7-8750H a 2,20 GHz |
| Núcleos e threads | 1 soquete, 6 núcleos físicos, 2 threads por núcleo; 12 processadores lógicos online |
| Frequências reportadas | Mínima 800 MHz; máxima 4.100 MHz; não representam frequência sustentada sob carga |
| Cache e virtualização | L3 de 9 MiB; VT-x reportado |
| Memória instalada | 32 GB: 2 módulos de 16 GB DDR4 SODIMM, sem ECC |
| Módulos | CT16G4SFD824A.M16FRS em ChannelA-DIMM0 e ChannelB-DIMM0; fabricante DMI 059B |
| Velocidade da RAM | Configurada em 2.400 MT/s; campo Speed do DMI reporta 2.667 MT/s |
| Limite reportado pelo DMI | 32 GB e 2 posições, ambas ocupadas; não é validação independente de compatibilidade de expansão |
| Memória no sistema | 30 GiB total; 8,5 GiB em uso; 11 GiB livres; 11 GiB buff/cache; 22 GiB disponíveis na coleta |
| Swap | Arquivo /swap.img, 8 GiB; sem uso na coleta |
| Vídeo integrado | Intel UHD Graphics 630 |
| Vídeo dedicado | NVIDIA GeForce GTX 1060 Mobile; VRAM e funcionamento do driver não verificados |
| Rede cabeada | Qualcomm Atheros Killer E2400 Gigabit Ethernet; velocidade negociada e interface em uso não verificadas |
| Wi-Fi | Intel Cannon Lake PCH CNVi WiFi; conexão em uso não verificada |
| Controladoras | Intel HM370 / Cannon Lake; SATA AHCI e USB 3.1 xHCI |

Coleta de 17/09/2026: lscpu confirmou explicitamente os 6 núcleos físicos. Temperaturas não obtidas, pois sensors não está disponível. Nenhum pacote foi instalado.

O lscpu reportou Gather data sampling como Vulnerable e algumas outras entradas com mitigação e ressalva SMT vulnerable. Registrar para futura revisão de segurança/microcódigo; esta saída não comprova exploração, nem constitui auditoria de segurança. Nenhuma atualização de firmware ou alteração de configuração foi realizada.

## Armazenamento

| Dispositivo | Montagem | Capacidade utilizável | Usado | Disponível | Uso |
|---|---|---:|---:|---:|---:|
| `/dev/sda2` | `/` | 233 GiB | 59 GiB | 163 GiB | 27% |
| `/dev/sdb1` | `/mnt/storage` | 916 GiB | 12 GiB | 858 GiB | 2% |
| `/dev/sda1` | `/boot/efi` | 1,1 GiB | 6,4 MiB | 1,1 GiB | 1% |

Dados de espaço de / e /mnt/storage reconfirmados em 17/09/2026; o uso de /boot/efi na tabela é da coleta anterior.

- SSD /dev/sda: TOSHIBA THNSNJ256G8NY, 238,5 GiB reportados, ROTA=0. Partições: sda1 de 1 GiB, FAT, /boot/efi; sda2 de 237,4 GiB, ext4, /.
- HD /dev/sdb: HGST HTS721010A9E630, 931,5 GiB reportados, ROTA=1. Partição sdb1 ext4 em /mnt/storage.
- Os dispositivos loop listados pertencem a pacotes Snap; não são discos físicos adicionais.

### Localização confirmada do banco e regra para alterações

SSH informado pelo usuário: multiverso@192.168.0.4. Container correto do banco do Agenda 24h: supabase-db, banco postgres; não confundir com o container separado postgres.

As consultas e o docker inspect enviados anteriormente nesta sessão confirmaram:

- Dados do Supabase no HD: /mnt/storage/supabase/supabase/docker/volumes/db/data no host, montado em /var/lib/postgresql/data no container.
- SHOW data_directory retorna /var/lib/postgresql/data; somente tablespaces pg_default e pg_global, sem localização externa reportada.
- Configuração adicional do PostgreSQL no SSD: /var/lib/docker/volumes/supabase_db-config/_data, montada em /etc/postgresql-custom.
- Backup manual anterior à estrutura de satisfação no SSD: /home/multiverso/agenda24h-antes-pesquisa-1eeGaN.dump, 514 KB; listagem do arquivo validada, restauração não testada. Não é cópia fora do servidor.

Antes de futuras alterações, confirmar o container, o caminho no host e o disco de destino. Não presumir que todos os arquivos do Docker ou todos os componentes do Supabase estejam no mesmo disco. Nenhum dado foi movido nesta etapa.

### Limites do check-up de hardware

Este levantamento é um inventário, não uma certificação de saúde ou capacidade. Pendentes: SMART/desgaste e erros dos discos; temperaturas e throttling sob carga; teste de RAM; bateria/alimentação e recuperação após queda; desempenho de I/O; velocidade real da rede; uso de CPU e memória dos serviços ao longo do tempo. Nenhuma dessas verificações foi executada nesta coleta.

## Plataforma de containers

| Componente | Versão |
|---|---|
| Docker Engine | 29.7.2 |
| Docker Compose | v5.5.0 |

Rede Docker personalizada encontrada: `multiverso-network`.

Confirmado em 17/09: os 19 containers estão ativos e conectados à multiverso-network (bridge local). Há seis projetos Compose e Portainer sem labels Compose. DockerRootDir=/var/lib/docker, driver overlayfs, logs json-file e cgroups v2. Todos reportam Memory=0 e NanoCPUs=0; outros controles de CPU não foram consultados. Supabase usa restart unless-stopped; os seis containers restantes usam always. Compartilhar rede não comprova integração funcional.

## Serviços ativos

| Serviço | Imagem/versão observada | Estado na coleta | Publicação no host |
|---|---|---|---|
| n8n | `n8nio/n8n:2.36.8` | Ativo há 6 dias | `127.0.0.1:5678` |
| Evolution API | `evoapicloud/evolution-api:latest` | Ativa há 6 dias | `127.0.0.1:8081` |
| Baserow | `baserow/baserow:latest` | Saudável há 6 dias | `127.0.0.1:8000` |
| Redis | `redis:7` | Ativo há 6 dias | `127.0.0.1:6379` |
| PostgreSQL separado | `postgres:16` | Ativo há 6 dias | `127.0.0.1:5432` |
| Portainer | `portainer/portainer-ce:latest` | Ativo há 6 dias | `127.0.0.1:9000` |
| Ollama | serviço no host | Escutando | `127.0.0.1:11434` |
| Supabase | stack self-hosted | Ativa há 6 dias | Ver seção de exposição de rede |

### Componentes do Supabase

- PostgreSQL 15.8.1.085
- Kong 3.9.1
- Studio 2026.04.27-sha-5f60601
- Storage API 1.48.26
- PostgREST 14.8
- GoTrue 2.186.0
- Realtime 2.76.5
- Supavisor 2.7.4
- Edge Runtime 1.71.2
- Analytics/Logflare 1.36.1
- Vector 0.53.0-alpine
- Postgres Meta 0.96.3
- imgproxy 3.30.1

## n8n

| Item | Valor confirmado |
|---|---|
| Container | `n8n` |
| Versão | 2.36.8 |
| Compose | `/home/multiverso/docker/n8n/docker-compose.yml` |
| Banco configurado | PostgreSQL (`DB_TYPE=postgresdb`) |
| Host público | `n8n.multiverso360.com.br` |
| Protocolo público configurado | HTTPS |
| Porta interna | 5678 |
| Fuso horário | `America/Sao_Paulo` |
| Dados persistentes | volume `n8n_n8n_data` em `/home/node/.n8n` |

O container está fixado na versão 2.36.8, o que favorece atualizações controladas. Ainda é necessário confirmar:

- O endereço do banco usado pelo n8n.
- Se ele utiliza o PostgreSQL 16 separado ou o PostgreSQL do Supabase.
- Nome do banco e do usuário, sem registrar a senha.
- Configuração de fila e concorrência.
- Política de retenção das execuções.
- Variáveis de URL externa, proxy e webhooks.
- Criptografia e guarda da chave usada nas credenciais do n8n.
- Estado de saúde real, e não apenas se o processo está ativo.

## Arquivos Docker Compose localizados

- `/home/multiverso/docker/n8n/docker-compose.yml`
- `/home/multiverso/docker/evolution/docker-compose.yml`
- `/home/multiverso/docker/baserow/docker-compose.yml`
- `/home/multiverso/docker/redis/docker-compose.yml`
- `/home/multiverso/docker/postgres/docker-compose.yml`
- `/home/multiverso/docker/stack/docker-compose.yml`
- `/mnt/storage/supabase/supabase/docker/docker-compose.yml`

Em 17/09, compose ls e labels confirmaram os seis arquivos individuais de n8n, evolution, baserow, redis, postgres e supabase. O arquivo stack/docker-compose.yml foi localizado na coleta antiga, mas não aparece como projeto ativo nesta coleta. Portainer não apresenta labels Compose; seu método de criação não está confirmado. Ainda faltam versões sanitizadas dos arquivos, sem segredos, para documentar dependências e permitir reconstrução.

## Persistência dos dados

| Serviço | Persistência observada |
|---|---|
| n8n | volume `n8n_n8n_data` |
| Evolution API | volume `evolution_data` |
| Baserow | volume `baserow_baserow_data` |
| PostgreSQL separado | volume `postgres_postgres_data` |
| Redis | volume Docker com nome automático |
| Portainer | volume `portainer_data` |
| Supabase Database | bind mount em `/mnt/storage/supabase/supabase/docker/volumes/db/data` |
| Supabase Storage | bind mount em `/mnt/storage/supabase/supabase/docker/volumes/storage` |

O Redis está associado ao Compose /home/multiverso/docker/redis/docker-compose.yml e utiliza volume com nome automático. O inventário lógico registra o identificador exato; nenhuma renomeação ou migração foi realizada. Todos os oito volumes locais reportaram caminhos sob /var/lib/docker/volumes no SSD; binds principais do Supabase permanecem no HD.

## Publicação, proxy e domínios

Histórico de publicação de 05/09; em 17/09 apenas o serviço cloudflared ativo e suas portas foram reconfirmados. O usuário informa acesso administrativo pela rede local e autenticação por token; mecanismo e políticas não foram inspecionados. Isso não determina quais aplicações são publicadas pelo túnel.

Não foram encontrados Nginx, Traefik, Certbot ou certificados locais do Let's Encrypt. O acesso externo aparenta ser feito pelo Cloudflare Tunnel. Essa conclusão é uma inferência baseada no serviço ativo e deve ser confirmada pela configuração sanitizada do túnel.

### Cloudflare Tunnel

| Item | Estado |
|---|---|
| Serviço | Ativo e habilitado no systemd |
| Executável | `/usr/local/bin/cloudflared` |
| Arquivo de configuração | `/etc/cloudflared/config.yml` |
| Versão | 2026.5.0 |
| Início observado | 30 de agosto de 2026 |

Os registros informavam que a versão 2026.5.0 estava desatualizada e recomendavam 2026.8.3 na data da coleta. A atualização deve ser planejada e testada, não aplicada automaticamente em produção.

Também apareceram eventos `Incoming request ended abruptly: context canceled` para recursos de telemetria e interface do n8n. Isoladamente, esses eventos não provam indisponibilidade; é necessário correlacioná-los com horário, experiência do usuário e outros registros.

### Domínios encontrados

- `n8n.multiverso360.com.br`
- `evolution.multiverso360.com.br`
- `baserow.multiverso360.com.br`
- `portainer.multiverso360.com.br`
- `supabase.multiverso360.com.br`

## Exposição de rede

Portas abaixo reconfirmadas por docker ps e ss em 17/09/2026. Não foi realizado teste de acesso externo nem inspeção do firewall/roteador.

### Restrito ao próprio servidor

- n8n: `127.0.0.1:5678`
- Evolution API: `127.0.0.1:8081`
- Baserow: `127.0.0.1:8000`
- Portainer: `127.0.0.1:9000`
- Redis: `127.0.0.1:6379`
- PostgreSQL separado: `127.0.0.1:5432`
- Ollama: `127.0.0.1:11434`

Essa configuração reduz a exposição direta e é adequada quando o acesso externo passa pelo túnel.

### Escutando em todas as interfaces

- SSH: porta 22
- Supabase Kong HTTP: porta 8100
- Supabase Kong HTTPS: porta 8444
- Supabase Supavisor/pooler: portas 6543 e 5433

Escutar em `0.0.0.0` ou `[::]` não significa, sozinho, que a porta esteja acessível pela internet. Contudo, permite acesso por interfaces de rede do host, sujeito a firewall e roteador. É necessário verificar UFW/nftables, regras do roteador e necessidade real de cada porta. As portas de banco 5433 e 6543 merecem prioridade.

O SSH e o Fail2Ban estão ativos. Ainda faltam configurações efetivas de autenticação, login de root, jails do Fail2Ban e limitação por rede; serviço ativo não comprova cobertura de proteção. Não houve alteração de segurança.

## Backups e recuperação

Foram encontradas duas rotinas no cron do usuário `multiverso`:

- Backup diário às 03:00: `/home/multiverso/disaster-recovery/scripts/backup_daily.sh`
- Backup semanal aos domingos às 04:00: `/home/multiverso/disaster-recovery/scripts/backup_weekly.sh`

Também foram encontrados registros de backups diários e semanais entre agosto e setembro de 2026, além de uma configuração do rclone. O rclone reportou a versão `1.60.1-DEV`.

Isso confirma que rotinas são disparadas, mas ainda não confirma que os arquivos gerados são íntegros ou restauráveis. Precisamos verificar, sem copiar segredos:

- Quais serviços e volumes entram no backup.
- Onde ficam as cópias locais e remotas.
- Retenção diária, semanal e mensal.
- Criptografia das cópias.
- Resultado e tamanho das últimas execuções.
- Alertas em caso de falha.
- Procedimento de restauração.
- Data do último teste de restauração completo.
- Proteção contra perda simultânea do disco principal e do disco `/mnt/storage`.

## Riscos e prioridades

### Prioridade alta

1. Confirmar firewall e necessidade de exposição das portas 5433 e 6543 do pool de banco.
2. Validar uma restauração de teste dos dados do n8n, PostgreSQL, Supabase e Evolution API.
3. Criar versões sanitizadas dos arquivos Compose para documentar dependências e permitir reconstrução.
4. Identificar com precisão qual banco atende cada aplicação.

### Prioridade média

1. Substituir gradualmente etiquetas `latest` por versões fixas na Evolution API, Baserow e Portainer.
2. Planejar atualização do `cloudflared` após revisar notas e compatibilidade.
3. Confirmar regras de SSH e proteção do acesso administrativo.
4. Testar saúde funcional e recuperação; políticas de reinício já inventariadas em 17/09, Memory e NanoCPUs sem limites definidos nesses campos. Outros controles e rotação dos logs permanecem pendentes.
5. Revisar acesso ao socket Docker pelo Portainer e pelo Vector.

### Prioridade operacional

1. Medir consumo de CPU, memória e disco ao longo do tempo.
2. Criar alertas para indisponibilidade, disco cheio e falha de backup.
3. Documentar ordem de inicialização e recuperação após queda de energia.
4. Verificar estado dos discos por SMART e temperatura do equipamento.

## Informações ainda necessárias

- Configuração sanitizada de cada arquivo Docker Compose.
- Configuração sanitizada do Cloudflare Tunnel.
- Regras do firewall do Ubuntu.
- Relação funcional entre aplicações e bancos; associação à rede e políticas de reinício já confirmadas em 17/09.
- Últimas linhas dos logs de backup e seus códigos de saída.
- Lista dos artefatos produzidos pelos backups, com tamanhos e datas.
- Inventário dos workflows do n8n.
- Configurações funcionais da Evolution API, sem chaves ou dados pessoais.
- Tabelas e políticas do Supabase utilizadas pelo Agenda 24h.
- Dependências do Baserow e sua função atual no produto.
- Política de atualização de imagens e plano de reversão.

## Origem da informação

Inventário inicial coletado pelo usuário com comandos de consulta do sistema, Docker e systemd em 5 de setembro de 2026. Atualização de hardware de 17/09/2026: hostnamectl, uname, lscpu, free, swapon, dmidecode, lsblk, df e lspci, conforme anexo enviado pelo usuário. O assistente não acessou diretamente o servidor. Machine ID, Boot ID e outros identificadores desnecessários da saída bruta não foram reproduzidos. Resultados de memória e espaço são uma fotografia do momento, não monitoramento contínuo.
