# Cobrança e planos

## Canal presencial — 14 de setembro de 2026

O responsável pretende receber pela InfinitePay e preencher o [onboarding no iPad](../provisionamento/onboarding-presencial-ipad.md) junto com o cliente. A autorização da recorrência e seu vínculo com a venda presencial ainda precisam ser validados na plataforma. O pagamento presencial deverá ser conferido pelo responsável na InfinitePay; as exigências de webhook Stripe abaixo se aplicam ao canal online. Não foi confirmada a retirada do Stripe desse canal nem alteração dos preços dos planos.

## Modelo comercial confirmado

O cliente do Agenda 24h pagará duas cobranças:

1. **Implantação:** taxa única de R$ 300.
2. **Manutenção do serviço:** assinatura mensal, com valor definido pelo plano contratado.

A implantação cobre a preparação inicial do cliente. A mensalidade mantém o uso e a operação contínua do Agenda 24h.

## Planos confirmados

| Plano | Mensalidade | Limite de profissionais |
|---|---:|---:|
| Solo | R$ 99 | 1 |
| Equipe | R$ 149 | Até 5 |
| Empresa | R$ 199 | Até 15 |

Os planos se diferenciam somente pela quantidade de profissionais. O plano Empresa não será anunciado como ilimitado; a landing page futura deverá informar claramente o limite de 15 profissionais.

## Reembolso da implantação

Foi definida uma janela de 7 dias contados desde o pagamento da assinatura na plataforma Stripe. Dentro dessa janela, o reembolso será integral sobre o valor pago na contratação. O procedimento de encerramento e exclusão dos dados ainda precisa ser definido. A redação final deverá ser revisada juridicamente antes da venda.

## Estrutura prevista no Stripe

Para o modelo comercial confirmado, a estrutura recomendada é:

- um produto/preço de cobrança única para a implantação de R$ 300;
- um produto separado para cada plano comercial;
- um preço mensal recorrente associado a cada plano;
- Stripe Checkout para a contratação;
- Stripe Billing para a assinatura, renovação, novas tentativas de cobrança e estado da mensalidade.

Planos diferentes não devem ser representados apenas por preços diferentes dentro de um único produto genérico. Cada plano deve ter identidade própria para aparecer claramente no Checkout, nas faturas e no portal de cobrança.

A forma exata de apresentar a taxa de implantação e a primeira mensalidade no Checkout ainda será definida. Elas poderão compor a cobrança inicial, desde que continuem registradas separadamente.

## Relação com a ativação

O redirecionamento após o Checkout não comprova pagamento. A ativação dependerá de evento oficial do Stripe recebido por webhook com assinatura validada.

Para ativar uma empresa, deverão existir:

- taxa de implantação paga;
- primeira mensalidade no estado aceito;
- onboarding completo;
- provisionamento revisado e aprovado;
- workflow e instância testados.

## Estados comerciais necessários

O Agenda 24h deverá distinguir pelo menos:

- aguardando pagamento;
- pagamento inicial confirmado;
- assinatura ativa;
- pagamento em processamento;
- pagamento atrasado;
- em período de tolerância;
- suspenso por inadimplência;
- cancelamento programado;
- assinatura cancelada.

O estado comercial não deve ser misturado com o estado técnico do provisionamento.

## Pendências comerciais

- dia ou ciclo da cobrança mensal;
- existência de período de teste;
- procedimento operacional, encerramento de conta e redação final da política de reembolso em 7 dias;
- quantidade de dias de tolerância após falha de pagamento;
- número e canais das notificações de cobrança;
- momento da suspensão do WhatsApp e do workflow;
- comportamento em caso de cancelamento;
- período de retenção dos dados depois do encerramento;
- possibilidade de reativar o mesmo cliente sem nova implantação;
- regras para troca de plano e cobrança proporcional.

## Alteração de plano pelo portal — atualização de 17/09/2026

Recapitulação mais recente: solicitações de troca de plano serão encaminhadas ao responsável para troca manual nesta etapa, enquanto ele se familiariza com a plataforma de pagamentos. Aviso por EmailJS; admin recebe somente retorno na página com prazo de até 24 horas, sem acompanhamento detalhado agora. Não automatizar cobrança nem aplicar novo limite ao receber o pedido. Essa decisão prevalece sobre a previsão de acompanhamento abaixo; detalhes em solicitacoes-administrativas-portal.md.

O administrador terá uma aba Upgrade de plano (nome provisório) para solicitar aumento/redução do plano contratado. O responsável pela plataforma analisa, aprova e efetiva; não haverá troca automática ao enviar ou aprovar o pedido. O portal acompanha situação e resultado, distinguindo aprovação de efetivação. Gestão por solicitação de profissionais vem primeiro; alteração de plano depois da definição das regras comerciais e pagamento. [Fluxo aprovado](../documentacao/solicitacoes-administrativas-portal.md). As referências a Stripe neste documento não resolvem a escolha de pagamento ainda pendente nesta etapa.

Antes de disponibilizá-la, deverão ser definidas as regras de cobrança, início de vigência, diferença proporcional de valor e aplicação do novo limite, incluindo como tratar profissionais acima da capacidade em uma redução. Não presumir exclusão automática de profissionais ou agendamentos. Essas definições não bloqueiam o provisionamento atual.

## Regras de segurança e operação

- validar a assinatura de todos os webhooks do Stripe;
- processar eventos de forma idempotente para não ativar, suspender ou cobrar duas vezes;
- usar credencial restrita com apenas as permissões necessárias sempre que possível;
- manter credenciais de teste separadas das credenciais de produção;
- não colocar chaves em workflows exportados, documentação, página de onboarding ou EmailJS;
- não apagar dados imediatamente por atraso ou cancelamento;
- suspender de forma reversível conforme a política comercial que ainda será definida.

## Questão fiscal

Antes das primeiras cobranças reais, o tratamento fiscal da implantação e da mensalidade deve ser confirmado com o profissional contábil responsável. Ativar cálculo automático de tributos no Stripe, por si só, não cria registros fiscais nem garante recolhimento correto.
