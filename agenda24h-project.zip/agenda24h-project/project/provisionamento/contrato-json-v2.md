# Contrato de provisionamento V2

O provisionamento recebe somente dados já revisados manualmente. Ele não usa `tag`, tabelas antigas, senhas próprias nem serviços duplicados por profissional.

## Ordem segura do workflow

1. Validar e normalizar o JSON V2.
2. Conferir se o plano existe e comporta a quantidade de profissionais.
3. Criar os usuários do administrador e dos profissionais com acesso ao portal no Supabase Auth, sem senha no JSON e sem enviar e-mail ainda.
4. Chamar a RPC transacional que cria empresa, configurações, horários, catálogo, vínculos serviço-profissional, conteúdos e membros da empresa.
5. Se a RPC falhar, remover os usuários Auth criados nesta execução.
6. Se a RPC funcionar, disparar o e-mail oficial de recuperação do Supabase para cada acesso definir sua própria senha.
7. Deixar a empresa em `em_validacao`; só depois dos testes ela passa a `ativo`.

Isso evita que um cliente receba um link de acesso antes de sua empresa existir corretamente no banco.

## Dados obrigatórios novos

- `empresa.codigo`, `empresa.nome_fantasia`, `empresa.whatsapp_numero`, `empresa.instancia_evolution`;
- `plano_codigo`: `solo` (Solo), `equipe` (Equipe) ou `empresa` (Empresa);
- `admin.nome` e `admin.email`;
- `profissionais[].acesso_portal`: somente quem realmente acessará o portal recebe `true`; para esses, `email` é obrigatório;
- catálogo único de `servicos`;
- relação `profissional_servicos` por ID lógico do JSON;
- horários da empresa e horários de cada profissional.

Os nomes e códigos oficiais são Solo (`solo`), Equipe (`equipe`) e Empresa (`empresa`). Os limites continuam em 1, 5 e 15 profissionais, respectivamente.

### Atualização dos pacotes em instalações existentes

1. Pausar o workflow de provisionamento no n8n e aguardar as execuções em andamento terminarem.
2. Aplicar `supabase/migrations/202609160015_renomear_planos.sql` no Supabase. A migração atualiza os registros existentes sem trocar seus IDs, preços, limites ou vínculos de assinaturas.
3. Atualizar o workflow com `workflows-n8n/Provisionamento de Cliente V2 - JSON Estruturado.json` e ajustar quaisquer formulários ou payloads salvos para os novos códigos.
4. Conferir o catálogo com a consulta abaixo, validar o provisionamento em ambiente de teste e reativar o workflow.

```sql
select codigo, nome, limite_profissionais, valor_mensal
from public.planos
where codigo in ('solo', 'equipe', 'empresa')
order by limite_profissionais;
```

Resultado esperado: `solo` / Solo / 1 / 99.00; `equipe` / Equipe / 5 / 149.00; `empresa` / Empresa / 15 / 199.00. Os códigos antigos deixam de ser aceitos pelo workflow atualizado. As migrations anteriores e auditorias históricas mantêm os nomes usados na época.

`portal_redirect_url` é opcional. Se informado, deve ser uma URL previamente permitida no Supabase e levar à tela em que o usuário escolhe uma nova senha.

## Dados que não entram mais

- `tag`;
- `usuarios_portal`, `senha_hash`, `senha_temporaria`, `usuario_id` manual ou sessões próprias;
- serviços inseridos dentro de cada profissional;
- arrays genéricos de dias e um único intervalo diário;
- preço mínimo/máximo.

## Configuração antes de ativar

O n8n precisa receber a chave de serviço do Supabase por variável de ambiente protegida do **próprio container n8n**. A variável existente somente no container Supabase não é compartilhada automaticamente. O workflow deve enviar dois headers: `apikey` com a chave de serviço e `Authorization` no formato `Bearer <chave>`. A chave nunca é salva no JSON, nos campos do workflow, na documentação ou nos logs.

A URL pública configurada para a API é `https://supabase.multiverso360.com.br`. A URL antiga `http://localhost:8000` não deve ser usada pelos workflows: ela era uma configuração incorreta exibida pelo painel e não funciona entre containers Docker separados.

O primeiro teste parou com `401 No API key found in request`; isso confirma que o gateway ainda não recebeu o header `apikey`. Não houve criação de empresa nem de usuário Auth nessa tentativa.

Configure também o SMTP do Supabase antes de provisionar empresas reais. O provedor de e-mail padrão possui limite muito baixo para e-mails de autenticação; o workflow envia um link de definição de senha para cada pessoa com acesso ao portal.

## Autenticação

O Supabase Auth cria e recupera senhas. O banco público recebe apenas `usuario_id`, retornado pelo Auth. O administrador e um profissional continuam sendo papéis distintos em `membros_empresa`; um profissional só recebe conta de portal quando `acesso_portal` for `true`.
