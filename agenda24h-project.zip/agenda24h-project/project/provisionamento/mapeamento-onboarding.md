# Mapeamento do onboarding

Atualizado em 7 de setembro de 2026.

## Decisão técnica recomendada

Os dados do onboarding não devem ser colocados todos diretamente em um único system prompt. A arquitetura recomendada usa cada camada para sua finalidade:

- **Pasta offline:** cópia bruta e administrativa do formulário recebido.
- **Supabase:** fonte oficial e estruturada das configurações usadas pelo sistema.
- **System prompt:** instruções de comportamento e informações conversacionais carregadas a partir do Supabase.
- **Tools compartilhadas:** aplicação obrigatória das regras transacionais usando dados do Supabase.
- **Redis:** memória temporária da conversa, nunca fonte oficial das configurações.

A pasta offline não deve ser consultada durante o atendimento. Se o servidor depender de arquivos manuais para responder, o sistema ficará difícil de atualizar, validar e escalar.

## Distribuição dos dados

| Informação do onboarding | Supabase | System prompt | Tool/workflow |
|---|---|---|---|
| Nome, ramo e apresentação da empresa | Fonte oficial | Sim, para apresentação | Identificação da empresa |
| Persona, tom de voz e nome da assistente | Fonte oficial e versionada | Sim | Não aplica regra transacional |
| FAQ, políticas e restrições | Fonte oficial | Sim, em versão controlada | Pode validar quando necessário |
| Serviços e descrições | Tabelas estruturadas | Resumo opcional | Consulta oficial |
| Preço e duração | Campos estruturados | Pode explicar | Tool consulta e usa o valor real |
| Profissionais | Tabela estruturada | Pode apresentar | Tool consulta profissionais ativos |
| Relação serviço-profissional | Tabela de relacionamento | Não confiar no texto | Tool filtra profissionais habilitados |
| Dias e horários de trabalho | Campos/tabelas estruturados | Pode explicar | Tool calcula disponibilidade |
| Antecedência mínima | Configuração numérica | Pode explicar | Tool bloqueia horário inválido |
| Buffer após atendimento | Configuração numérica | Pode explicar | Tool calcula ocupação |
| Prazo de cancelamento/remarcação | Configuração numérica | Pode explicar | Tool permite ou recusa a ação |
| Número reserva | Configuração protegida da empresa | Pode orientar | Workflow encaminha quando aplicável |
| Prazo de reativação | Configuração do serviço | Não precisa decidir | Workflow compartilhado calcula |
| Mensagens de lembrete e reativação | Modelos versionados | Não é obrigatório | Workflows compartilhados enviam |

## Fluxo recomendado

1. Cliente preenche o onboarding.
2. O responsável guarda a cópia bruta em local offline protegido.
3. O responsável revisa e normaliza os dados.
4. O workflow de provisionamento grava as informações estruturadas no Supabase.
5. O workflow principal identifica a empresa pela instância Evolution.
6. Antes de chamar a IA, carrega do Supabase a versão ativa da persona, FAQ, políticas e restrições.
7. O system prompt é composto com o modelo-base e os dados conversacionais da empresa.
8. Quando houver operação de agenda, a tool consulta novamente as regras estruturadas no Supabase.

## Princípio de segurança

O system prompt ajuda a IA a conversar, mas não garante integridade. Nenhum preço, disponibilidade, profissional, antecedência, buffer, cancelamento ou remarcação será aceito apenas porque o modelo afirmou que é válido.

## Validação pendente

Essa arquitetura deve ser comparada com a página de onboarding e com os workflows que serão enviados. Depois dessa análise, será possível definir campos, tabelas, expressões e nodes exatos sem duplicar informações.
