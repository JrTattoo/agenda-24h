# Onboarding presencial no iPad

## Arquivo escolhido — 21 de setembro de 2026

O responsável forneceu o arquivo [onboarding-agenda24h.html](onboarding-ipad/onboarding-agenda24h.html) e confirmou que esta é a versão que usará. O arquivo foi incorporado ao projeto sem alterações no conteúdo. Ainda necessita de ajustes, inclusive na interface; esses ajustes não foram solicitados nesta inclusão e serão definidos posteriormente. As propostas históricas abaixo não constituem autorização para modificar o arquivo.

Prioridade reafirmada em 17/09/2026: manter onboarding manual assistido enquanto o volume for pequeno. Automação completa virá conforme crescimento da carteira, sem prazo definido e fora da prioridade atual. Para alterações de equipe, o método 1 seguirá revisão e execução pelo responsável em processo próprio do n8n; ver [solicitações do portal](../documentacao/solicitacoes-administrativas-portal.md).

## Atualização dos pacotes — 16 de setembro de 2026

O responsável confirmou a aplicação da atualização dos pacotes no Supabase local, no workflow de provisionamento V4 e na página de onboarding manual/presencial: Solo (`solo`), Equipe (`equipe`) e Empresa (`empresa`). Um teste integrado após as alterações ainda não foi apresentado nesta conversa. A atualização da lógica dos pacotes na página online permanece pendente e será tratada junto com outras alterações que ainda serão definidas pelo responsável.

Atualizado em 14 de setembro de 2026.

## Direção confirmada

O responsável fará vendas presenciais e usará o iPad para demonstrar o produto e preencher o onboarding junto com o cliente. O cadastro não deve depender de o cliente acessar sozinho o site após a compra. A página deverá permitir salvar um arquivo no iPad para revisão e provisionamento manual posterior.

A InfinitePay é a plataforma pretendida para o recebimento presencial e a recorrência. Isso acrescenta um caminho presencial; não confirma a retirada do Stripe do caminho online.

## Fluxo proposto

1. Demonstrar o produto e definir o plano.
2. Receber o pagamento e conferir separadamente a configuração da recorrência na plataforma de cobrança.
3. Preencher o onboarding junto com o cliente no iPad.
4. Revisar um resumo e salvar o arquivo no app Arquivos, em uma pasta de “No Meu iPad”.
5. Transferir o arquivo para a pasta local protegida do responsável quando for realizar o provisionamento.
6. Revisar o cadastro, conferir o pagamento na plataforma e completar os dados técnicos, como o nome da instância Evolution.
7. Fornecer o JSON V2 revisado ao workflow existente. A empresa continua em validação até a conclusão dos testes e aprovação manual.

Salvar no iPad não significa executar o n8n ou o Supabase localmente nele. O arquivo é a entrada para o provisionamento posterior.

## Escopo proposto para a página

- Formulário confortável para toque, dividido em empresa/responsável, plano, profissionais, serviços, vínculos, horários e regras de atendimento.
- Horários com múltiplos intervalos por dia, permitindo representar almoço e jornadas diferentes por profissional.
- Resumo antes de exportar e identificação clara de campos incompletos.
- Exportação e reabertura de rascunhos para continuar o cadastro.
- Exportação do JSON de provisionamento conforme o [contrato V2](contrato-json-v2.md), somente após validar os campos obrigatórios, vínculos e limite de profissionais do plano.
- Registro administrativo da origem presencial, referência da venda e referência da recorrência separado do JSON técnico. Esses dados não comprovam pagamento por si só.
- Botão para limpar o cadastro antes de demonstrar o produto ou atender outro cliente.
- Sem credenciais de pagamento, senhas ou chaves de serviço no navegador ou nos arquivos.

O formulário bruto pode conter informações ainda incompletas; não deve ser apresentado como um JSON pronto para executar no workflow. Exportar o cadastro não ativa a empresa.

## iPad e armazenamento

O Safari permite configurar os downloads para “No Meu iPad”. A página deve oferecer uma ação explícita para baixar/compartilhar o arquivo; não deve prometer escrever silenciosamente em uma pasta escolhida. A exportação precisa ser testada no iPad real.

Fonte: [Personalize os ajustes do Safari no iPad — Apple](https://support.apple.com/pt-br/guide/ipad/ipad54f3cde6/ipados).

Não usar iCloud Drive ou a pasta deste projeto, sincronizada pelo OneDrive, para o arquivo bruto se o objetivo continua sendo armazenamento local e offline. Não guardar cadastros reais na documentação do projeto.

Funcionamento da página sem internet é um requisito separado de salvar o arquivo localmente e ainda precisa ser definido e implementado.

## Recorrência InfinitePay: ponto a validar

A central oficial informa que planos e cobranças recorrentes podem enviar links periódicos. O débito automático no cartão depende de autorização do cliente na tela de pagamento, quando disponível. A documentação consultada não confirma que a venda na maquininha, sozinha, configure essa autorização.

Antes de adotar esse procedimento comercial, validar no produto disponível na conta a etapa de autorização e como identificar a assinatura. Uma venda paga e uma recorrência autorizada são verificações distintas.

Fonte consultada em 14/09/2026: [Planos e Recorrências — InfinitePay](https://ajuda.infinitepay.io/pt-BR/articles/9232324-como-automatizar-cobrancas-com-o-planos-e-recorrencias).

## Situação da implementação

O arquivo HTML escolhido pelo responsável está disponível em [onboarding-ipad/onboarding-agenda24h.html](onboarding-ipad/onboarding-agenda24h.html). Sua inclusão em 21/09/2026 substitui o registro anterior de ausência de código. Nesta etapa foi conferida apenas a integridade da cópia; não foram executados testes funcionais, alterações de interface ou publicação.
