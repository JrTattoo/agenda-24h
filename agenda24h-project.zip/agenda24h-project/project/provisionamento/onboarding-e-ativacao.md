# Provisionamento — onboarding e ativação

## Prioridade confirmada — 17 de setembro de 2026

Enquanto a carteira for pequena, onboarding e alterações do quadro de profissionais permanecem sob revisão e execução manual assistida pelo responsável, usando processos internos do n8n. Onboarding automático ponta a ponta é evolução futura conforme crescimento, não prioridade atual. Isso não impede validação e uso das automações auxiliares existentes. Alterações de empresa existente terão processo próprio, conforme [método 1 aprovado](../documentacao/solicitacoes-administrativas-portal.md), sem reutilizar a RPC de criação de empresa para editar cadastros.

## Atualização — 14 de setembro de 2026

Foi acrescentado o [onboarding presencial no iPad](onboarding-presencial-ipad.md): o responsável preenche o cadastro junto com o cliente e salva um arquivo local para revisão e provisionamento posterior. A InfinitePay é a plataforma pretendida para esse canal, com o procedimento de autorização da recorrência ainda a validar. As referências a Stripe e redirecionamento abaixo descrevem o caminho online; não são pré-requisitos para abrir o formulário presencial. No canal presencial, o responsável deverá conferir pagamento e recorrência na plataforma antes da ativação.

## Estado

- **Confirmado:** o fluxo inicial será parcialmente automatizado e parcialmente manual.
- **Confirmado:** o workflow principal de cada empresa será clonado e configurado manualmente pelo responsável.
- **Confirmado:** haverá taxa única de implantação de R$ 300 e mensalidade recorrente conforme o plano.
- **Confirmado:** a instância Evolution será criada manualmente no MVP.
- **Confirmado:** os dados brutos do onboarding serão mantidos em uma pasta local e offline sob controle do responsável.
- **Pendente:** definir os campos exatos do formulário de onboarding.
- **Adiado para etapa posterior:** uma automação integrada entre Stripe e Gmail acompanhará pagamento, onboarding e a notificação ao responsável. Ela não faz parte da construção atual; o foco imediato é criar o Supabase V2 e adaptar os workflows para o novo contrato do banco.
- **Implementado no banco:** a RPC `provisionar_empresa_v2` cria, em uma transação, a empresa, configurações, assinatura manual, administrador, profissionais, serviços, vínculos e horários.
- **Em validação no n8n:** o workflow V2 cria usuários pelo Supabase Auth antes da RPC e envia recuperação de senha somente depois do provisionamento concluído. A ligação segura entre o container n8n e a chave de serviço ainda está pendente de confirmação.
- **Não usar:** o workflow antigo, tabelas legadas, senhas próprias, `senha_hash` e IDs Auth inseridos manualmente.

## Objetivo

Transformar uma compra confirmada em uma empresa configurada no Agenda 24h, com seus dados, serviços, profissionais, agenda, personalidade, regras e workflow principal próprio.

## Fluxo confirmado para a primeira versão

1. O cliente realiza a compra pelo Stripe.
2. Após a compra, o cliente é direcionado para a página de onboarding.
3. O cliente preenche os dados necessários da empresa.
4. Uma notificação é enviada ao responsável pelo projeto usando EmailJS.
5. O responsável revisa e separa os dados necessários para o provisionamento.
6. O responsável inicia manualmente o workflow de provisionamento no n8n e fornece os dados revisados.
7. O workflow cria no Supabase os registros da nova empresa e suas configurações iniciais.
8. O responsável clona manualmente o modelo oficial do workflow principal.
9. O responsável configura manualmente essa cópia para a empresa.
10. O responsável cria manualmente uma instância individual da Evolution API e a vincula ao número de WhatsApp da empresa.
11. O workflow individual é vinculado à instância correta, às tools compartilhadas e aos componentes compartilhados de lembretes e reativação.
12. O responsável executa a conferência e os testes de ativação.
13. Somente depois da aprovação manual a empresa passa ao estado `ativo`.

## Divisão de responsabilidades

### Stripe

- cobrar e registrar a implantação única de R$ 300;
- criar e manter a assinatura mensal conforme o plano contratado;
- identificar o comprador e a transação ou assinatura;
- enviar ao sistema um evento oficial de pagamento;
- direcionar o comprador para o onboarding.

### Página de onboarding

- coletar somente os dados necessários para configurar o Agenda 24h;
- vincular o formulário ao comprador correto;
- validar campos obrigatórios;
- registrar o envio do formulário.

### EmailJS

- avisar o responsável de que existe um onboarding aguardando revisão;
- não ser a fonte oficial dos dados nem a prova de pagamento.

### Responsável pelo projeto

- revisar as informações;
- corrigir dados inconsistentes com o cliente, quando necessário;
- iniciar o provisionamento manual;
- clonar o modelo oficial do workflow principal;
- configurar empresa, instância, credenciais e vínculos na cópia;
- criar manualmente a instância Evolution;
- executar a lista de verificação e os testes de ativação;
- realizar a conferência final.

### Workflow de provisionamento no n8n

- validar os dados recebidos;
- criar ou atualizar a empresa no Supabase;
- cadastrar configurações, serviços, profissionais e horários;
- gerar identificadores internos;
- registrar os dados necessários para o vínculo entre empresa, instância, número, workflow e tools compartilhadas;
- registrar cada etapa e qualquer falha;
- poder ser executado novamente sem duplicar a empresa ou seus dados.

## Criação manual do workflow principal

A criação manual é uma decisão consciente para a primeira fase. O objetivo é observar cada provisionamento, identificar variações e impedir que uma automação ainda não validada publique configurações incorretas.

### Lista mínima de verificação

- confirmar que a cópia veio da versão oficial mais recente do modelo;
- usar um nome padronizado que identifique a empresa e a versão;
- configurar o identificador interno da empresa;
- vincular somente a instância Evolution daquela empresa;
- conferir credenciais sem copiar segredos para campos visíveis;
- conectar as versões oficiais das tools compartilhadas;
- confirmar que lembretes e reativação reconhecem o novo contratante;
- validar prompt, personalidade, regras e informações do estabelecimento;
- testar texto e áudio;
- confirmar que imagens e vídeos recebem a orientação de formato não suportado sem serem analisados;
- testar consulta de serviços, profissionais e disponibilidade;
- criar, consultar, reagendar e cancelar um agendamento de teste;
- testar mensagem manual do profissional e pausa da IA;
- verificar se dados de outra empresa nunca aparecem;
- registrar quem ativou, quando ativou e qual versão foi usada;
- ativar o workflow somente depois de todos os testes passarem.

### Controle de versões

Mesmo com cópias manuais, deve existir um único workflow marcado como **modelo oficial**. Ele não atende clientes diretamente. Cada workflow de cliente deve registrar a versão do modelo que originou a cópia, permitindo saber quais empresas precisam receber uma correção futura.

A automação dessa etapa poderá ser considerada somente depois que o processo manual estiver estável e repetível.

## Regras obrigatórias

### Confirmação de pagamento

O redirecionamento do navegador após o Checkout não deve, sozinho, autorizar a ativação. O sistema deve receber e validar um webhook oficial do Stripe, incluindo a assinatura do evento, e registrar o estado do pagamento no banco.

O provisionamento somente poderá concluir a ativação quando existirem:

- pagamento ou assinatura no estado aceito;
- formulário de onboarding completo;
- revisão manual aprovada;
- dados mínimos válidos.

### Vínculo entre compra e onboarding

Cada formulário deve ser vinculado de forma segura ao cliente e à compra ou assinatura do Stripe. Nome e e-mail sozinhos não são identificadores suficientes.

Devem ser preservados, conforme o tipo de cobrança:

- identificador do cliente no Stripe;
- identificador da sessão de Checkout;
- identificador da assinatura, quando existir;
- identificador do plano/preço contratado;
- identificador interno da empresa no Agenda 24h.

### Prevenção de duplicidade

O workflow deve ser idempotente: repetir a mesma solicitação não pode cadastrar a empresa, os profissionais ou os serviços duas vezes.

### Estados do provisionamento

Cada solicitação deve ter um estado rastreável:

- pagamento pendente;
- aguardando onboarding;
- onboarding recebido;
- em revisão;
- aprovado para provisionamento;
- provisionando;
- ativo;
- falhou;
- cancelado.

### Segurança

- verificar a assinatura dos webhooks do Stripe antes de processá-los;
- guardar chaves e segredos fora de workflows exportados, código e documentação;
- preferir uma chave restrita do Stripe, com apenas as permissões necessárias;
- não enviar credenciais, chaves ou dados sensíveis pelo EmailJS;
- não registrar segredos nos logs do n8n;
- usar ambientes e credenciais separados para teste e produção.

## Campos previstos para o onboarding

Esta lista é uma proposta e ainda precisa ser confirmada:

- responsável, contato e dados básicos da empresa;
- nome comercial, ramo, endereço e fuso horário;
- telefone que será conectado ao WhatsApp;
- serviços, descrições, preços, duração e prazo de reativação;
- profissionais e quais serviços cada um realiza;
- horários de trabalho, intervalos, folgas e bloqueios;
- regras de agendamento, antecedência, cancelamento e remarcação;
- perguntas frequentes, políticas e restrições;
- personalidade, tom de voz e apresentação da IA;
- mensagens de confirmação, lembrete e reativação;
- regras e contato para transferência humana;
- número reserva para encaminhamento de cancelamentos e remarcações bloqueados nas últimas 24 horas;
- autorização e preferências relacionadas ao tratamento de dados.

O destino recomendado de cada campo está documentado em [Mapeamento do onboarding](mapeamento-onboarding.md). Em resumo, o Supabase guarda os dados oficiais, o system prompt recebe somente o conteúdo conversacional e as tools aplicam as regras de agenda.

## Armazenamento local do onboarding

Os dados recebidos serão organizados em uma pasta local e offline. A localização, o formato, a criptografia, o controle de acesso, o backup e o prazo de exclusão ainda precisam ser definidos.

Essa pasta não deve ficar dentro deste projeto, que está em uma área sincronizada pelo OneDrive. A documentação oficial não deverá conter nomes, telefones, credenciais ou formulários reais de clientes.

## Melhorias posteriores

Depois que o fluxo manual estiver validado, poderão ser automatizadas:

- integração Stripe + Gmail para acompanhar pagamento, onboarding e avisos ao responsável;
- leitura direta dos dados do onboarding pelo workflow;
- validação automática dos campos;
- criação automática do contratante após aprovação;
- envio de confirmação e instruções de ativação;
- acompanhamento do estado do provisionamento pelo cliente;
- suspensão ou reativação conforme o estado da assinatura.

O processo manual será mantido no MVP como uma etapa de controle e aprendizado, não como dependência permanente para escalar.
