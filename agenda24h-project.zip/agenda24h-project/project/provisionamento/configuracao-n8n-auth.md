# Preparação do n8n para o provisionamento V2

Faça esta configuração uma vez, antes de importar e ativar o workflow.

1. No Supabase, abra **Settings → API Keys** e crie ou copie a chave secreta `sb_secret_...`. Não use a chave pública.
2. No ambiente protegido do n8n, registre duas variáveis:
   - `SUPABASE_URL`: a URL do projeto, terminando em `.supabase.co`;
   - `SUPABASE_SECRET_KEY`: a chave secreta do passo anterior.
3. No Supabase, abra **Authentication → URL Configuration**. Inclua a URL da futura tela de definição de senha em **Redirect URLs**. Enquanto o portal não existir, deixe `portal_redirect_url` fora do JSON; o link usará a URL principal definida no projeto.
4. No Supabase, configure o SMTP antes de cadastrar empresas reais. O envio padrão do Supabase é muito limitado para e-mails de autenticação.
5. Importe o workflow `Provisionamento de Cliente V2 - Auth e JSON Estruturado.json` e atribua a conexão PostgreSQL que já possui acesso de serviço ao projeto.
6. Antes de ativar, execute um teste com o arquivo `exemplo-json-v2.json`, usando e-mails seus de teste e um código de empresa que nunca será usado em produção.

## Resultado esperado do teste

- uma empresa fica com status `em_validacao`;
- o administrador e somente os profissionais com `acesso_portal: true` são criados no Auth;
- os dados da empresa, serviços, horários e vínculos surgem juntos;
- cada acesso recebe um e-mail para criar sua senha;
- se a inserção no banco falhar, os usuários criados na tentativa são removidos.

## Não faça

- não cole a chave secreta em um nó, expressão, JSON do cliente ou planilha;
- não crie senha temporária no onboarding;
- não ative o workflow antes de configurar SMTP e testar com uma empresa fictícia.
