# JSON de alteração de equipe e serviços

Modelo preparado em 17/09/2026 a partir de contrato-json-v2.md e exemplo-json-v2.json deste projeto. O código da página original de onboarding e um email real recebido não estavam disponíveis nesta inspeção. Compatibilidade com o envelope exato do EmailJS ainda precisa ser conferida. Não é o payload da RPC provisionar_empresa_v2.

Exemplo fictício: exemplo-json-alteracao-equipe-v1.json. Não executar contra produção. Os UUIDs são ilustrativos.

## Padrão compartilhado com onboarding

Reutiliza snake_case, empresa.nome_fantasia, admin.nome/email, plano_codigo e arrays profissionais, servicos, profissional_servicos, horarios_profissionais. Profissionais usam chave, acesso_portal, cor_agenda e ativo. Serviços usam duracao_min, preco e demais campos do catálogo V2. Vínculos usam profissional_chave/servico_chave. Horários usam dia_semana, inicio e fim, permitindo múltiplos intervalos por dia (0 domingo a 6 sábado).

Não aninhar serviços e horários dentro do cadastro de cada profissional. Não enviar especialidade, servicoIds, duracaoMinutos, diaSemana, horaInicio, horaFim ou intervaloMinutos como substitutos dos campos do contrato V2.

## Semântica de alteração, não substituição integral

- profissionais e servicos contêm somente cadastros NOVOS propostos. Registros existentes são identificados por UUID em referencias_existentes e por chave lógica nas operações.
- As chaves são únicas dentro de cada categoria, abrangendo novos e existentes. Referências não podem ficar sem destino.
- alteracoes.profissionais_incluir lista chaves de novos profissionais adicionados sem substituição.
- profissionais_remover lista chaves existentes a desativar. Não exclusão física.
- profissionais_substituir liga uma chave existente à chave de um novo cadastro. O novo aparece em profissionais, mas NÃO novamente em profissionais_incluir. O antigo NÃO aparece novamente em profissionais_remover.
- servicos_incluir lista exatamente os novos serviços; servicos_remover lista existentes com remoção solicitada. A execução deve preservar histórico e resolver impactos, não apagar reservas silenciosamente.
- vinculos_desvincular recebe objetos com profissional_chave e servico_chave existentes. profissional_servicos expressa adições de vínculos; não substitui globalmente os vínculos existentes.
- horarios_profissionais nesta versão descreve horários dos profissionais novos. Edição de horários de existentes exige contrato adicional explícito, não deve ser inferida da ausência de intervalos.
- Tudo que não consta nas operações permanece inalterado. Array vazio nunca significa apagar todos.
- O exemplo mantém ocupação 3: sai um, entra um. Há inclusão de serviço novo e remoção solicitada de serviço antigo; as duas outras pessoas da empresa não precisam ser reenviadas.
- plano_codigo e ocupacao_informativa são fotografia para revisão, não comando de mudança de plano nem fonte confiável do limite. Troca de plano segue solicitação manual separada.
- Não enviar configuracoes, conteudos, horarios_empresa, dados de pagamento, senhas ou credenciais: fora deste escopo.

## Validação e envio

Validar campos conforme onboarding; email obrigatório quando acesso_portal=true; preço não negativo, duração positiva, intervalos válidos e capacidade resultante. Não criar valores comerciais automaticamente. Valores do exemplo são apenas ilustrativos.

Gerar solicitacao_id uma vez por versão do pedido e reutilizar em tentativas do mesmo envio. Uma revisão do conteúdo após envio deve ter nova identificação. Workflow deve detectar ID repetido com conteúdo divergente, não reaplicar silenciosamente.

Portal somente consulta Supabase, prepara JSON e envia EmailJS. Não cria tabela de pedidos nem grava no banco. Template template_rg88ork e serviço service_pm2junr já informados; variáveis do template e corpo/anexo ainda precisam ser verificados no onboarding/template real. Não disparar email em teste sem autorização.

Responsável revisa e executa workflow próprio. Workflow revalida empresa, vínculos, referências, duplicidade e limite atual; email e admin.nome/email não comprovam autorização. Considerar agendamentos futuros, acessos e efeitos da desativação antes da execução. Ausência de profissional antigo no quadro ativo não apaga seu histórico.

## Situação

Modelo e documentação criados na pasta oficial de planejamento. Gerador, tipos e exemplo do portal em C:\projetos\portal consulta agenda24h ainda não foram modificados para este contrato; workflow executor também não implementado nesta etapa. Preparação do modelo não comprova compatibilidade com código real do onboarding não inspecionado.
