# Mapa e estado da fotografia

Esta skill foi montada a partir do workspace local do Agenda 24h em 24/09/2026. No ZIP de importacao, `project/` contem os arquivos principais. Para respeitar o limite de 200 arquivos do importador, 34 arquivos de texto (documentos historicos, testes e copias de migrations) foram reunidos em `references/ARQUIVOS-CONSOLIDADOS.txt`, com seus caminhos originais identificados. Nenhum conteudo desses arquivos foi omitido. A copia nao e um espelho ao vivo. Mudancas posteriores no repositorio ou nos servicos nao aparecem aqui ate o pacote ser reconstruido.

## Por onde navegar

Os caminhos abaixo se referem ao conteudo completo. Se um arquivo nao estiver diretamente em `project/`, procure seu caminho em `references/ARQUIVOS-CONSOLIDADOS.txt`.

- `project/documentacao/passagem-projeto-2026-09-23.md`: passagem de contexto e alertas de estado.
- `project/documentacao/especificacao-2026-09-24/`: PRD, TRD, app flow, briefing UI/UX, schema e plano de implementacao.
- `project/documentacao/controle-progresso-v2.md`: historico detalhado, mas alguns itens estao desatualizados; nao o use sozinho como status atual.
- `project/workflows-n8n/reconstrucao-v3/evento5s/`: WF1 linear webhook/5s, comparacao com legado e testes. O arquivo `wf1-linear-v3-5s.json` e artefato local, nao implantacao comprovada.
- `project/workflows-n8n/reconstrucao-v3/json/`: seis tools e guard V3. `project/workflows-n8n/reconstrucao-v3/`: migrations e testes relacionados.
- `project/workflows-n8n/automacoes-v2/`: exports locais de lembrete e reativacao pos-atendimento; a reativacao de faltosos ainda precisa de implementacao e homologacao.
- `project/workflows-n8n/comparecimento/` e `project/workflows-n8n/satisfacao/`: fluxos e instrucoes dessas frentes.
- `project/supabase/migrations/`: migrations da base; a existencia de um SQL nao indica aplicacao remota.
- `project/portal-web/`: portal React/Vite, contrato de integracao e migrations especificas.
- `project/provisionamento/`: onboarding, contratos JSON e provisionamento.

## Confiabilidade do estado

- Ultima verificacao remota citada na passagem: 22/09, somente leitura. Naquela data faltavam funcoes/papel V3 e a empresa-teste estava `em_validacao`; tudo isso deve ser rechecado antes de decisao operacional.
- O WF1 testado pelo proprietario foi despublicado apos timeout em `Reservar conversa`. O novo WF1 linear foi preparado localmente, sem comprovacao de importacao e teste fim a fim.
- Os exports V2 de lembrete e reativacao nao foram declarados ativos ou homologados. Nao presumir que a credencial Header Auth neles pertence a Evolution.
- O portal tem implementacao avancada e papel recepcionista no codigo, mas login, escrita, permissao e integracao real ainda exigem teste.
- Nunca substitua evidencia do ambiente real por esta fotografia.

## O que nao foi incluido

Foram excluidos arquivos `.env*`, historico Git, `node_modules`, `dist`, backups locais e arquivos compactados anteriores. Credenciais reais devem permanecer no gerenciador apropriado, nunca nesta skill. Exports originais mencionados em Downloads/fora do workspace nao fazem parte desta fotografia; quando forem relevantes, peca ao usuario o arquivo atualizado.

Para trabalho continuo com escrita no codigo, abra o repositorio original no Claude Code e instale esta skill em `.claude/skills/agenda24h-project/`. No Claude.ai, carregue o ZIP para fornecer contexto; a copia incluida no ZIP nao se sincroniza automaticamente com o repositorio nem com os servicos.
